﻿Public Class Form1
    Private popup As WH_CO1200M


    Public Sub InitPopup()

        popup = New WH_CO1200M      'Form1 안에 불려지는 폼을 여기서 호출한다. 
        ' 참조부분에 추가되어 있어야 한다
        ' 불려지는 폼은 다른 일반 메뉴와 동일하게 구현하면 된다

        If popup IsNot Nothing Then
            popup.Dock = System.Windows.Forms.DockStyle.Fill

            'popup 화면에 버턴이 있다면 popup내에서 제어해도 되고 여기서도 제어 가능하다

            'AddHandler popup.btn_popup_save.Click, AddressOf btn_popup_save_Click
            'AddHandler popup.btn_popup_delete.Click, AddressOf btn_popup_delete_Click
            'AddHandler popup.btn_popup_exit.Click, AddressOf btn_popup_exit_Click

            Me.Controls.Add(popup)

            popup.Show()
        End If
    End Sub


End Class