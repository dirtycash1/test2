﻿Imports Frame7
Imports Base7
Imports Base7.Shared


Public Class WH_CO1200M

    Private Sub Me_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    
        Me.NewForm()
       


    End Sub


    Private Sub btn_find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_find.Click
        Me.Open()

    End Sub


    Private Sub btn_exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_exit.Click
        'Me.DialogResult = Windows.Forms.DialogResult.Cancel
    End Sub
End Class
