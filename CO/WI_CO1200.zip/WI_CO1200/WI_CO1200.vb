﻿Imports Frame7
Imports Base7
Imports Base7.Shared

Public Class WI_CO1200
    Dim p As New OpenParameters

    Private Sub Me_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.NewForm()
    End Sub
    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            Case MenuType.Cancel
                Me.NewForm()
            Case Else
                MyBase.MenuButton_Click(mty)        '나머지는 기본기능에 맡긴다
        End Select
    End Sub
    Public Overrides Sub NewForm()
        find_gd_cd.Text = ""
        gd_cd.Text = ""

        Me.OpenTrigger("WI_CO1200_list")    'g_list을 기점으로 OpenTrigger로 작동하는 모든 Control들 조회

        gd_cd.Focus()
    End Sub


    Private Sub find_Clear()
        p.Clear()
        p.Add("@find_gd_cd", find_gd_cd.Text)
        p.Add("@find_gd_nm", find_gd_nm.Text)
        p.Add("@find_jagu_cd", "XXX")
        p.Add("@find_stts", "XXX")
        p.Add("@find_help_gu", "XXX")

        Me.Open("WI_CO1200_list", p)
    End Sub
    
    'Private Sub btn_pic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If img.Visible Then
    '        img.Visible = False
    '        Me.SplitContainer3.SplitterDistance = 35
    '    Else
    '        img.Visible = True
    '        Me.SplitContainer3.SplitterDistance = 220
    '    End If
    'End Sub

    Private Sub btn_find_Click(sender As Object, e As System.EventArgs) Handles btn_find.Click
        ' 찾기 리스트 조회
        g_list.Open()
    End Sub


    Private Sub btn_cancel_Click(sender As Object, e As System.EventArgs) Handles btn_cancel.Click
        Me.find_Clear()
    End Sub
End Class
