﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WI_CO_REMK1100
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.file_save = New DevExpress.XtraEditors.SimpleButton()
        Me.std_month = New Frame7.eDate()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel2 = New Frame7.ePanel()
        Me.sa_rmk1 = New Frame7.eMemo()
        Me.EPanel4 = New Frame7.ePanel()
        Me.sa_10 = New Frame7.eGrid()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.EPanel3 = New Frame7.ePanel()
        Me.sa_rmk2 = New Frame7.eMemo()
        Me.EPanel5 = New Frame7.ePanel()
        Me.sa_20 = New Frame7.eGrid()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer6 = New System.Windows.Forms.SplitContainer()
        Me.EPanel6 = New Frame7.ePanel()
        Me.b_rmk1 = New Frame7.eMemo()
        Me.EPanel7 = New Frame7.ePanel()
        Me.b_10 = New Frame7.eGrid()
        Me.SplitContainer7 = New System.Windows.Forms.SplitContainer()
        Me.EPanel8 = New Frame7.ePanel()
        Me.b_rmk2 = New Frame7.eMemo()
        Me.EPanel9 = New Frame7.ePanel()
        Me.b_20 = New Frame7.eGrid()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer8 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer9 = New System.Windows.Forms.SplitContainer()
        Me.EPanel10 = New Frame7.ePanel()
        Me.j_rmk1 = New Frame7.eMemo()
        Me.EPanel11 = New Frame7.ePanel()
        Me.j_10 = New Frame7.eGrid()
        Me.SplitContainer10 = New System.Windows.Forms.SplitContainer()
        Me.EPanel12 = New Frame7.ePanel()
        Me.j_rmk2 = New Frame7.eMemo()
        Me.EPanel13 = New Frame7.ePanel()
        Me.j_20 = New Frame7.eGrid()
        Me.XtraTabPage4 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer11 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer12 = New System.Windows.Forms.SplitContainer()
        Me.EPanel14 = New Frame7.ePanel()
        Me.sqc_rmk1 = New Frame7.eMemo()
        Me.EPanel15 = New Frame7.ePanel()
        Me.sqc_10 = New Frame7.eGrid()
        Me.SplitContainer13 = New System.Windows.Forms.SplitContainer()
        Me.EPanel16 = New Frame7.ePanel()
        Me.sqc_rmk2 = New Frame7.eMemo()
        Me.EPanel17 = New Frame7.ePanel()
        Me.sqc_20 = New Frame7.eGrid()
        Me.XtraTabPage5 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer14 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer15 = New System.Windows.Forms.SplitContainer()
        Me.EPanel18 = New Frame7.ePanel()
        Me.jejo_rmk1 = New Frame7.eMemo()
        Me.EPanel19 = New Frame7.ePanel()
        Me.jejo_10 = New Frame7.eGrid()
        Me.SplitContainer16 = New System.Windows.Forms.SplitContainer()
        Me.EPanel20 = New Frame7.ePanel()
        Me.jejo_rmk2 = New Frame7.eMemo()
        Me.EPanel21 = New Frame7.ePanel()
        Me.jejo_20 = New Frame7.eGrid()
        Me.XtraTabPage6 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer17 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer18 = New System.Windows.Forms.SplitContainer()
        Me.EPanel22 = New Frame7.ePanel()
        Me.ch_rmk1 = New Frame7.eMemo()
        Me.EPanel23 = New Frame7.ePanel()
        Me.ch_10 = New Frame7.eGrid()
        Me.SplitContainer19 = New System.Windows.Forms.SplitContainer()
        Me.EPanel24 = New Frame7.ePanel()
        Me.ch_rmk2 = New Frame7.eMemo()
        Me.EPanel25 = New Frame7.ePanel()
        Me.ch_20 = New Frame7.eGrid()
        Me.XtraTabPage7 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer20 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer21 = New System.Windows.Forms.SplitContainer()
        Me.EPanel26 = New Frame7.ePanel()
        Me.gong_rmk1 = New Frame7.eMemo()
        Me.EPanel27 = New Frame7.ePanel()
        Me.gong_10 = New Frame7.eGrid()
        Me.SplitContainer22 = New System.Windows.Forms.SplitContainer()
        Me.EPanel28 = New Frame7.ePanel()
        Me.gong_rmk2 = New Frame7.eMemo()
        Me.EPanel29 = New Frame7.ePanel()
        Me.gong_20 = New Frame7.eGrid()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        CType(Me.EPanel5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel5.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel2.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        Me.SplitContainer6.Panel1.SuspendLayout()
        Me.SplitContainer6.Panel2.SuspendLayout()
        Me.SplitContainer6.SuspendLayout()
        CType(Me.EPanel6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel6.SuspendLayout()
        CType(Me.EPanel7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel7.SuspendLayout()
        Me.SplitContainer7.Panel1.SuspendLayout()
        Me.SplitContainer7.Panel2.SuspendLayout()
        Me.SplitContainer7.SuspendLayout()
        CType(Me.EPanel8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel8.SuspendLayout()
        CType(Me.EPanel9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel9.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        Me.SplitContainer8.Panel1.SuspendLayout()
        Me.SplitContainer8.Panel2.SuspendLayout()
        Me.SplitContainer8.SuspendLayout()
        Me.SplitContainer9.Panel1.SuspendLayout()
        Me.SplitContainer9.Panel2.SuspendLayout()
        Me.SplitContainer9.SuspendLayout()
        CType(Me.EPanel10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel10.SuspendLayout()
        CType(Me.EPanel11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel11.SuspendLayout()
        Me.SplitContainer10.Panel1.SuspendLayout()
        Me.SplitContainer10.Panel2.SuspendLayout()
        Me.SplitContainer10.SuspendLayout()
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel12.SuspendLayout()
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel13.SuspendLayout()
        Me.XtraTabPage4.SuspendLayout()
        Me.SplitContainer11.Panel1.SuspendLayout()
        Me.SplitContainer11.Panel2.SuspendLayout()
        Me.SplitContainer11.SuspendLayout()
        Me.SplitContainer12.Panel1.SuspendLayout()
        Me.SplitContainer12.Panel2.SuspendLayout()
        Me.SplitContainer12.SuspendLayout()
        CType(Me.EPanel14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel14.SuspendLayout()
        CType(Me.EPanel15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel15.SuspendLayout()
        Me.SplitContainer13.Panel1.SuspendLayout()
        Me.SplitContainer13.Panel2.SuspendLayout()
        Me.SplitContainer13.SuspendLayout()
        CType(Me.EPanel16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel16.SuspendLayout()
        CType(Me.EPanel17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel17.SuspendLayout()
        Me.XtraTabPage5.SuspendLayout()
        Me.SplitContainer14.Panel1.SuspendLayout()
        Me.SplitContainer14.Panel2.SuspendLayout()
        Me.SplitContainer14.SuspendLayout()
        Me.SplitContainer15.Panel1.SuspendLayout()
        Me.SplitContainer15.Panel2.SuspendLayout()
        Me.SplitContainer15.SuspendLayout()
        CType(Me.EPanel18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel18.SuspendLayout()
        CType(Me.EPanel19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel19.SuspendLayout()
        Me.SplitContainer16.Panel1.SuspendLayout()
        Me.SplitContainer16.Panel2.SuspendLayout()
        Me.SplitContainer16.SuspendLayout()
        CType(Me.EPanel20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel20.SuspendLayout()
        CType(Me.EPanel21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel21.SuspendLayout()
        Me.XtraTabPage6.SuspendLayout()
        Me.SplitContainer17.Panel1.SuspendLayout()
        Me.SplitContainer17.Panel2.SuspendLayout()
        Me.SplitContainer17.SuspendLayout()
        Me.SplitContainer18.Panel1.SuspendLayout()
        Me.SplitContainer18.Panel2.SuspendLayout()
        Me.SplitContainer18.SuspendLayout()
        CType(Me.EPanel22, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel22.SuspendLayout()
        CType(Me.EPanel23, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel23.SuspendLayout()
        Me.SplitContainer19.Panel1.SuspendLayout()
        Me.SplitContainer19.Panel2.SuspendLayout()
        Me.SplitContainer19.SuspendLayout()
        CType(Me.EPanel24, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel24.SuspendLayout()
        CType(Me.EPanel25, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel25.SuspendLayout()
        Me.XtraTabPage7.SuspendLayout()
        Me.SplitContainer20.Panel1.SuspendLayout()
        Me.SplitContainer20.Panel2.SuspendLayout()
        Me.SplitContainer20.SuspendLayout()
        Me.SplitContainer21.Panel1.SuspendLayout()
        Me.SplitContainer21.Panel2.SuspendLayout()
        Me.SplitContainer21.SuspendLayout()
        CType(Me.EPanel26, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel26.SuspendLayout()
        CType(Me.EPanel27, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel27.SuspendLayout()
        Me.SplitContainer22.Panel1.SuspendLayout()
        Me.SplitContainer22.Panel2.SuspendLayout()
        Me.SplitContainer22.SuspendLayout()
        CType(Me.EPanel28, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel28.SuspendLayout()
        CType(Me.EPanel29, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel29.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1182, 611)
        Me.SplitContainer1.SplitterDistance = 71
        Me.SplitContainer1.TabIndex = 6
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.file_save)
        Me.EPanel1.Controls.Add(Me.std_month)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1182, 71)
        Me.EPanel1.TabIndex = 1
        Me.EPanel1.Text = "     공정별 특이사항 - 조건검색"
        '
        'file_save
        '
        Me.file_save.Location = New System.Drawing.Point(247, 32)
        Me.file_save.Name = "file_save"
        Me.file_save.Size = New System.Drawing.Size(91, 24)
        Me.file_save.TabIndex = 19
        Me.file_save.Text = "파일 저장"
        Me.file_save.Visible = False
        '
        'std_month
        '
        Me.std_month.Location = New System.Drawing.Point(18, 35)
        Me.std_month.Name = "std_month"
        Me.std_month.Size = New System.Drawing.Size(193, 21)
        Me.std_month.TabIndex = 18
        Me.std_month.Title = "기준월"
        Me.std_month.TitleWidth = 80
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1182, 536)
        Me.XtraTabControl1.TabIndex = 4
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2, Me.XtraTabPage3, Me.XtraTabPage4, Me.XtraTabPage5, Me.XtraTabPage6, Me.XtraTabPage7})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer2)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage1.Text = "사출"
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer4)
        Me.SplitContainer2.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer2.SplitterDistance = 584
        Me.SplitContainer2.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel4)
        Me.SplitContainer3.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer3.SplitterDistance = 378
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.sa_rmk1)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(584, 378)
        Me.EPanel2.TabIndex = 2
        Me.EPanel2.Text = "     사출 #1공장"
        '
        'sa_rmk1
        '
        Me.sa_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sa_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.sa_rmk1.Name = "sa_rmk1"
        Me.sa_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.sa_rmk1.TabIndex = 155
        Me.sa_rmk1.Title = ""
        Me.sa_rmk1.TitleWidth = 0
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.sa_10)
        Me.EPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel4.Location = New System.Drawing.Point(0, 0)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(584, 124)
        Me.EPanel4.TabIndex = 3
        Me.EPanel4.Text = "     1공장 - 첨부파일"
        '
        'sa_10
        '
        Me.sa_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sa_10.Location = New System.Drawing.Point(2, 23)
        Me.sa_10.Name = "sa_10"
        Me.sa_10.ReadOnly = False
        Me.sa_10.RowHeight = -1
        Me.sa_10.Size = New System.Drawing.Size(580, 99)
        Me.sa_10.TabIndex = 2
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.EPanel3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.EPanel5)
        Me.SplitContainer4.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer4.SplitterDistance = 379
        Me.SplitContainer4.TabIndex = 0
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.sa_rmk2)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(587, 379)
        Me.EPanel3.TabIndex = 3
        Me.EPanel3.Text = "     사출 #2공장"
        '
        'sa_rmk2
        '
        Me.sa_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sa_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.sa_rmk2.Name = "sa_rmk2"
        Me.sa_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.sa_rmk2.TabIndex = 156
        Me.sa_rmk2.Title = ""
        Me.sa_rmk2.TitleWidth = 0
        '
        'EPanel5
        '
        Me.EPanel5.Controls.Add(Me.sa_20)
        Me.EPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel5.Location = New System.Drawing.Point(0, 0)
        Me.EPanel5.Name = "EPanel5"
        Me.EPanel5.Size = New System.Drawing.Size(587, 123)
        Me.EPanel5.TabIndex = 3
        Me.EPanel5.Text = "     2공장 - 첨부파일"
        '
        'sa_20
        '
        Me.sa_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sa_20.Location = New System.Drawing.Point(2, 23)
        Me.sa_20.Name = "sa_20"
        Me.sa_20.ReadOnly = False
        Me.sa_20.RowHeight = -1
        Me.sa_20.Size = New System.Drawing.Size(583, 98)
        Me.sa_20.TabIndex = 3
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.SplitContainer5)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage2.Text = "분리"
        '
        'SplitContainer5
        '
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.SplitContainer6)
        '
        'SplitContainer5.Panel2
        '
        Me.SplitContainer5.Panel2.Controls.Add(Me.SplitContainer7)
        Me.SplitContainer5.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer5.SplitterDistance = 584
        Me.SplitContainer5.TabIndex = 1
        '
        'SplitContainer6
        '
        Me.SplitContainer6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer6.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer6.Name = "SplitContainer6"
        Me.SplitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer6.Panel1
        '
        Me.SplitContainer6.Panel1.Controls.Add(Me.EPanel6)
        '
        'SplitContainer6.Panel2
        '
        Me.SplitContainer6.Panel2.Controls.Add(Me.EPanel7)
        Me.SplitContainer6.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer6.SplitterDistance = 378
        Me.SplitContainer6.TabIndex = 0
        '
        'EPanel6
        '
        Me.EPanel6.Controls.Add(Me.b_rmk1)
        Me.EPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel6.Location = New System.Drawing.Point(0, 0)
        Me.EPanel6.Name = "EPanel6"
        Me.EPanel6.Size = New System.Drawing.Size(584, 378)
        Me.EPanel6.TabIndex = 2
        Me.EPanel6.Text = "     1공장"
        '
        'b_rmk1
        '
        Me.b_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.b_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.b_rmk1.Name = "b_rmk1"
        Me.b_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.b_rmk1.TabIndex = 155
        Me.b_rmk1.Title = ""
        Me.b_rmk1.TitleWidth = 0
        '
        'EPanel7
        '
        Me.EPanel7.Controls.Add(Me.b_10)
        Me.EPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel7.Location = New System.Drawing.Point(0, 0)
        Me.EPanel7.Name = "EPanel7"
        Me.EPanel7.Size = New System.Drawing.Size(584, 124)
        Me.EPanel7.TabIndex = 3
        Me.EPanel7.Text = "     1공장 - 첨부파일"
        '
        'b_10
        '
        Me.b_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.b_10.Location = New System.Drawing.Point(2, 23)
        Me.b_10.Name = "b_10"
        Me.b_10.ReadOnly = False
        Me.b_10.RowHeight = -1
        Me.b_10.Size = New System.Drawing.Size(580, 99)
        Me.b_10.TabIndex = 2
        '
        'SplitContainer7
        '
        Me.SplitContainer7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer7.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer7.Name = "SplitContainer7"
        Me.SplitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer7.Panel1
        '
        Me.SplitContainer7.Panel1.Controls.Add(Me.EPanel8)
        '
        'SplitContainer7.Panel2
        '
        Me.SplitContainer7.Panel2.Controls.Add(Me.EPanel9)
        Me.SplitContainer7.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer7.SplitterDistance = 379
        Me.SplitContainer7.TabIndex = 0
        '
        'EPanel8
        '
        Me.EPanel8.Controls.Add(Me.b_rmk2)
        Me.EPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel8.Location = New System.Drawing.Point(0, 0)
        Me.EPanel8.Name = "EPanel8"
        Me.EPanel8.Size = New System.Drawing.Size(587, 379)
        Me.EPanel8.TabIndex = 3
        Me.EPanel8.Text = "     2공장"
        '
        'b_rmk2
        '
        Me.b_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.b_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.b_rmk2.Name = "b_rmk2"
        Me.b_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.b_rmk2.TabIndex = 156
        Me.b_rmk2.Title = ""
        Me.b_rmk2.TitleWidth = 0
        '
        'EPanel9
        '
        Me.EPanel9.Controls.Add(Me.b_20)
        Me.EPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel9.Location = New System.Drawing.Point(0, 0)
        Me.EPanel9.Name = "EPanel9"
        Me.EPanel9.Size = New System.Drawing.Size(587, 123)
        Me.EPanel9.TabIndex = 3
        Me.EPanel9.Text = "     2공장 - 첨부파일"
        '
        'b_20
        '
        Me.b_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.b_20.Location = New System.Drawing.Point(2, 23)
        Me.b_20.Name = "b_20"
        Me.b_20.ReadOnly = False
        Me.b_20.RowHeight = -1
        Me.b_20.Size = New System.Drawing.Size(583, 98)
        Me.b_20.TabIndex = 3
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.SplitContainer8)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage3.Text = "전면접착"
        '
        'SplitContainer8
        '
        Me.SplitContainer8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer8.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer8.Name = "SplitContainer8"
        '
        'SplitContainer8.Panel1
        '
        Me.SplitContainer8.Panel1.Controls.Add(Me.SplitContainer9)
        '
        'SplitContainer8.Panel2
        '
        Me.SplitContainer8.Panel2.Controls.Add(Me.SplitContainer10)
        Me.SplitContainer8.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer8.SplitterDistance = 584
        Me.SplitContainer8.TabIndex = 1
        '
        'SplitContainer9
        '
        Me.SplitContainer9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer9.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer9.Name = "SplitContainer9"
        Me.SplitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer9.Panel1
        '
        Me.SplitContainer9.Panel1.Controls.Add(Me.EPanel10)
        '
        'SplitContainer9.Panel2
        '
        Me.SplitContainer9.Panel2.Controls.Add(Me.EPanel11)
        Me.SplitContainer9.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer9.SplitterDistance = 378
        Me.SplitContainer9.TabIndex = 0
        '
        'EPanel10
        '
        Me.EPanel10.Controls.Add(Me.j_rmk1)
        Me.EPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel10.Location = New System.Drawing.Point(0, 0)
        Me.EPanel10.Name = "EPanel10"
        Me.EPanel10.Size = New System.Drawing.Size(584, 378)
        Me.EPanel10.TabIndex = 2
        Me.EPanel10.Text = "     1공장"
        '
        'j_rmk1
        '
        Me.j_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.j_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.j_rmk1.Name = "j_rmk1"
        Me.j_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.j_rmk1.TabIndex = 155
        Me.j_rmk1.Title = ""
        Me.j_rmk1.TitleWidth = 0
        '
        'EPanel11
        '
        Me.EPanel11.Controls.Add(Me.j_10)
        Me.EPanel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel11.Location = New System.Drawing.Point(0, 0)
        Me.EPanel11.Name = "EPanel11"
        Me.EPanel11.Size = New System.Drawing.Size(584, 124)
        Me.EPanel11.TabIndex = 3
        Me.EPanel11.Text = "     1공장 - 첨부파일"
        '
        'j_10
        '
        Me.j_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.j_10.Location = New System.Drawing.Point(2, 23)
        Me.j_10.Name = "j_10"
        Me.j_10.ReadOnly = False
        Me.j_10.RowHeight = -1
        Me.j_10.Size = New System.Drawing.Size(580, 99)
        Me.j_10.TabIndex = 2
        '
        'SplitContainer10
        '
        Me.SplitContainer10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer10.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer10.Name = "SplitContainer10"
        Me.SplitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer10.Panel1
        '
        Me.SplitContainer10.Panel1.Controls.Add(Me.EPanel12)
        '
        'SplitContainer10.Panel2
        '
        Me.SplitContainer10.Panel2.Controls.Add(Me.EPanel13)
        Me.SplitContainer10.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer10.SplitterDistance = 379
        Me.SplitContainer10.TabIndex = 0
        '
        'EPanel12
        '
        Me.EPanel12.Controls.Add(Me.j_rmk2)
        Me.EPanel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel12.Location = New System.Drawing.Point(0, 0)
        Me.EPanel12.Name = "EPanel12"
        Me.EPanel12.Size = New System.Drawing.Size(587, 379)
        Me.EPanel12.TabIndex = 3
        Me.EPanel12.Text = "     2공장"
        '
        'j_rmk2
        '
        Me.j_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.j_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.j_rmk2.Name = "j_rmk2"
        Me.j_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.j_rmk2.TabIndex = 156
        Me.j_rmk2.Title = ""
        Me.j_rmk2.TitleWidth = 0
        '
        'EPanel13
        '
        Me.EPanel13.Controls.Add(Me.j_20)
        Me.EPanel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel13.Location = New System.Drawing.Point(0, 0)
        Me.EPanel13.Name = "EPanel13"
        Me.EPanel13.Size = New System.Drawing.Size(587, 123)
        Me.EPanel13.TabIndex = 3
        Me.EPanel13.Text = "     2공장 - 첨부파일"
        '
        'j_20
        '
        Me.j_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.j_20.Location = New System.Drawing.Point(2, 23)
        Me.j_20.Name = "j_20"
        Me.j_20.ReadOnly = False
        Me.j_20.RowHeight = -1
        Me.j_20.Size = New System.Drawing.Size(583, 98)
        Me.j_20.TabIndex = 3
        '
        'XtraTabPage4
        '
        Me.XtraTabPage4.Controls.Add(Me.SplitContainer11)
        Me.XtraTabPage4.Name = "XtraTabPage4"
        Me.XtraTabPage4.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage4.Text = "SQC"
        '
        'SplitContainer11
        '
        Me.SplitContainer11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer11.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer11.Name = "SplitContainer11"
        '
        'SplitContainer11.Panel1
        '
        Me.SplitContainer11.Panel1.Controls.Add(Me.SplitContainer12)
        '
        'SplitContainer11.Panel2
        '
        Me.SplitContainer11.Panel2.Controls.Add(Me.SplitContainer13)
        Me.SplitContainer11.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer11.SplitterDistance = 584
        Me.SplitContainer11.TabIndex = 1
        '
        'SplitContainer12
        '
        Me.SplitContainer12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer12.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer12.Name = "SplitContainer12"
        Me.SplitContainer12.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer12.Panel1
        '
        Me.SplitContainer12.Panel1.Controls.Add(Me.EPanel14)
        '
        'SplitContainer12.Panel2
        '
        Me.SplitContainer12.Panel2.Controls.Add(Me.EPanel15)
        Me.SplitContainer12.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer12.SplitterDistance = 378
        Me.SplitContainer12.TabIndex = 0
        '
        'EPanel14
        '
        Me.EPanel14.Controls.Add(Me.sqc_rmk1)
        Me.EPanel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel14.Location = New System.Drawing.Point(0, 0)
        Me.EPanel14.Name = "EPanel14"
        Me.EPanel14.Size = New System.Drawing.Size(584, 378)
        Me.EPanel14.TabIndex = 2
        Me.EPanel14.Text = "     1공장"
        '
        'sqc_rmk1
        '
        Me.sqc_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sqc_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.sqc_rmk1.Name = "sqc_rmk1"
        Me.sqc_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.sqc_rmk1.TabIndex = 155
        Me.sqc_rmk1.Title = ""
        Me.sqc_rmk1.TitleWidth = 0
        '
        'EPanel15
        '
        Me.EPanel15.Controls.Add(Me.sqc_10)
        Me.EPanel15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel15.Location = New System.Drawing.Point(0, 0)
        Me.EPanel15.Name = "EPanel15"
        Me.EPanel15.Size = New System.Drawing.Size(584, 124)
        Me.EPanel15.TabIndex = 3
        Me.EPanel15.Text = "     1공장 - 첨부파일"
        '
        'sqc_10
        '
        Me.sqc_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sqc_10.Location = New System.Drawing.Point(2, 23)
        Me.sqc_10.Name = "sqc_10"
        Me.sqc_10.ReadOnly = False
        Me.sqc_10.RowHeight = -1
        Me.sqc_10.Size = New System.Drawing.Size(580, 99)
        Me.sqc_10.TabIndex = 2
        '
        'SplitContainer13
        '
        Me.SplitContainer13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer13.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer13.Name = "SplitContainer13"
        Me.SplitContainer13.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer13.Panel1
        '
        Me.SplitContainer13.Panel1.Controls.Add(Me.EPanel16)
        '
        'SplitContainer13.Panel2
        '
        Me.SplitContainer13.Panel2.Controls.Add(Me.EPanel17)
        Me.SplitContainer13.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer13.SplitterDistance = 379
        Me.SplitContainer13.TabIndex = 0
        '
        'EPanel16
        '
        Me.EPanel16.Controls.Add(Me.sqc_rmk2)
        Me.EPanel16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel16.Location = New System.Drawing.Point(0, 0)
        Me.EPanel16.Name = "EPanel16"
        Me.EPanel16.Size = New System.Drawing.Size(587, 379)
        Me.EPanel16.TabIndex = 3
        Me.EPanel16.Text = "     2공장"
        '
        'sqc_rmk2
        '
        Me.sqc_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sqc_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.sqc_rmk2.Name = "sqc_rmk2"
        Me.sqc_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.sqc_rmk2.TabIndex = 156
        Me.sqc_rmk2.Title = ""
        Me.sqc_rmk2.TitleWidth = 0
        '
        'EPanel17
        '
        Me.EPanel17.Controls.Add(Me.sqc_20)
        Me.EPanel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel17.Location = New System.Drawing.Point(0, 0)
        Me.EPanel17.Name = "EPanel17"
        Me.EPanel17.Size = New System.Drawing.Size(587, 123)
        Me.EPanel17.TabIndex = 3
        Me.EPanel17.Text = "     2공장 - 첨부파일"
        '
        'sqc_20
        '
        Me.sqc_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sqc_20.Location = New System.Drawing.Point(2, 23)
        Me.sqc_20.Name = "sqc_20"
        Me.sqc_20.ReadOnly = False
        Me.sqc_20.RowHeight = -1
        Me.sqc_20.Size = New System.Drawing.Size(583, 98)
        Me.sqc_20.TabIndex = 3
        '
        'XtraTabPage5
        '
        Me.XtraTabPage5.Controls.Add(Me.SplitContainer14)
        Me.XtraTabPage5.Name = "XtraTabPage5"
        Me.XtraTabPage5.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage5.Text = "제조기술"
        '
        'SplitContainer14
        '
        Me.SplitContainer14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer14.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer14.Name = "SplitContainer14"
        '
        'SplitContainer14.Panel1
        '
        Me.SplitContainer14.Panel1.Controls.Add(Me.SplitContainer15)
        '
        'SplitContainer14.Panel2
        '
        Me.SplitContainer14.Panel2.Controls.Add(Me.SplitContainer16)
        Me.SplitContainer14.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer14.SplitterDistance = 584
        Me.SplitContainer14.TabIndex = 1
        '
        'SplitContainer15
        '
        Me.SplitContainer15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer15.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer15.Name = "SplitContainer15"
        Me.SplitContainer15.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer15.Panel1
        '
        Me.SplitContainer15.Panel1.Controls.Add(Me.EPanel18)
        '
        'SplitContainer15.Panel2
        '
        Me.SplitContainer15.Panel2.Controls.Add(Me.EPanel19)
        Me.SplitContainer15.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer15.SplitterDistance = 378
        Me.SplitContainer15.TabIndex = 0
        '
        'EPanel18
        '
        Me.EPanel18.Controls.Add(Me.jejo_rmk1)
        Me.EPanel18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel18.Location = New System.Drawing.Point(0, 0)
        Me.EPanel18.Name = "EPanel18"
        Me.EPanel18.Size = New System.Drawing.Size(584, 378)
        Me.EPanel18.TabIndex = 2
        Me.EPanel18.Text = "     1공장"
        '
        'jejo_rmk1
        '
        Me.jejo_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.jejo_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.jejo_rmk1.Name = "jejo_rmk1"
        Me.jejo_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.jejo_rmk1.TabIndex = 155
        Me.jejo_rmk1.Title = ""
        Me.jejo_rmk1.TitleWidth = 0
        '
        'EPanel19
        '
        Me.EPanel19.Controls.Add(Me.jejo_10)
        Me.EPanel19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel19.Location = New System.Drawing.Point(0, 0)
        Me.EPanel19.Name = "EPanel19"
        Me.EPanel19.Size = New System.Drawing.Size(584, 124)
        Me.EPanel19.TabIndex = 3
        Me.EPanel19.Text = "     1공장 - 첨부파일"
        '
        'jejo_10
        '
        Me.jejo_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.jejo_10.Location = New System.Drawing.Point(2, 23)
        Me.jejo_10.Name = "jejo_10"
        Me.jejo_10.ReadOnly = False
        Me.jejo_10.RowHeight = -1
        Me.jejo_10.Size = New System.Drawing.Size(580, 99)
        Me.jejo_10.TabIndex = 2
        '
        'SplitContainer16
        '
        Me.SplitContainer16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer16.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer16.Name = "SplitContainer16"
        Me.SplitContainer16.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer16.Panel1
        '
        Me.SplitContainer16.Panel1.Controls.Add(Me.EPanel20)
        '
        'SplitContainer16.Panel2
        '
        Me.SplitContainer16.Panel2.Controls.Add(Me.EPanel21)
        Me.SplitContainer16.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer16.SplitterDistance = 379
        Me.SplitContainer16.TabIndex = 0
        '
        'EPanel20
        '
        Me.EPanel20.Controls.Add(Me.jejo_rmk2)
        Me.EPanel20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel20.Location = New System.Drawing.Point(0, 0)
        Me.EPanel20.Name = "EPanel20"
        Me.EPanel20.Size = New System.Drawing.Size(587, 379)
        Me.EPanel20.TabIndex = 3
        Me.EPanel20.Text = "     2공장"
        '
        'jejo_rmk2
        '
        Me.jejo_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.jejo_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.jejo_rmk2.Name = "jejo_rmk2"
        Me.jejo_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.jejo_rmk2.TabIndex = 156
        Me.jejo_rmk2.Title = ""
        Me.jejo_rmk2.TitleWidth = 0
        '
        'EPanel21
        '
        Me.EPanel21.Controls.Add(Me.jejo_20)
        Me.EPanel21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel21.Location = New System.Drawing.Point(0, 0)
        Me.EPanel21.Name = "EPanel21"
        Me.EPanel21.Size = New System.Drawing.Size(587, 123)
        Me.EPanel21.TabIndex = 3
        Me.EPanel21.Text = "     2공장 - 첨부파일"
        '
        'jejo_20
        '
        Me.jejo_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.jejo_20.Location = New System.Drawing.Point(2, 23)
        Me.jejo_20.Name = "jejo_20"
        Me.jejo_20.ReadOnly = False
        Me.jejo_20.RowHeight = -1
        Me.jejo_20.Size = New System.Drawing.Size(583, 98)
        Me.jejo_20.TabIndex = 3
        '
        'XtraTabPage6
        '
        Me.XtraTabPage6.Controls.Add(Me.SplitContainer17)
        Me.XtraTabPage6.Name = "XtraTabPage6"
        Me.XtraTabPage6.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage6.Text = "출하"
        '
        'SplitContainer17
        '
        Me.SplitContainer17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer17.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer17.Name = "SplitContainer17"
        '
        'SplitContainer17.Panel1
        '
        Me.SplitContainer17.Panel1.Controls.Add(Me.SplitContainer18)
        '
        'SplitContainer17.Panel2
        '
        Me.SplitContainer17.Panel2.Controls.Add(Me.SplitContainer19)
        Me.SplitContainer17.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer17.SplitterDistance = 584
        Me.SplitContainer17.TabIndex = 1
        '
        'SplitContainer18
        '
        Me.SplitContainer18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer18.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer18.Name = "SplitContainer18"
        Me.SplitContainer18.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer18.Panel1
        '
        Me.SplitContainer18.Panel1.Controls.Add(Me.EPanel22)
        '
        'SplitContainer18.Panel2
        '
        Me.SplitContainer18.Panel2.Controls.Add(Me.EPanel23)
        Me.SplitContainer18.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer18.SplitterDistance = 378
        Me.SplitContainer18.TabIndex = 0
        '
        'EPanel22
        '
        Me.EPanel22.Controls.Add(Me.ch_rmk1)
        Me.EPanel22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel22.Location = New System.Drawing.Point(0, 0)
        Me.EPanel22.Name = "EPanel22"
        Me.EPanel22.Size = New System.Drawing.Size(584, 378)
        Me.EPanel22.TabIndex = 2
        Me.EPanel22.Text = "     1공장"
        '
        'ch_rmk1
        '
        Me.ch_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ch_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.ch_rmk1.Name = "ch_rmk1"
        Me.ch_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.ch_rmk1.TabIndex = 155
        Me.ch_rmk1.Title = ""
        Me.ch_rmk1.TitleWidth = 0
        '
        'EPanel23
        '
        Me.EPanel23.Controls.Add(Me.ch_10)
        Me.EPanel23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel23.Location = New System.Drawing.Point(0, 0)
        Me.EPanel23.Name = "EPanel23"
        Me.EPanel23.Size = New System.Drawing.Size(584, 124)
        Me.EPanel23.TabIndex = 3
        Me.EPanel23.Text = "     1공장 - 첨부파일"
        '
        'ch_10
        '
        Me.ch_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ch_10.Location = New System.Drawing.Point(2, 23)
        Me.ch_10.Name = "ch_10"
        Me.ch_10.ReadOnly = False
        Me.ch_10.RowHeight = -1
        Me.ch_10.Size = New System.Drawing.Size(580, 99)
        Me.ch_10.TabIndex = 2
        '
        'SplitContainer19
        '
        Me.SplitContainer19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer19.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer19.Name = "SplitContainer19"
        Me.SplitContainer19.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer19.Panel1
        '
        Me.SplitContainer19.Panel1.Controls.Add(Me.EPanel24)
        '
        'SplitContainer19.Panel2
        '
        Me.SplitContainer19.Panel2.Controls.Add(Me.EPanel25)
        Me.SplitContainer19.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer19.SplitterDistance = 379
        Me.SplitContainer19.TabIndex = 0
        '
        'EPanel24
        '
        Me.EPanel24.Controls.Add(Me.ch_rmk2)
        Me.EPanel24.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel24.Location = New System.Drawing.Point(0, 0)
        Me.EPanel24.Name = "EPanel24"
        Me.EPanel24.Size = New System.Drawing.Size(587, 379)
        Me.EPanel24.TabIndex = 3
        Me.EPanel24.Text = "     2공장"
        '
        'ch_rmk2
        '
        Me.ch_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ch_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.ch_rmk2.Name = "ch_rmk2"
        Me.ch_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.ch_rmk2.TabIndex = 156
        Me.ch_rmk2.Title = ""
        Me.ch_rmk2.TitleWidth = 0
        '
        'EPanel25
        '
        Me.EPanel25.Controls.Add(Me.ch_20)
        Me.EPanel25.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel25.Location = New System.Drawing.Point(0, 0)
        Me.EPanel25.Name = "EPanel25"
        Me.EPanel25.Size = New System.Drawing.Size(587, 123)
        Me.EPanel25.TabIndex = 3
        Me.EPanel25.Text = "     2공장 - 첨부파일"
        '
        'ch_20
        '
        Me.ch_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ch_20.Location = New System.Drawing.Point(2, 23)
        Me.ch_20.Name = "ch_20"
        Me.ch_20.ReadOnly = False
        Me.ch_20.RowHeight = -1
        Me.ch_20.Size = New System.Drawing.Size(583, 98)
        Me.ch_20.TabIndex = 3
        '
        'XtraTabPage7
        '
        Me.XtraTabPage7.Controls.Add(Me.SplitContainer20)
        Me.XtraTabPage7.Name = "XtraTabPage7"
        Me.XtraTabPage7.Size = New System.Drawing.Size(1175, 506)
        Me.XtraTabPage7.Text = "공무"
        '
        'SplitContainer20
        '
        Me.SplitContainer20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer20.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer20.Name = "SplitContainer20"
        '
        'SplitContainer20.Panel1
        '
        Me.SplitContainer20.Panel1.Controls.Add(Me.SplitContainer21)
        '
        'SplitContainer20.Panel2
        '
        Me.SplitContainer20.Panel2.Controls.Add(Me.SplitContainer22)
        Me.SplitContainer20.Size = New System.Drawing.Size(1175, 506)
        Me.SplitContainer20.SplitterDistance = 584
        Me.SplitContainer20.TabIndex = 1
        '
        'SplitContainer21
        '
        Me.SplitContainer21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer21.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer21.Name = "SplitContainer21"
        Me.SplitContainer21.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer21.Panel1
        '
        Me.SplitContainer21.Panel1.Controls.Add(Me.EPanel26)
        '
        'SplitContainer21.Panel2
        '
        Me.SplitContainer21.Panel2.Controls.Add(Me.EPanel27)
        Me.SplitContainer21.Size = New System.Drawing.Size(584, 506)
        Me.SplitContainer21.SplitterDistance = 378
        Me.SplitContainer21.TabIndex = 0
        '
        'EPanel26
        '
        Me.EPanel26.Controls.Add(Me.gong_rmk1)
        Me.EPanel26.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel26.Location = New System.Drawing.Point(0, 0)
        Me.EPanel26.Name = "EPanel26"
        Me.EPanel26.Size = New System.Drawing.Size(584, 378)
        Me.EPanel26.TabIndex = 2
        Me.EPanel26.Text = "     1공장"
        '
        'gong_rmk1
        '
        Me.gong_rmk1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gong_rmk1.Location = New System.Drawing.Point(2, 23)
        Me.gong_rmk1.Name = "gong_rmk1"
        Me.gong_rmk1.Size = New System.Drawing.Size(580, 353)
        Me.gong_rmk1.TabIndex = 156
        Me.gong_rmk1.Title = ""
        Me.gong_rmk1.TitleWidth = 0
        '
        'EPanel27
        '
        Me.EPanel27.Controls.Add(Me.gong_10)
        Me.EPanel27.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel27.Location = New System.Drawing.Point(0, 0)
        Me.EPanel27.Name = "EPanel27"
        Me.EPanel27.Size = New System.Drawing.Size(584, 124)
        Me.EPanel27.TabIndex = 3
        Me.EPanel27.Text = "     1공장 - 첨부파일"
        '
        'gong_10
        '
        Me.gong_10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gong_10.Location = New System.Drawing.Point(2, 23)
        Me.gong_10.Name = "gong_10"
        Me.gong_10.ReadOnly = False
        Me.gong_10.RowHeight = -1
        Me.gong_10.Size = New System.Drawing.Size(580, 99)
        Me.gong_10.TabIndex = 2
        '
        'SplitContainer22
        '
        Me.SplitContainer22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer22.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer22.Name = "SplitContainer22"
        Me.SplitContainer22.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer22.Panel1
        '
        Me.SplitContainer22.Panel1.Controls.Add(Me.EPanel28)
        '
        'SplitContainer22.Panel2
        '
        Me.SplitContainer22.Panel2.Controls.Add(Me.EPanel29)
        Me.SplitContainer22.Size = New System.Drawing.Size(587, 506)
        Me.SplitContainer22.SplitterDistance = 379
        Me.SplitContainer22.TabIndex = 0
        '
        'EPanel28
        '
        Me.EPanel28.Controls.Add(Me.gong_rmk2)
        Me.EPanel28.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel28.Location = New System.Drawing.Point(0, 0)
        Me.EPanel28.Name = "EPanel28"
        Me.EPanel28.Size = New System.Drawing.Size(587, 379)
        Me.EPanel28.TabIndex = 3
        Me.EPanel28.Text = "     2공장"
        '
        'gong_rmk2
        '
        Me.gong_rmk2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gong_rmk2.Location = New System.Drawing.Point(2, 23)
        Me.gong_rmk2.Name = "gong_rmk2"
        Me.gong_rmk2.Size = New System.Drawing.Size(583, 354)
        Me.gong_rmk2.TabIndex = 156
        Me.gong_rmk2.Title = ""
        Me.gong_rmk2.TitleWidth = 0
        '
        'EPanel29
        '
        Me.EPanel29.Controls.Add(Me.gong_20)
        Me.EPanel29.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel29.Location = New System.Drawing.Point(0, 0)
        Me.EPanel29.Name = "EPanel29"
        Me.EPanel29.Size = New System.Drawing.Size(587, 123)
        Me.EPanel29.TabIndex = 3
        Me.EPanel29.Text = "     2공장 - 첨부파일"
        '
        'gong_20
        '
        Me.gong_20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gong_20.Location = New System.Drawing.Point(2, 23)
        Me.gong_20.Name = "gong_20"
        Me.gong_20.ReadOnly = False
        Me.gong_20.RowHeight = -1
        Me.gong_20.Size = New System.Drawing.Size(583, 98)
        Me.gong_20.TabIndex = 3
        '
        'WI_CO_REMK1100
        '
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "WI_CO_REMK1100"
        Me.Size = New System.Drawing.Size(1182, 611)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        CType(Me.EPanel5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel5.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel2.ResumeLayout(False)
        Me.SplitContainer5.ResumeLayout(False)
        Me.SplitContainer6.Panel1.ResumeLayout(False)
        Me.SplitContainer6.Panel2.ResumeLayout(False)
        Me.SplitContainer6.ResumeLayout(False)
        CType(Me.EPanel6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel6.ResumeLayout(False)
        CType(Me.EPanel7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel7.ResumeLayout(False)
        Me.SplitContainer7.Panel1.ResumeLayout(False)
        Me.SplitContainer7.Panel2.ResumeLayout(False)
        Me.SplitContainer7.ResumeLayout(False)
        CType(Me.EPanel8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel8.ResumeLayout(False)
        CType(Me.EPanel9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel9.ResumeLayout(False)
        Me.XtraTabPage3.ResumeLayout(False)
        Me.SplitContainer8.Panel1.ResumeLayout(False)
        Me.SplitContainer8.Panel2.ResumeLayout(False)
        Me.SplitContainer8.ResumeLayout(False)
        Me.SplitContainer9.Panel1.ResumeLayout(False)
        Me.SplitContainer9.Panel2.ResumeLayout(False)
        Me.SplitContainer9.ResumeLayout(False)
        CType(Me.EPanel10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel10.ResumeLayout(False)
        CType(Me.EPanel11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel11.ResumeLayout(False)
        Me.SplitContainer10.Panel1.ResumeLayout(False)
        Me.SplitContainer10.Panel2.ResumeLayout(False)
        Me.SplitContainer10.ResumeLayout(False)
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel12.ResumeLayout(False)
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel13.ResumeLayout(False)
        Me.XtraTabPage4.ResumeLayout(False)
        Me.SplitContainer11.Panel1.ResumeLayout(False)
        Me.SplitContainer11.Panel2.ResumeLayout(False)
        Me.SplitContainer11.ResumeLayout(False)
        Me.SplitContainer12.Panel1.ResumeLayout(False)
        Me.SplitContainer12.Panel2.ResumeLayout(False)
        Me.SplitContainer12.ResumeLayout(False)
        CType(Me.EPanel14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel14.ResumeLayout(False)
        CType(Me.EPanel15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel15.ResumeLayout(False)
        Me.SplitContainer13.Panel1.ResumeLayout(False)
        Me.SplitContainer13.Panel2.ResumeLayout(False)
        Me.SplitContainer13.ResumeLayout(False)
        CType(Me.EPanel16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel16.ResumeLayout(False)
        CType(Me.EPanel17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel17.ResumeLayout(False)
        Me.XtraTabPage5.ResumeLayout(False)
        Me.SplitContainer14.Panel1.ResumeLayout(False)
        Me.SplitContainer14.Panel2.ResumeLayout(False)
        Me.SplitContainer14.ResumeLayout(False)
        Me.SplitContainer15.Panel1.ResumeLayout(False)
        Me.SplitContainer15.Panel2.ResumeLayout(False)
        Me.SplitContainer15.ResumeLayout(False)
        CType(Me.EPanel18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel18.ResumeLayout(False)
        CType(Me.EPanel19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel19.ResumeLayout(False)
        Me.SplitContainer16.Panel1.ResumeLayout(False)
        Me.SplitContainer16.Panel2.ResumeLayout(False)
        Me.SplitContainer16.ResumeLayout(False)
        CType(Me.EPanel20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel20.ResumeLayout(False)
        CType(Me.EPanel21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel21.ResumeLayout(False)
        Me.XtraTabPage6.ResumeLayout(False)
        Me.SplitContainer17.Panel1.ResumeLayout(False)
        Me.SplitContainer17.Panel2.ResumeLayout(False)
        Me.SplitContainer17.ResumeLayout(False)
        Me.SplitContainer18.Panel1.ResumeLayout(False)
        Me.SplitContainer18.Panel2.ResumeLayout(False)
        Me.SplitContainer18.ResumeLayout(False)
        CType(Me.EPanel22, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel22.ResumeLayout(False)
        CType(Me.EPanel23, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel23.ResumeLayout(False)
        Me.SplitContainer19.Panel1.ResumeLayout(False)
        Me.SplitContainer19.Panel2.ResumeLayout(False)
        Me.SplitContainer19.ResumeLayout(False)
        CType(Me.EPanel24, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel24.ResumeLayout(False)
        CType(Me.EPanel25, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel25.ResumeLayout(False)
        Me.XtraTabPage7.ResumeLayout(False)
        Me.SplitContainer20.Panel1.ResumeLayout(False)
        Me.SplitContainer20.Panel2.ResumeLayout(False)
        Me.SplitContainer20.ResumeLayout(False)
        Me.SplitContainer21.Panel1.ResumeLayout(False)
        Me.SplitContainer21.Panel2.ResumeLayout(False)
        Me.SplitContainer21.ResumeLayout(False)
        CType(Me.EPanel26, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel26.ResumeLayout(False)
        CType(Me.EPanel27, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel27.ResumeLayout(False)
        Me.SplitContainer22.Panel1.ResumeLayout(False)
        Me.SplitContainer22.Panel2.ResumeLayout(False)
        Me.SplitContainer22.ResumeLayout(False)
        CType(Me.EPanel28, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel28.ResumeLayout(False)
        CType(Me.EPanel29, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel29.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel2 As Frame7.ePanel
    Friend WithEvents EPanel4 As Frame7.ePanel
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel3 As Frame7.ePanel
    Friend WithEvents EPanel5 As Frame7.ePanel
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage4 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage5 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage6 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage7 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents sa_10 As Frame7.eGrid
    Friend WithEvents sa_20 As Frame7.eGrid
    Friend WithEvents sa_rmk1 As Frame7.eMemo
    Friend WithEvents sa_rmk2 As Frame7.eMemo
    Friend WithEvents SplitContainer5 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer6 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel6 As Frame7.ePanel
    Friend WithEvents b_rmk1 As Frame7.eMemo
    Friend WithEvents EPanel7 As Frame7.ePanel
    Friend WithEvents b_10 As Frame7.eGrid
    Friend WithEvents SplitContainer7 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel8 As Frame7.ePanel
    Friend WithEvents b_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel9 As Frame7.ePanel
    Friend WithEvents b_20 As Frame7.eGrid
    Friend WithEvents SplitContainer8 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer9 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel10 As Frame7.ePanel
    Friend WithEvents j_rmk1 As Frame7.eMemo
    Friend WithEvents EPanel11 As Frame7.ePanel
    Friend WithEvents j_10 As Frame7.eGrid
    Friend WithEvents SplitContainer10 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel12 As Frame7.ePanel
    Friend WithEvents j_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel13 As Frame7.ePanel
    Friend WithEvents j_20 As Frame7.eGrid
    Friend WithEvents SplitContainer11 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer12 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel14 As Frame7.ePanel
    Friend WithEvents sqc_rmk1 As Frame7.eMemo
    Friend WithEvents EPanel15 As Frame7.ePanel
    Friend WithEvents sqc_10 As Frame7.eGrid
    Friend WithEvents SplitContainer13 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel16 As Frame7.ePanel
    Friend WithEvents sqc_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel17 As Frame7.ePanel
    Friend WithEvents sqc_20 As Frame7.eGrid
    Friend WithEvents SplitContainer14 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer15 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel18 As Frame7.ePanel
    Friend WithEvents jejo_rmk1 As Frame7.eMemo
    Friend WithEvents EPanel19 As Frame7.ePanel
    Friend WithEvents jejo_10 As Frame7.eGrid
    Friend WithEvents SplitContainer16 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel20 As Frame7.ePanel
    Friend WithEvents jejo_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel21 As Frame7.ePanel
    Friend WithEvents jejo_20 As Frame7.eGrid
    Friend WithEvents SplitContainer17 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer18 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel22 As Frame7.ePanel
    Friend WithEvents ch_rmk1 As Frame7.eMemo
    Friend WithEvents EPanel23 As Frame7.ePanel
    Friend WithEvents ch_10 As Frame7.eGrid
    Friend WithEvents SplitContainer19 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel24 As Frame7.ePanel
    Friend WithEvents ch_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel25 As Frame7.ePanel
    Friend WithEvents ch_20 As Frame7.eGrid
    Friend WithEvents SplitContainer20 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer21 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel26 As Frame7.ePanel
    Friend WithEvents EPanel27 As Frame7.ePanel
    Friend WithEvents gong_10 As Frame7.eGrid
    Friend WithEvents SplitContainer22 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel28 As Frame7.ePanel
    Friend WithEvents gong_rmk2 As Frame7.eMemo
    Friend WithEvents EPanel29 As Frame7.ePanel
    Friend WithEvents gong_20 As Frame7.eGrid
    Friend WithEvents gong_rmk1 As Frame7.eMemo
    Friend WithEvents std_month As Frame7.eDate
    Private WithEvents file_save As DevExpress.XtraEditors.SimpleButton

End Class
