﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ESC500
    Inherits Base7.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim XyDiagram1 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series1 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel1 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions1 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim Series2 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel2 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions2 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim SideBySideBarSeriesLabel3 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle1 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram2 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series3 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel4 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim Series4 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel5 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim SideBySideBarSeriesLabel6 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle2 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram3 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series5 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel7 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim Series6 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel8 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim SideBySideBarSeriesLabel9 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle3 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram4 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series7 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel10 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim SideBySideBarSeriesLabel11 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle4 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.chart1_ty = New Frame7.eOptionBox()
        Me.unit_bc = New Frame7.eCombo()
        Me.draw_ty = New Frame7.eOptionBox()
        Me.fr_mon = New Frame7.eDate()
        Me.co_cd = New Frame7.eCombo()
        Me.div_cd = New Frame7.eCombo()
        Me.label_yn = New Frame7.eCheck()
        Me.to_mon = New Frame7.eDate()
        Me.doc_bc = New Frame7.eCombo()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.chart1 = New DevExpress.XtraCharts.ChartControl()
        Me.Chart2 = New DevExpress.XtraCharts.ChartControl()
        Me.g10 = New Frame7.eGrid()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.g20 = New Frame7.eGrid()
        Me.XtraTabPage5 = New DevExpress.XtraTab.XtraTabPage()
        Me.g30 = New Frame7.eGrid()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.Chart4 = New DevExpress.XtraCharts.ChartControl()
        Me.Chart3 = New DevExpress.XtraCharts.ChartControl()
        Me.XtraTabPage4 = New DevExpress.XtraTab.XtraTabPage()
        Me.EGrid1 = New Frame7.eGrid()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage3.SuspendLayout()
        Me.XtraTabPage5.SuspendLayout()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(4, 4)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1064, 644)
        Me.SplitContainer1.SplitterDistance = 78
        Me.SplitContainer1.TabIndex = 7
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.chart1_ty)
        Me.EPanel1.Controls.Add(Me.unit_bc)
        Me.EPanel1.Controls.Add(Me.draw_ty)
        Me.EPanel1.Controls.Add(Me.fr_mon)
        Me.EPanel1.Controls.Add(Me.co_cd)
        Me.EPanel1.Controls.Add(Me.div_cd)
        Me.EPanel1.Controls.Add(Me.label_yn)
        Me.EPanel1.Controls.Add(Me.to_mon)
        Me.EPanel1.Controls.Add(Me.doc_bc)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1064, 78)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     검색"
        '
        'chart1_ty
        '
        Me.chart1_ty.Location = New System.Drawing.Point(228, 50)
        Me.chart1_ty.Name = "chart1_ty"
        Me.chart1_ty.SelectedIndex = -1
        Me.chart1_ty.Size = New System.Drawing.Size(194, 24)
        Me.chart1_ty.TabIndex = 22
        Me.chart1_ty.TitleWidth = 0
        Me.chart1_ty.Visible = False
        '
        'unit_bc
        '
        Me.unit_bc.Location = New System.Drawing.Point(686, 26)
        Me.unit_bc.Name = "unit_bc"
        Me.unit_bc.Size = New System.Drawing.Size(224, 21)
        Me.unit_bc.TabIndex = 3
        Me.unit_bc.Title = "unit_bc"
        '
        'draw_ty
        '
        Me.draw_ty.Location = New System.Drawing.Point(738, 50)
        Me.draw_ty.Name = "draw_ty"
        Me.draw_ty.SelectedIndex = -1
        Me.draw_ty.Size = New System.Drawing.Size(172, 24)
        Me.draw_ty.TabIndex = 14
        Me.draw_ty.TitleWidth = 0
        '
        'fr_mon
        '
        Me.fr_mon.Format = "yyyy-MM"
        Me.fr_mon.Location = New System.Drawing.Point(447, 26)
        Me.fr_mon.Name = "fr_mon"
        Me.fr_mon.Size = New System.Drawing.Size(193, 21)
        Me.fr_mon.TabIndex = 19
        Me.fr_mon.Title = "fr_mon"
        Me.fr_mon.TitleWidth = 90
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(18, 26)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(186, 21)
        Me.co_cd.TabIndex = 1
        Me.co_cd.Title = "co_cd"
        Me.co_cd.TitleWidth = 90
        '
        'div_cd
        '
        Me.div_cd.Location = New System.Drawing.Point(18, 51)
        Me.div_cd.Name = "div_cd"
        Me.div_cd.Size = New System.Drawing.Size(186, 21)
        Me.div_cd.TabIndex = 1
        Me.div_cd.Title = "div_cd"
        Me.div_cd.TitleWidth = 90
        '
        'label_yn
        '
        Me.label_yn.Caption = ""
        Me.label_yn.Location = New System.Drawing.Point(646, 50)
        Me.label_yn.Name = "label_yn"
        Me.label_yn.Size = New System.Drawing.Size(86, 21)
        Me.label_yn.TabIndex = 15
        Me.label_yn.Title = "수치보기"
        Me.label_yn.TitleWidth = 60
        '
        'to_mon
        '
        Me.to_mon.Format = "yyyy-MM"
        Me.to_mon.Location = New System.Drawing.Point(447, 50)
        Me.to_mon.Name = "to_mon"
        Me.to_mon.Size = New System.Drawing.Size(193, 21)
        Me.to_mon.TabIndex = 18
        Me.to_mon.Title = "to_mon"
        Me.to_mon.TitleWidth = 90
        '
        'doc_bc
        '
        Me.doc_bc.Location = New System.Drawing.Point(228, 26)
        Me.doc_bc.Name = "doc_bc"
        Me.doc_bc.Size = New System.Drawing.Size(194, 21)
        Me.doc_bc.TabIndex = 21
        Me.doc_bc.Title = "doc_bc"
        Me.doc_bc.TitleWidth = 90
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1064, 562)
        Me.XtraTabControl1.TabIndex = 5
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage3, Me.XtraTabPage5})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer3)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1057, 532)
        Me.XtraTabPage1.Text = "XtraTabPage1"
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer3.Location = New System.Drawing.Point(4, 4)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.g10)
        Me.SplitContainer3.Size = New System.Drawing.Size(1048, 524)
        Me.SplitContainer3.SplitterDistance = 264
        Me.SplitContainer3.TabIndex = 9
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.chart1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Chart2)
        Me.SplitContainer2.Size = New System.Drawing.Size(1048, 264)
        Me.SplitContainer2.SplitterDistance = 618
        Me.SplitContainer2.TabIndex = 9
        '
        'chart1
        '
        XyDiagram1.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisX.Range.SideMarginsEnabled = True
        XyDiagram1.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram1.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram1.AxisY.NumericOptions.Precision = 0
        XyDiagram1.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisY.Range.SideMarginsEnabled = True
        XyDiagram1.AxisY.VisibleInPanesSerializable = "-1"
        Me.chart1.Diagram = XyDiagram1
        Me.chart1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart1.Location = New System.Drawing.Point(0, 0)
        Me.chart1.Name = "chart1"
        SideBySideBarSeriesLabel1.LineVisible = True
        Series1.Label = SideBySideBarSeriesLabel1
        Series1.Name = "지시"
        PointOptions1.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions1.ValueNumericOptions.Precision = 0
        Series1.PointOptions = PointOptions1
        SideBySideBarSeriesLabel2.LineVisible = True
        Series2.Label = SideBySideBarSeriesLabel2
        Series2.Name = "실적"
        PointOptions2.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions2.ValueNumericOptions.Precision = 0
        Series2.PointOptions = PointOptions2
        Me.chart1.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series1, Series2}
        SideBySideBarSeriesLabel3.LineVisible = True
        Me.chart1.SeriesTemplate.Label = SideBySideBarSeriesLabel3
        Me.chart1.Size = New System.Drawing.Size(618, 264)
        Me.chart1.TabIndex = 2
        ChartTitle1.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle1.Text = "지시 대비 실적"
        ChartTitle1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart1.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle1})
        '
        'Chart2
        '
        Me.Chart2.AppearanceName = "Chameleon"
        XyDiagram2.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram2.AxisX.Range.SideMarginsEnabled = True
        XyDiagram2.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram2.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram2.AxisY.Range.SideMarginsEnabled = True
        XyDiagram2.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram2.DefaultPane.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        XyDiagram2.DefaultPane.Shadow.Visible = True
        Me.Chart2.Diagram = XyDiagram2
        Me.Chart2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Chart2.Legend.TextOffset = 5
        Me.Chart2.Legend.VerticalIndent = 5
        Me.Chart2.Location = New System.Drawing.Point(0, 0)
        Me.Chart2.Name = "Chart2"
        SideBySideBarSeriesLabel4.LineVisible = True
        Series3.Label = SideBySideBarSeriesLabel4
        SideBySideBarSeriesLabel5.LineVisible = True
        Series4.Label = SideBySideBarSeriesLabel5
        Series4.Name = "Series 1"
        Me.Chart2.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series3, Series4}
        SideBySideBarSeriesLabel6.LineVisible = True
        Me.Chart2.SeriesTemplate.Label = SideBySideBarSeriesLabel6
        Me.Chart2.SideBySideBarDistanceVariable = 0.01R
        Me.Chart2.Size = New System.Drawing.Size(426, 264)
        Me.Chart2.TabIndex = 7
        ChartTitle2.Text = "MAKER"
        ChartTitle2.Visible = False
        Me.Chart2.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle2})
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.ReadOnly = False
        Me.g10.RowHeight = -1
        Me.g10.Size = New System.Drawing.Size(1048, 256)
        Me.g10.TabIndex = 3
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.g20)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1057, 532)
        Me.XtraTabPage3.Text = "XtraTabPage3"
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.ReadOnly = False
        Me.g20.RecordNavigator = False
        Me.g20.RowHeight = -1
        Me.g20.Size = New System.Drawing.Size(1057, 532)
        Me.g20.TabIndex = 4
        '
        'XtraTabPage5
        '
        Me.XtraTabPage5.Controls.Add(Me.g30)
        Me.XtraTabPage5.Name = "XtraTabPage5"
        Me.XtraTabPage5.Size = New System.Drawing.Size(1057, 532)
        Me.XtraTabPage5.Text = "XtraTabPage5"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Name = "g30"
        Me.g30.ReadOnly = False
        Me.g30.RecordNavigator = False
        Me.g30.RowHeight = -1
        Me.g30.Size = New System.Drawing.Size(1057, 532)
        Me.g30.TabIndex = 4
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1057, 258)
        '
        'Chart4
        '
        Me.Chart4.AppearanceName = "Chameleon"
        XyDiagram3.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram3.AxisX.Range.SideMarginsEnabled = True
        XyDiagram3.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram3.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram3.AxisY.Range.SideMarginsEnabled = True
        XyDiagram3.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram3.DefaultPane.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        XyDiagram3.DefaultPane.Shadow.Visible = True
        Me.Chart4.Diagram = XyDiagram3
        Me.Chart4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Chart4.Legend.TextOffset = 5
        Me.Chart4.Legend.VerticalIndent = 5
        Me.Chart4.Location = New System.Drawing.Point(0, 0)
        Me.Chart4.Name = "Chart4"
        SideBySideBarSeriesLabel7.LineVisible = True
        Series5.Label = SideBySideBarSeriesLabel7
        SideBySideBarSeriesLabel8.LineVisible = True
        Series6.Label = SideBySideBarSeriesLabel8
        Series6.Name = "Series 1"
        Me.Chart4.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series5, Series6}
        SideBySideBarSeriesLabel9.LineVisible = True
        Me.Chart4.SeriesTemplate.Label = SideBySideBarSeriesLabel9
        Me.Chart4.SideBySideBarDistanceVariable = 0.01R
        Me.Chart4.Size = New System.Drawing.Size(777, 241)
        Me.Chart4.TabIndex = 7
        ChartTitle3.Text = "MAKER"
        ChartTitle3.Visible = False
        Me.Chart4.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle3})
        '
        'Chart3
        '
        Me.Chart3.AppearanceName = "Chameleon"
        XyDiagram4.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram4.AxisX.Range.SideMarginsEnabled = True
        XyDiagram4.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram4.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram4.AxisY.NumericOptions.Precision = 0
        XyDiagram4.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram4.AxisY.Range.SideMarginsEnabled = True
        XyDiagram4.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram4.DefaultPane.BackColor = System.Drawing.Color.Gold
        XyDiagram4.DefaultPane.Shadow.Visible = True
        XyDiagram4.PaneDistance = 4
        Me.Chart3.Diagram = XyDiagram4
        Me.Chart3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Chart3.Legend.TextOffset = 5
        Me.Chart3.Legend.VerticalIndent = 5
        Me.Chart3.Location = New System.Drawing.Point(0, 0)
        Me.Chart3.Name = "Chart3"
        SideBySideBarSeriesLabel10.LineVisible = True
        Series7.Label = SideBySideBarSeriesLabel10
        Me.Chart3.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series7}
        SideBySideBarSeriesLabel11.LineVisible = True
        Me.Chart3.SeriesTemplate.Label = SideBySideBarSeriesLabel11
        Me.Chart3.SideBySideBarDistanceVariable = 0.01R
        Me.Chart3.Size = New System.Drawing.Size(267, 241)
        Me.Chart3.TabIndex = 7
        ChartTitle4.Text = "MAKER"
        ChartTitle4.Visible = False
        Me.Chart3.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle4})
        '
        'XtraTabPage4
        '
        Me.XtraTabPage4.Name = "XtraTabPage4"
        Me.XtraTabPage4.Size = New System.Drawing.Size(0, 0)
        '
        'EGrid1
        '
        Me.EGrid1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EGrid1.Location = New System.Drawing.Point(0, 0)
        Me.EGrid1.Name = "EGrid1"
        Me.EGrid1.ReadOnly = False
        Me.EGrid1.RecordNavigator = False
        Me.EGrid1.RowHeight = -1
        Me.EGrid1.Size = New System.Drawing.Size(1057, 532)
        Me.EGrid1.TabIndex = 5
        '
        'ESC500
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "ESC500"
        Me.Size = New System.Drawing.Size(1199, 730)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage3.ResumeLayout(False)
        Me.XtraTabPage5.ResumeLayout(False)
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(XyDiagram4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents draw_ty As Frame7.eOptionBox
    Friend WithEvents fr_mon As Frame7.eDate
    Friend WithEvents to_mon As Frame7.eDate
    Friend WithEvents co_cd As Frame7.eCombo
    Friend WithEvents unit_bc As Frame7.eCombo
    Friend WithEvents label_yn As Frame7.eCheck
    Friend WithEvents div_cd As Frame7.eCombo
    Friend WithEvents doc_bc As Frame7.eCombo
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents Chart4 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents Chart3 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents XtraTabPage4 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents EGrid1 As Frame7.eGrid
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents Chart2 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents g10 As Frame7.eGrid
    Friend WithEvents XtraTabPage5 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g20 As Frame7.eGrid
    Friend WithEvents g30 As Frame7.eGrid
    Friend WithEvents chart1_ty As Frame7.eOptionBox
    Friend WithEvents chart1 As DevExpress.XtraCharts.ChartControl

End Class
