﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class $safeprojectname$
    Inherits Base7.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim XyDiagram1 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series1 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel1 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions1 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim Series2 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel2 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions2 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim SideBySideBarSeriesLabel3 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle1 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram2 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series3 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel1 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions3 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView1 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim Series4 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel2 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions4 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView2 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim PointSeriesLabel3 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim LineSeriesView3 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim ChartTitle2 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram3 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series5 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel4 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions5 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim Series6 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim SideBySideBarSeriesLabel5 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim PointOptions6 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim SideBySideBarSeriesLabel6 As DevExpress.XtraCharts.SideBySideBarSeriesLabel = New DevExpress.XtraCharts.SideBySideBarSeriesLabel()
        Dim ChartTitle3 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram4 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series7 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel4 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions7 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView4 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim Series8 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel5 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions8 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView5 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim PointSeriesLabel6 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim LineSeriesView6 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim ChartTitle4 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Me.EPanel1 = New Frame7.ePanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.std_dt = New Frame7.eDate()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer12 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer13 = New System.Windows.Forms.SplitContainer()
        Me.EPanel8 = New Frame7.ePanel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.chart1_1 = New DevExpress.XtraCharts.ChartControl()
        Me.EPanel9 = New Frame7.ePanel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.chart1_2 = New DevExpress.XtraCharts.ChartControl()
        Me.EPanel10 = New Frame7.ePanel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.g10 = New Frame7.eGrid()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer14 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer15 = New System.Windows.Forms.SplitContainer()
        Me.EPanel11 = New Frame7.ePanel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.chart2_1 = New DevExpress.XtraCharts.ChartControl()
        Me.EPanel12 = New Frame7.ePanel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.chart2_2 = New DevExpress.XtraCharts.ChartControl()
        Me.EPanel13 = New Frame7.ePanel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.g20 = New Frame7.eGrid()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer12.Panel1.SuspendLayout()
        Me.SplitContainer12.Panel2.SuspendLayout()
        Me.SplitContainer12.SuspendLayout()
        Me.SplitContainer13.Panel1.SuspendLayout()
        Me.SplitContainer13.Panel2.SuspendLayout()
        Me.SplitContainer13.SuspendLayout()
        CType(Me.EPanel8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        CType(Me.chart1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel9.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.chart1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SplitContainer14.Panel1.SuspendLayout()
        Me.SplitContainer14.Panel2.SuspendLayout()
        Me.SplitContainer14.SuspendLayout()
        Me.SplitContainer15.Panel1.SuspendLayout()
        Me.SplitContainer15.Panel2.SuspendLayout()
        Me.SplitContainer15.SuspendLayout()
        CType(Me.EPanel11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel11.SuspendLayout()
        Me.Panel10.SuspendLayout()
        CType(Me.chart2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(SideBySideBarSeriesLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel12.SuspendLayout()
        Me.Panel11.SuspendLayout()
        CType(Me.chart2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel13.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.SuspendLayout()
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.Label1)
        Me.EPanel1.Controls.Add(Me.std_dt)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1194, 58)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     조회조건"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 14)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        Me.Label1.Visible = False
        '
        'std_dt
        '
        Me.std_dt.Location = New System.Drawing.Point(8, 28)
        Me.std_dt.Name = "std_dt"
        Me.std_dt.Size = New System.Drawing.Size(240, 21)
        Me.std_dt.TabIndex = 2
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1194, 690)
        Me.SplitContainer1.SplitterDistance = 58
        Me.SplitContainer1.TabIndex = 0
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1194, 628)
        Me.XtraTabControl1.TabIndex = 1
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer12)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1187, 598)
        Me.XtraTabPage1.Text = "제품군분류(일자별)"
        '
        'SplitContainer12
        '
        Me.SplitContainer12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer12.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer12.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer12.Name = "SplitContainer12"
        Me.SplitContainer12.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer12.Panel1
        '
        Me.SplitContainer12.Panel1.Controls.Add(Me.SplitContainer13)
        '
        'SplitContainer12.Panel2
        '
        Me.SplitContainer12.Panel2.Controls.Add(Me.EPanel10)
        Me.SplitContainer12.Size = New System.Drawing.Size(1187, 598)
        Me.SplitContainer12.SplitterDistance = 350
        Me.SplitContainer12.TabIndex = 2
        '
        'SplitContainer13
        '
        Me.SplitContainer13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer13.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer13.Name = "SplitContainer13"
        '
        'SplitContainer13.Panel1
        '
        Me.SplitContainer13.Panel1.Controls.Add(Me.EPanel8)
        '
        'SplitContainer13.Panel2
        '
        Me.SplitContainer13.Panel2.Controls.Add(Me.EPanel9)
        Me.SplitContainer13.Size = New System.Drawing.Size(1187, 350)
        Me.SplitContainer13.SplitterDistance = 371
        Me.SplitContainer13.TabIndex = 0
        '
        'EPanel8
        '
        Me.EPanel8.Controls.Add(Me.Panel7)
        Me.EPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel8.Location = New System.Drawing.Point(0, 0)
        Me.EPanel8.Name = "EPanel8"
        Me.EPanel8.Size = New System.Drawing.Size(371, 350)
        Me.EPanel8.TabIndex = 0
        Me.EPanel8.Text = "     월별"
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.chart1_1)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(2, 23)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(367, 325)
        Me.Panel7.TabIndex = 2
        '
        'chart1_1
        '
        XyDiagram1.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisX.Range.SideMarginsEnabled = True
        XyDiagram1.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram1.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram1.AxisY.NumericOptions.Precision = 0
        XyDiagram1.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisY.Range.SideMarginsEnabled = True
        XyDiagram1.AxisY.VisibleInPanesSerializable = "-1"
        Me.chart1_1.Diagram = XyDiagram1
        Me.chart1_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart1_1.Location = New System.Drawing.Point(0, 0)
        Me.chart1_1.Name = "chart1_1"
        SideBySideBarSeriesLabel1.LineVisible = True
        Series1.Label = SideBySideBarSeriesLabel1
        Series1.Name = "지시"
        PointOptions1.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions1.ValueNumericOptions.Precision = 0
        Series1.PointOptions = PointOptions1
        SideBySideBarSeriesLabel2.LineVisible = True
        Series2.Label = SideBySideBarSeriesLabel2
        Series2.Name = "실적"
        PointOptions2.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions2.ValueNumericOptions.Precision = 0
        Series2.PointOptions = PointOptions2
        Me.chart1_1.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series1, Series2}
        SideBySideBarSeriesLabel3.LineVisible = True
        Me.chart1_1.SeriesTemplate.Label = SideBySideBarSeriesLabel3
        Me.chart1_1.Size = New System.Drawing.Size(367, 325)
        Me.chart1_1.TabIndex = 1
        ChartTitle1.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle1.Text = "제품군별  지시 대비 실적"
        ChartTitle1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart1_1.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle1})
        '
        'EPanel9
        '
        Me.EPanel9.Controls.Add(Me.Panel8)
        Me.EPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel9.Location = New System.Drawing.Point(0, 0)
        Me.EPanel9.Name = "EPanel9"
        Me.EPanel9.Size = New System.Drawing.Size(812, 350)
        Me.EPanel9.TabIndex = 0
        Me.EPanel9.Text = "     일별"
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.chart1_2)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(2, 23)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(808, 325)
        Me.Panel8.TabIndex = 2
        '
        'chart1_2
        '
        XyDiagram2.AxisX.Label.Angle = -45
        XyDiagram2.AxisX.Label.Antialiasing = True
        XyDiagram2.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram2.AxisX.Range.SideMarginsEnabled = True
        XyDiagram2.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram2.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram2.AxisY.NumericOptions.Precision = 0
        XyDiagram2.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram2.AxisY.Range.SideMarginsEnabled = True
        XyDiagram2.AxisY.VisibleInPanesSerializable = "-1"
        Me.chart1_2.Diagram = XyDiagram2
        Me.chart1_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart1_2.EmptyChartText.Font = New System.Drawing.Font("맑은 고딕", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.chart1_2.EmptyChartText.Text = "조회할 데이터가 없습니다."
        Me.chart1_2.EmptyChartText.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart1_2.Location = New System.Drawing.Point(0, 0)
        Me.chart1_2.Name = "chart1_2"
        Me.chart1_2.PaletteName = "Metro"
        PointSeriesLabel1.LineVisible = True
        Series3.Label = PointSeriesLabel1
        Series3.Name = "Series 1"
        PointOptions3.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions3.ValueNumericOptions.Precision = 0
        Series3.PointOptions = PointOptions3
        Series3.View = LineSeriesView1
        PointSeriesLabel2.LineVisible = True
        Series4.Label = PointSeriesLabel2
        Series4.Name = "Series 2"
        PointOptions4.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions4.ValueNumericOptions.Precision = 0
        Series4.PointOptions = PointOptions4
        LineSeriesView2.LineMarkerOptions.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView2.LineMarkerOptions.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView2.LineMarkerOptions.FillStyle.FillMode = DevExpress.XtraCharts.FillMode.Solid
        LineSeriesView2.LineMarkerOptions.Kind = DevExpress.XtraCharts.MarkerKind.Hexagon
        LineSeriesView2.LineMarkerOptions.Size = 13
        Series4.View = LineSeriesView2
        Me.chart1_2.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series3, Series4}
        PointSeriesLabel3.LineVisible = True
        Me.chart1_2.SeriesTemplate.Label = PointSeriesLabel3
        Me.chart1_2.SeriesTemplate.View = LineSeriesView3
        Me.chart1_2.Size = New System.Drawing.Size(808, 325)
        Me.chart1_2.TabIndex = 4
        ChartTitle2.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle2.Text = "제품군별 일 실적 추이"
        ChartTitle2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart1_2.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle2})
        '
        'EPanel10
        '
        Me.EPanel10.Controls.Add(Me.Panel9)
        Me.EPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel10.Location = New System.Drawing.Point(0, 0)
        Me.EPanel10.Name = "EPanel10"
        Me.EPanel10.Size = New System.Drawing.Size(1187, 244)
        Me.EPanel10.TabIndex = 0
        Me.EPanel10.Text = "     일별 생산실적"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.g10)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel9.Location = New System.Drawing.Point(2, 23)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1183, 219)
        Me.Panel9.TabIndex = 2
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.ReadOnly = False
        Me.g10.RecordNavigator = False
        Me.g10.RowHeight = -1
        Me.g10.Size = New System.Drawing.Size(1183, 219)
        Me.g10.TabIndex = 0
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.SplitContainer14)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1187, 598)
        Me.XtraTabPage2.Text = "제품군분류(월별)"
        '
        'SplitContainer14
        '
        Me.SplitContainer14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer14.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer14.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer14.Name = "SplitContainer14"
        Me.SplitContainer14.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer14.Panel1
        '
        Me.SplitContainer14.Panel1.Controls.Add(Me.SplitContainer15)
        '
        'SplitContainer14.Panel2
        '
        Me.SplitContainer14.Panel2.Controls.Add(Me.EPanel13)
        Me.SplitContainer14.Size = New System.Drawing.Size(1187, 598)
        Me.SplitContainer14.SplitterDistance = 350
        Me.SplitContainer14.TabIndex = 2
        '
        'SplitContainer15
        '
        Me.SplitContainer15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer15.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer15.Name = "SplitContainer15"
        '
        'SplitContainer15.Panel1
        '
        Me.SplitContainer15.Panel1.Controls.Add(Me.EPanel11)
        '
        'SplitContainer15.Panel2
        '
        Me.SplitContainer15.Panel2.Controls.Add(Me.EPanel12)
        Me.SplitContainer15.Size = New System.Drawing.Size(1187, 350)
        Me.SplitContainer15.SplitterDistance = 369
        Me.SplitContainer15.TabIndex = 0
        '
        'EPanel11
        '
        Me.EPanel11.Controls.Add(Me.Panel10)
        Me.EPanel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel11.Location = New System.Drawing.Point(0, 0)
        Me.EPanel11.Name = "EPanel11"
        Me.EPanel11.Size = New System.Drawing.Size(369, 350)
        Me.EPanel11.TabIndex = 0
        Me.EPanel11.Text = "     년간"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.chart2_1)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(2, 23)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(365, 325)
        Me.Panel10.TabIndex = 2
        '
        'chart2_1
        '
        XyDiagram3.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram3.AxisX.Range.SideMarginsEnabled = True
        XyDiagram3.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram3.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram3.AxisY.NumericOptions.Precision = 0
        XyDiagram3.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram3.AxisY.Range.SideMarginsEnabled = True
        XyDiagram3.AxisY.VisibleInPanesSerializable = "-1"
        Me.chart2_1.Diagram = XyDiagram3
        Me.chart2_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart2_1.Location = New System.Drawing.Point(0, 0)
        Me.chart2_1.Name = "chart2_1"
        SideBySideBarSeriesLabel4.LineVisible = True
        Series5.Label = SideBySideBarSeriesLabel4
        Series5.Name = "지시"
        PointOptions5.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions5.ValueNumericOptions.Precision = 0
        Series5.PointOptions = PointOptions5
        SideBySideBarSeriesLabel5.LineVisible = True
        Series6.Label = SideBySideBarSeriesLabel5
        Series6.Name = "실적"
        PointOptions6.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions6.ValueNumericOptions.Precision = 0
        Series6.PointOptions = PointOptions6
        Me.chart2_1.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series5, Series6}
        SideBySideBarSeriesLabel6.LineVisible = True
        Me.chart2_1.SeriesTemplate.Label = SideBySideBarSeriesLabel6
        Me.chart2_1.Size = New System.Drawing.Size(365, 325)
        Me.chart2_1.TabIndex = 1
        ChartTitle3.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle3.Text = "제품군별  지시 대비 실적"
        ChartTitle3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_1.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle3})
        '
        'EPanel12
        '
        Me.EPanel12.Controls.Add(Me.Panel11)
        Me.EPanel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel12.Location = New System.Drawing.Point(0, 0)
        Me.EPanel12.Name = "EPanel12"
        Me.EPanel12.Size = New System.Drawing.Size(814, 350)
        Me.EPanel12.TabIndex = 0
        Me.EPanel12.Text = "     월별"
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.chart2_2)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(2, 23)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(810, 325)
        Me.Panel11.TabIndex = 2
        '
        'chart2_2
        '
        XyDiagram4.AxisX.Label.Angle = -45
        XyDiagram4.AxisX.Label.Antialiasing = True
        XyDiagram4.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram4.AxisX.Range.SideMarginsEnabled = True
        XyDiagram4.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram4.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram4.AxisY.NumericOptions.Precision = 0
        XyDiagram4.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram4.AxisY.Range.SideMarginsEnabled = True
        XyDiagram4.AxisY.VisibleInPanesSerializable = "-1"
        Me.chart2_2.Diagram = XyDiagram4
        Me.chart2_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart2_2.EmptyChartText.Font = New System.Drawing.Font("맑은 고딕", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.chart2_2.EmptyChartText.Text = "조회할 데이터가 없습니다."
        Me.chart2_2.EmptyChartText.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_2.Location = New System.Drawing.Point(0, 0)
        Me.chart2_2.Name = "chart2_2"
        Me.chart2_2.PaletteName = "Metro"
        PointSeriesLabel4.LineVisible = True
        Series7.Label = PointSeriesLabel4
        Series7.Name = "Series 1"
        PointOptions7.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions7.ValueNumericOptions.Precision = 0
        Series7.PointOptions = PointOptions7
        Series7.View = LineSeriesView4
        PointSeriesLabel5.LineVisible = True
        Series8.Label = PointSeriesLabel5
        Series8.Name = "Series 2"
        PointOptions8.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions8.ValueNumericOptions.Precision = 0
        Series8.PointOptions = PointOptions8
        LineSeriesView5.LineMarkerOptions.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView5.LineMarkerOptions.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView5.LineMarkerOptions.FillStyle.FillMode = DevExpress.XtraCharts.FillMode.Solid
        LineSeriesView5.LineMarkerOptions.Kind = DevExpress.XtraCharts.MarkerKind.Hexagon
        LineSeriesView5.LineMarkerOptions.Size = 13
        Series8.View = LineSeriesView5
        Me.chart2_2.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series7, Series8}
        PointSeriesLabel6.LineVisible = True
        Me.chart2_2.SeriesTemplate.Label = PointSeriesLabel6
        Me.chart2_2.SeriesTemplate.View = LineSeriesView6
        Me.chart2_2.Size = New System.Drawing.Size(810, 325)
        Me.chart2_2.TabIndex = 4
        ChartTitle4.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle4.Text = "제품군별 월별 실적 추이"
        ChartTitle4.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_2.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle4})
        '
        'EPanel13
        '
        Me.EPanel13.Controls.Add(Me.Panel12)
        Me.EPanel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel13.Location = New System.Drawing.Point(0, 0)
        Me.EPanel13.Name = "EPanel13"
        Me.EPanel13.Size = New System.Drawing.Size(1187, 244)
        Me.EPanel13.TabIndex = 0
        Me.EPanel13.Text = "     월별 생산실적"
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.g20)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(2, 23)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1183, 219)
        Me.Panel12.TabIndex = 2
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.ReadOnly = False
        Me.g20.RecordNavigator = False
        Me.g20.RowHeight = -1
        Me.g20.Size = New System.Drawing.Size(1183, 219)
        Me.g20.TabIndex = 0
        '
        '$safeprojectname$
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "$safeprojectname$"
        Me.Size = New System.Drawing.Size(1194, 690)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.EPanel1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer12.Panel1.ResumeLayout(False)
        Me.SplitContainer12.Panel2.ResumeLayout(False)
        Me.SplitContainer12.ResumeLayout(False)
        Me.SplitContainer13.Panel1.ResumeLayout(False)
        Me.SplitContainer13.Panel2.ResumeLayout(False)
        Me.SplitContainer13.ResumeLayout(False)
        CType(Me.EPanel8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel8.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel9.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel10.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.SplitContainer14.Panel1.ResumeLayout(False)
        Me.SplitContainer14.Panel2.ResumeLayout(False)
        Me.SplitContainer14.ResumeLayout(False)
        Me.SplitContainer15.Panel1.ResumeLayout(False)
        Me.SplitContainer15.Panel2.ResumeLayout(False)
        Me.SplitContainer15.ResumeLayout(False)
        CType(Me.EPanel11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel11.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(SideBySideBarSeriesLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel12.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        CType(XyDiagram4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel13.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer12 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer13 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel8 As Frame7.ePanel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents chart1_1 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents EPanel9 As Frame7.ePanel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents chart1_2 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents EPanel10 As Frame7.ePanel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents g10 As Frame7.eGrid
    Friend WithEvents SplitContainer14 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer15 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel11 As Frame7.ePanel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents chart2_1 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents EPanel12 As Frame7.ePanel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents chart2_2 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents EPanel13 As Frame7.ePanel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents g20 As Frame7.eGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents std_dt As Frame7.eDate

End Class
