﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAB101
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.f_stat_bc = New Frame7.eCheckCombo()
        Me.div_cd = New Frame7.eCheckCombo()
        Me.doc_no = New Frame7.eText()
        Me.co_cd = New Frame7.eCombo()
        Me.fr_dt = New Frame7.eDate()
        Me.doc_bc = New Frame7.eCheckCombo()
        Me.cust_nm = New Frame7.eText()
        Me.apr_no = New Frame7.eText()
        Me.to_dt = New Frame7.eDate()
        Me.stat_bc = New Frame7.eCheckCombo()
        Me.to_apr_dt = New Frame7.eDate()
        Me.fr_apr_dt = New Frame7.eDate()
        Me.cust_cd = New Frame7.eText()
        Me.fr_amt1 = New Frame7.eText()
        Me.doc_rid = New Frame7.eText()
        Me.to_amt1 = New Frame7.eText()
        Me.dsc2 = New Frame7.eText()
        Me.fr_amt2 = New Frame7.eText()
        Me.dept_cd = New Frame7.eText()
        Me.to_amt2 = New Frame7.eText()
        Me.dept_nm = New Frame7.eText()
        Me.to_acc_cd = New Frame7.eText()
        Me.g_dept_nm = New Frame7.eText()
        Me.g_dept_cd = New Frame7.eText()
        Me.acc_cd = New Frame7.eText()
        Me.doc_id = New Frame7.eText()
        Me.fr_acc_cd = New Frame7.eText()
        Me.f_rmks = New Frame7.eText()
        Me.doc_nm = New Frame7.eText()
        Me.dsc1 = New Frame7.eText()
        Me.acc_nm = New Frame7.eText()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.XtraTabControl2 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.chk_all = New DevExpress.XtraEditors.CheckEdit()
        Me.g10 = New Frame7.eGrid()
        Me.g20 = New Frame7.eGrid()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g30 = New Frame7.eGrid()
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton()
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton()
        Me.ECombo4 = New Frame7.eCombo()
        Me.ECombo3 = New Frame7.eCombo()
        Me.EText6 = New Frame7.eText()
        Me.EText4 = New Frame7.eText()
        Me.EText5 = New Frame7.eText()
        Me.EText3 = New Frame7.eText()
        Me.EText2 = New Frame7.eText()
        Me.EDate1 = New Frame7.eDate()
        Me.ECombo2 = New Frame7.eCombo()
        Me.EText1 = New Frame7.eText()
        Me.ECombo1 = New Frame7.eCombo()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl2.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.chk_all.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(1209, 636)
        Me.SplitContainer2.SplitterDistance = 178
        Me.SplitContainer2.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.f_stat_bc)
        Me.EPanel1.Controls.Add(Me.div_cd)
        Me.EPanel1.Controls.Add(Me.doc_no)
        Me.EPanel1.Controls.Add(Me.co_cd)
        Me.EPanel1.Controls.Add(Me.fr_dt)
        Me.EPanel1.Controls.Add(Me.doc_bc)
        Me.EPanel1.Controls.Add(Me.cust_nm)
        Me.EPanel1.Controls.Add(Me.apr_no)
        Me.EPanel1.Controls.Add(Me.to_dt)
        Me.EPanel1.Controls.Add(Me.stat_bc)
        Me.EPanel1.Controls.Add(Me.to_apr_dt)
        Me.EPanel1.Controls.Add(Me.fr_apr_dt)
        Me.EPanel1.Controls.Add(Me.cust_cd)
        Me.EPanel1.Controls.Add(Me.fr_amt1)
        Me.EPanel1.Controls.Add(Me.doc_rid)
        Me.EPanel1.Controls.Add(Me.to_amt1)
        Me.EPanel1.Controls.Add(Me.dsc2)
        Me.EPanel1.Controls.Add(Me.fr_amt2)
        Me.EPanel1.Controls.Add(Me.dept_cd)
        Me.EPanel1.Controls.Add(Me.to_amt2)
        Me.EPanel1.Controls.Add(Me.dept_nm)
        Me.EPanel1.Controls.Add(Me.to_acc_cd)
        Me.EPanel1.Controls.Add(Me.g_dept_nm)
        Me.EPanel1.Controls.Add(Me.g_dept_cd)
        Me.EPanel1.Controls.Add(Me.acc_cd)
        Me.EPanel1.Controls.Add(Me.doc_id)
        Me.EPanel1.Controls.Add(Me.fr_acc_cd)
        Me.EPanel1.Controls.Add(Me.f_rmks)
        Me.EPanel1.Controls.Add(Me.doc_nm)
        Me.EPanel1.Controls.Add(Me.dsc1)
        Me.EPanel1.Controls.Add(Me.acc_nm)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1209, 178)
        Me.EPanel1.TabIndex = 1
        Me.EPanel1.Text = "     검색"
        '
        'f_stat_bc
        '
        Me.f_stat_bc.Location = New System.Drawing.Point(644, 28)
        Me.f_stat_bc.Name = "f_stat_bc"
        Me.f_stat_bc.Size = New System.Drawing.Size(376, 21)
        Me.f_stat_bc.TabIndex = 53
        Me.f_stat_bc.Title = "재직여부"
        '
        'div_cd
        '
        Me.div_cd.Location = New System.Drawing.Point(12, 52)
        Me.div_cd.Name = "div_cd"
        Me.div_cd.Size = New System.Drawing.Size(240, 21)
        Me.div_cd.TabIndex = 49
        Me.div_cd.Title = "div_cd"
        '
        'doc_no
        '
        Me.doc_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.doc_no.Location = New System.Drawing.Point(12, 76)
        Me.doc_no.Name = "doc_no"
        Me.doc_no.Size = New System.Drawing.Size(240, 21)
        Me.doc_no.TabIndex = 21
        Me.doc_no.Title = "전표번호(%)"
        '
        'co_cd
        '
        Me.co_cd.Location = New System.Drawing.Point(12, 28)
        Me.co_cd.Name = "co_cd"
        Me.co_cd.Size = New System.Drawing.Size(240, 21)
        Me.co_cd.TabIndex = 3
        Me.co_cd.Title = "법인명"
        '
        'fr_dt
        '
        Me.fr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.fr_dt.Location = New System.Drawing.Point(260, 28)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(240, 21)
        Me.fr_dt.TabIndex = 14
        Me.fr_dt.Title = "발의일자"
        '
        'doc_bc
        '
        Me.doc_bc.Location = New System.Drawing.Point(12, 148)
        Me.doc_bc.Name = "doc_bc"
        Me.doc_bc.Size = New System.Drawing.Size(240, 21)
        Me.doc_bc.TabIndex = 39
        Me.doc_bc.Title = "doc_bc"
        '
        'cust_nm
        '
        Me.cust_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.cust_nm.Location = New System.Drawing.Point(888, 100)
        Me.cust_nm.Name = "cust_nm"
        Me.cust_nm.Size = New System.Drawing.Size(132, 21)
        Me.cust_nm.TabIndex = 52
        Me.cust_nm.Title = ""
        Me.cust_nm.TitleWidth = 0
        '
        'apr_no
        '
        Me.apr_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.apr_no.Location = New System.Drawing.Point(12, 100)
        Me.apr_no.Name = "apr_no"
        Me.apr_no.Size = New System.Drawing.Size(240, 21)
        Me.apr_no.TabIndex = 21
        Me.apr_no.Title = "승인번호(%)"
        '
        'to_dt
        '
        Me.to_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_dt.Location = New System.Drawing.Point(504, 28)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(132, 21)
        Me.to_dt.TabIndex = 15
        Me.to_dt.Title = "~"
        Me.to_dt.TitleWidth = 10
        '
        'stat_bc
        '
        Me.stat_bc.Location = New System.Drawing.Point(12, 124)
        Me.stat_bc.Name = "stat_bc"
        Me.stat_bc.Size = New System.Drawing.Size(240, 21)
        Me.stat_bc.TabIndex = 39
        Me.stat_bc.Title = "stat_bc"
        '
        'to_apr_dt
        '
        Me.to_apr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_apr_dt.Location = New System.Drawing.Point(504, 52)
        Me.to_apr_dt.Name = "to_apr_dt"
        Me.to_apr_dt.Size = New System.Drawing.Size(132, 21)
        Me.to_apr_dt.TabIndex = 17
        Me.to_apr_dt.Title = "~"
        Me.to_apr_dt.TitleWidth = 10
        '
        'fr_apr_dt
        '
        Me.fr_apr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.fr_apr_dt.Location = New System.Drawing.Point(260, 52)
        Me.fr_apr_dt.Name = "fr_apr_dt"
        Me.fr_apr_dt.Size = New System.Drawing.Size(240, 21)
        Me.fr_apr_dt.TabIndex = 16
        Me.fr_apr_dt.Title = "승인일자"
        '
        'cust_cd
        '
        Me.cust_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.cust_cd.Location = New System.Drawing.Point(644, 100)
        Me.cust_cd.Name = "cust_cd"
        Me.cust_cd.Size = New System.Drawing.Size(240, 21)
        Me.cust_cd.TabIndex = 51
        Me.cust_cd.Title = "거래처"
        '
        'fr_amt1
        '
        Me.fr_amt1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.fr_amt1.Location = New System.Drawing.Point(260, 100)
        Me.fr_amt1.Name = "fr_amt1"
        Me.fr_amt1.Size = New System.Drawing.Size(240, 21)
        Me.fr_amt1.TabIndex = 24
        Me.fr_amt1.Title = "차변금액"
        '
        'doc_rid
        '
        Me.doc_rid.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.doc_rid.Location = New System.Drawing.Point(1040, 56)
        Me.doc_rid.Name = "doc_rid"
        Me.doc_rid.Size = New System.Drawing.Size(68, 21)
        Me.doc_rid.TabIndex = 18
        Me.doc_rid.Title = "doc_rid"
        '
        'to_amt1
        '
        Me.to_amt1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_amt1.Location = New System.Drawing.Point(504, 100)
        Me.to_amt1.Name = "to_amt1"
        Me.to_amt1.Size = New System.Drawing.Size(132, 21)
        Me.to_amt1.TabIndex = 26
        Me.to_amt1.Title = "~"
        Me.to_amt1.TitleWidth = 10
        '
        'dsc2
        '
        Me.dsc2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dsc2.Location = New System.Drawing.Point(888, 124)
        Me.dsc2.Name = "dsc2"
        Me.dsc2.Size = New System.Drawing.Size(132, 21)
        Me.dsc2.TabIndex = 50
        Me.dsc2.Title = "/"
        Me.dsc2.TitleWidth = 10
        '
        'fr_amt2
        '
        Me.fr_amt2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.fr_amt2.Location = New System.Drawing.Point(260, 124)
        Me.fr_amt2.Name = "fr_amt2"
        Me.fr_amt2.Size = New System.Drawing.Size(240, 21)
        Me.fr_amt2.TabIndex = 24
        Me.fr_amt2.Title = "대변금액"
        '
        'dept_cd
        '
        Me.dept_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dept_cd.Location = New System.Drawing.Point(1044, 83)
        Me.dept_cd.Name = "dept_cd"
        Me.dept_cd.Size = New System.Drawing.Size(240, 21)
        Me.dept_cd.TabIndex = 8
        Me.dept_cd.Title = "발의부서"
        '
        'to_amt2
        '
        Me.to_amt2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_amt2.Location = New System.Drawing.Point(504, 124)
        Me.to_amt2.Name = "to_amt2"
        Me.to_amt2.Size = New System.Drawing.Size(132, 21)
        Me.to_amt2.TabIndex = 26
        Me.to_amt2.Title = "~"
        Me.to_amt2.TitleWidth = 10
        '
        'dept_nm
        '
        Me.dept_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dept_nm.Location = New System.Drawing.Point(1288, 83)
        Me.dept_nm.Name = "dept_nm"
        Me.dept_nm.Size = New System.Drawing.Size(132, 21)
        Me.dept_nm.TabIndex = 29
        Me.dept_nm.Title = "발의부서명"
        Me.dept_nm.TitleWidth = 0
        '
        'to_acc_cd
        '
        Me.to_acc_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_acc_cd.Location = New System.Drawing.Point(504, 76)
        Me.to_acc_cd.Name = "to_acc_cd"
        Me.to_acc_cd.Size = New System.Drawing.Size(132, 21)
        Me.to_acc_cd.TabIndex = 26
        Me.to_acc_cd.Title = "~"
        Me.to_acc_cd.TitleWidth = 10
        '
        'g_dept_nm
        '
        Me.g_dept_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.g_dept_nm.Location = New System.Drawing.Point(888, 148)
        Me.g_dept_nm.Name = "g_dept_nm"
        Me.g_dept_nm.Size = New System.Drawing.Size(132, 21)
        Me.g_dept_nm.TabIndex = 29
        Me.g_dept_nm.Title = "발의부서명"
        Me.g_dept_nm.TitleWidth = 0
        '
        'g_dept_cd
        '
        Me.g_dept_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.g_dept_cd.Location = New System.Drawing.Point(644, 148)
        Me.g_dept_cd.Name = "g_dept_cd"
        Me.g_dept_cd.Size = New System.Drawing.Size(240, 21)
        Me.g_dept_cd.TabIndex = 8
        Me.g_dept_cd.Title = "귀속부서"
        '
        'acc_cd
        '
        Me.acc_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.acc_cd.Location = New System.Drawing.Point(644, 76)
        Me.acc_cd.Name = "acc_cd"
        Me.acc_cd.Size = New System.Drawing.Size(240, 21)
        Me.acc_cd.TabIndex = 24
        Me.acc_cd.Title = "계정코드"
        '
        'doc_id
        '
        Me.doc_id.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.doc_id.Location = New System.Drawing.Point(644, 52)
        Me.doc_id.Name = "doc_id"
        Me.doc_id.Size = New System.Drawing.Size(240, 21)
        Me.doc_id.TabIndex = 18
        Me.doc_id.Title = "발의자"
        '
        'fr_acc_cd
        '
        Me.fr_acc_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.fr_acc_cd.Location = New System.Drawing.Point(260, 76)
        Me.fr_acc_cd.Name = "fr_acc_cd"
        Me.fr_acc_cd.Size = New System.Drawing.Size(240, 21)
        Me.fr_acc_cd.TabIndex = 24
        Me.fr_acc_cd.Title = "계정구간"
        '
        'f_rmks
        '
        Me.f_rmks.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_rmks.Location = New System.Drawing.Point(413, 148)
        Me.f_rmks.Name = "f_rmks"
        Me.f_rmks.Size = New System.Drawing.Size(223, 21)
        Me.f_rmks.TabIndex = 8
        Me.f_rmks.Title = "(귀속부서는 전표 상세정보에서 조회됨)"
        Me.f_rmks.TitleWidth = 300
        '
        'doc_nm
        '
        Me.doc_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.doc_nm.Location = New System.Drawing.Point(888, 52)
        Me.doc_nm.Name = "doc_nm"
        Me.doc_nm.Size = New System.Drawing.Size(132, 21)
        Me.doc_nm.TabIndex = 30
        Me.doc_nm.Title = "발의자명"
        Me.doc_nm.TitleWidth = 0
        '
        'dsc1
        '
        Me.dsc1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dsc1.Location = New System.Drawing.Point(644, 124)
        Me.dsc1.Name = "dsc1"
        Me.dsc1.Size = New System.Drawing.Size(240, 21)
        Me.dsc1.TabIndex = 10
        Me.dsc1.Title = "행적요/관리적요"
        '
        'acc_nm
        '
        Me.acc_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.acc_nm.Location = New System.Drawing.Point(888, 76)
        Me.acc_nm.Name = "acc_nm"
        Me.acc_nm.Size = New System.Drawing.Size(132, 21)
        Me.acc_nm.TabIndex = 31
        Me.acc_nm.Title = "발의부서명"
        Me.acc_nm.TitleWidth = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.XtraTabControl2)
        Me.SplitContainer3.Panel2Collapsed = True
        Me.SplitContainer3.Size = New System.Drawing.Size(1209, 454)
        Me.SplitContainer3.SplitterDistance = 220
        Me.SplitContainer3.TabIndex = 0
        '
        'XtraTabControl2
        '
        Me.XtraTabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl2.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl2.Name = "XtraTabControl2"
        Me.XtraTabControl2.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl2.Size = New System.Drawing.Size(1209, 454)
        Me.XtraTabControl2.TabIndex = 3
        Me.XtraTabControl2.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer4)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1202, 424)
        Me.XtraTabPage1.Text = "전표정보"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.chk_all)
        Me.SplitContainer4.Panel1.Controls.Add(Me.g10)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.g20)
        Me.SplitContainer4.Size = New System.Drawing.Size(1202, 424)
        Me.SplitContainer4.SplitterDistance = 216
        Me.SplitContainer4.TabIndex = 0
        '
        'chk_all
        '
        Me.chk_all.Location = New System.Drawing.Point(32, 3)
        Me.chk_all.Name = "chk_all"
        Me.chk_all.Properties.Caption = "CheckEdit1"
        Me.chk_all.Size = New System.Drawing.Size(18, 19)
        Me.chk_all.TabIndex = 1
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.ReadOnly = False
        Me.g10.RowHeight = -1
        Me.g10.Size = New System.Drawing.Size(1202, 216)
        Me.g10.TabIndex = 0
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.ReadOnly = False
        Me.g20.RowHeight = -1
        Me.g20.Size = New System.Drawing.Size(1202, 204)
        Me.g20.TabIndex = 0
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g30)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1202, 424)
        Me.XtraTabPage2.Text = "전표상세정보"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Name = "g30"
        Me.g30.ReadOnly = False
        Me.g30.RecordNavigator = False
        Me.g30.RowHeight = -1
        Me.g30.Size = New System.Drawing.Size(1202, 424)
        Me.g30.TabIndex = 0
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Location = New System.Drawing.Point(776, 84)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(112, 24)
        Me.SimpleButton1.TabIndex = 14
        Me.SimpleButton1.Text = "새전표로 복사"
        '
        'SimpleButton2
        '
        Me.SimpleButton2.Location = New System.Drawing.Point(648, 84)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(112, 24)
        Me.SimpleButton2.TabIndex = 13
        Me.SimpleButton2.Text = "견본전표로 저장"
        '
        'ECombo4
        '
        Me.ECombo4.Location = New System.Drawing.Point(648, 28)
        Me.ECombo4.Name = "ECombo4"
        Me.ECombo4.Size = New System.Drawing.Size(240, 21)
        Me.ECombo4.TabIndex = 12
        Me.ECombo4.Title = "전표유형"
        '
        'ECombo3
        '
        Me.ECombo3.Location = New System.Drawing.Point(648, 52)
        Me.ECombo3.Name = "ECombo3"
        Me.ECombo3.Size = New System.Drawing.Size(240, 21)
        Me.ECombo3.TabIndex = 11
        Me.ECombo3.Title = "진행상태"
        '
        'EText6
        '
        Me.EText6.Location = New System.Drawing.Point(12, 100)
        Me.EText6.Name = "EText6"
        Me.EText6.Size = New System.Drawing.Size(496, 21)
        Me.EText6.TabIndex = 10
        Me.EText6.Title = "발의내용"
        '
        'EText4
        '
        Me.EText4.Location = New System.Drawing.Point(512, 76)
        Me.EText4.Name = "EText4"
        Me.EText4.Size = New System.Drawing.Size(120, 21)
        Me.EText4.TabIndex = 9
        Me.EText4.TitleWidth = 0
        '
        'EText5
        '
        Me.EText5.Location = New System.Drawing.Point(268, 76)
        Me.EText5.Name = "EText5"
        Me.EText5.Size = New System.Drawing.Size(240, 21)
        Me.EText5.TabIndex = 8
        Me.EText5.Title = "발의자"
        '
        'EText3
        '
        Me.EText3.Location = New System.Drawing.Point(512, 52)
        Me.EText3.Name = "EText3"
        Me.EText3.Size = New System.Drawing.Size(120, 21)
        Me.EText3.TabIndex = 7
        Me.EText3.TitleWidth = 0
        '
        'EText2
        '
        Me.EText2.Location = New System.Drawing.Point(268, 52)
        Me.EText2.Name = "EText2"
        Me.EText2.Size = New System.Drawing.Size(240, 21)
        Me.EText2.TabIndex = 6
        Me.EText2.Title = "발의부서"
        '
        'EDate1
        '
        Me.EDate1.Location = New System.Drawing.Point(268, 28)
        Me.EDate1.Name = "EDate1"
        Me.EDate1.Size = New System.Drawing.Size(240, 21)
        Me.EDate1.TabIndex = 5
        Me.EDate1.Title = "발의일자"
        '
        'ECombo2
        '
        Me.ECombo2.Location = New System.Drawing.Point(12, 76)
        Me.ECombo2.Name = "ECombo2"
        Me.ECombo2.Size = New System.Drawing.Size(240, 21)
        Me.ECombo2.TabIndex = 4
        Me.ECombo2.Title = "사업장명"
        '
        'EText1
        '
        Me.EText1.Location = New System.Drawing.Point(12, 28)
        Me.EText1.Name = "EText1"
        Me.EText1.Size = New System.Drawing.Size(240, 21)
        Me.EText1.TabIndex = 2
        Me.EText1.Title = "전표번호"
        '
        'ECombo1
        '
        Me.ECombo1.Location = New System.Drawing.Point(12, 52)
        Me.ECombo1.Name = "ECombo1"
        Me.ECombo1.Size = New System.Drawing.Size(240, 21)
        Me.ECombo1.TabIndex = 3
        Me.ECombo1.Title = "법인명"
        '
        'FAB101
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.Controls.Add(Me.SplitContainer2)
        Me.Name = "FAB101"
        Me.Size = New System.Drawing.Size(1209, 636)
        Me.Controls.SetChildIndex(Me.SplitContainer2, 0)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl2.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.chk_all.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents to_dt As Frame7.eDate
    Friend WithEvents dsc1 As Frame7.eText
    Friend WithEvents fr_dt As Frame7.eDate
    Friend WithEvents dept_cd As Frame7.eText
    Friend WithEvents co_cd As Frame7.eCombo
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ECombo4 As Frame7.eCombo
    Friend WithEvents ECombo3 As Frame7.eCombo
    Friend WithEvents EText6 As Frame7.eText
    Friend WithEvents EText4 As Frame7.eText
    Friend WithEvents EText5 As Frame7.eText
    Friend WithEvents EText3 As Frame7.eText
    Friend WithEvents EText2 As Frame7.eText
    Friend WithEvents EDate1 As Frame7.eDate
    Friend WithEvents ECombo2 As Frame7.eCombo
    Friend WithEvents EText1 As Frame7.eText
    Friend WithEvents ECombo1 As Frame7.eCombo
    Friend WithEvents doc_rid As Frame7.eText
    Friend WithEvents to_apr_dt As Frame7.eDate
    Friend WithEvents fr_apr_dt As Frame7.eDate
    Friend WithEvents to_acc_cd As Frame7.eText
    Friend WithEvents fr_acc_cd As Frame7.eText
    Friend WithEvents doc_no As Frame7.eText
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents XtraTabControl2 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents g10 As Frame7.eGrid
    Friend WithEvents g20 As Frame7.eGrid
    Friend WithEvents g30 As Frame7.eGrid
    Friend WithEvents doc_nm As Frame7.eText
    Friend WithEvents dept_nm As Frame7.eText
    Friend WithEvents chk_all As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents doc_id As Frame7.eText
    Friend WithEvents acc_nm As Frame7.eText
    Friend WithEvents doc_bc As Frame7.eCheckCombo
    Friend WithEvents stat_bc As Frame7.eCheckCombo
    Friend WithEvents div_cd As Frame7.eCheckCombo
    Friend WithEvents dsc2 As Frame7.eText
    Friend WithEvents acc_cd As Frame7.eText
    Friend WithEvents cust_cd As Frame7.eText
    Friend WithEvents cust_nm As Frame7.eText
    Friend WithEvents fr_amt1 As Frame7.eText
    Friend WithEvents to_amt1 As Frame7.eText
    Friend WithEvents fr_amt2 As Frame7.eText
    Friend WithEvents to_amt2 As Frame7.eText
    Friend WithEvents apr_no As Frame7.eText
    Friend WithEvents g_dept_cd As Frame7.eText
    Friend WithEvents g_dept_nm As Frame7.eText
    Friend WithEvents f_rmks As Frame7.eText
    Friend WithEvents f_stat_bc As Frame7.eCheckCombo

End Class
