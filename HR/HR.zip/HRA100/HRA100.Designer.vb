﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HRA100
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HRA100))
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.pnlshow = New Frame7.ePanel()
        Me.f_work_kd = New Frame7.eCombo()
        Me.btn_show = New DevExpress.XtraEditors.SimpleButton()
        Me.f_high_bc = New Frame7.eCombo()
        Me.f_retr_dt1 = New Frame7.eDate()
        Me.f_bs_cd = New Frame7.eCombo()
        Me.f_co_cd = New Frame7.eCombo()
        Me.f_dept_nm = New Frame7.eText()
        Me.f_duty_bc = New Frame7.eCombo()
        Me.f_retr_dt2 = New Frame7.eDate()
        Me.f_emp_nm = New Frame7.eText()
        Me.f_hire_dt1 = New Frame7.eDate()
        Me.f_stat_bc = New Frame7.eCheckCombo()
        Me.f_emp_no = New Frame7.eText()
        Me.f_hire_dt2 = New Frame7.eDate()
        Me.f_dept_yn = New Frame7.eCheck()
        Me.f_dept_cd = New Frame7.eText()
        Me.g10 = New Frame7.eGrid()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.EPanel3 = New Frame7.ePanel()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.photo = New Frame7.eImage()
        Me.btn_pic = New DevExpress.XtraEditors.SimpleButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.eval_bc = New Frame7.eCombo()
        Me.age = New Frame7.eText()
        Me.work_mon = New Frame7.eText()
        Me.work_dept_nm = New Frame7.eText()
        Me.work_dept = New Frame7.eText()
        Me.emp_nm = New Frame7.eText()
        Me.high_bc = New Frame7.eCombo()
        Me.duty_bc = New Frame7.eCombo()
        Me.pro_to = New Frame7.eDate()
        Me.sum_bc = New Frame7.eCombo()
        Me.cc_cd = New Frame7.eCombo()
        Me.fac_cd = New Frame7.eCombo()
        Me.work_bs = New Frame7.eCombo()
        Me.work_kd = New Frame7.eCombo()
        Me.job_nm = New Frame7.eText()
        Me.emp_nm3 = New Frame7.eText()
        Me.retr_rmk = New Frame7.eText()
        Me.emp_nm2 = New Frame7.eText()
        Me.bir_dt = New Frame7.eDate()
        Me.retr_dt = New Frame7.eDate()
        Me.dept_nm = New Frame7.eText()
        Me.pay_kd = New Frame7.eCombo()
        Me.stat_bc = New Frame7.eCombo()
        Me.reg_no = New Frame7.eText()
        Me.hire2_dt = New Frame7.eDate()
        Me.luna_yn = New Frame7.eCheck()
        Me.hire_bc = New Frame7.eCombo()
        Me.send_bc = New Frame7.eCombo()
        Me.grp_bc = New Frame7.eCombo()
        Me.retr_bc = New Frame7.eCombo()
        Me.pro_fr = New Frame7.eDate()
        Me.bs_cd = New Frame7.eCombo()
        Me.entr_bc = New Frame7.eCombo()
        Me.step_bc = New Frame7.eCombo()
        Me.rank_bc = New Frame7.eCombo()
        Me.emp_no = New Frame7.eText()
        Me.nat_cd = New Frame7.eCombo()
        Me.gen_ty = New Frame7.eCombo()
        Me.work_bc = New Frame7.eCombo()
        Me.hire_dt = New Frame7.eDate()
        Me.dept_cd = New Frame7.eText()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.woman_yn = New Frame7.eCheck()
        Me.hobby2 = New Frame7.eText()
        Me.hobby1 = New Frame7.eText()
        Me.merit_no = New Frame7.eText()
        Me.merit_bc = New Frame7.eCombo()
        Me.org_addr = New Frame7.eText()
        Me.zip_cd = New Frame7.eText()
        Me.email = New Frame7.eText()
        Me.card_no = New Frame7.eText()
        Me.car_no = New Frame7.eText()
        Me.mobile = New Frame7.eText()
        Me.home_tel = New Frame7.eText()
        Me.relig_bc = New Frame7.eCombo()
        Me.dept_tel = New Frame7.eText()
        Me.wed_yn = New Frame7.eCheck()
        Me.addr1 = New Frame7.eText()
        Me.XtraTabPage1_1 = New DevExpress.XtraTab.XtraTabPage()
        Me.blood_bc = New Frame7.eCombo()
        Me.ms_bc = New Frame7.eCombo()
        Me.kind_bc = New Frame7.eCombo()
        Me.rank1_bc = New Frame7.eCombo()
        Me.hcap_yn = New Frame7.eCheck()
        Me.job_bc = New Frame7.eCombo()
        Me.spc_yn = New Frame7.eCheck()
        Me.fr_dt = New Frame7.eDate()
        Me.to_dt = New Frame7.eDate()
        Me.hi = New Frame7.eText()
        Me.blood_rh_bc = New Frame7.eCombo()
        Me.weight = New Frame7.eText()
        Me.cblind_chk = New Frame7.eCheck()
        Me.sight_left = New Frame7.eText()
        Me.hcap_lv = New Frame7.eText()
        Me.sight_right = New Frame7.eText()
        Me.hcap_bc = New Frame7.eCombo()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g20 = New Frame7.eGrid()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.g30 = New Frame7.eGrid()
        Me.XtraTabPage4 = New DevExpress.XtraTab.XtraTabPage()
        Me.g40 = New Frame7.eGrid()
        Me.XtraTabPage5 = New DevExpress.XtraTab.XtraTabPage()
        Me.g50 = New Frame7.eGrid()
        Me.XtraTabPage6 = New DevExpress.XtraTab.XtraTabPage()
        Me.g60 = New Frame7.eGrid()
        Me.XtraTabPage7 = New DevExpress.XtraTab.XtraTabPage()
        Me.g70 = New Frame7.eGrid()
        Me.XtraTabPage8 = New DevExpress.XtraTab.XtraTabPage()
        Me.g80 = New Frame7.eGrid()
        Me.XtraTabPage9 = New DevExpress.XtraTab.XtraTabPage()
        Me.g90 = New Frame7.eGrid()
        Me.XtraTabPage10 = New DevExpress.XtraTab.XtraTabPage()
        Me.g95 = New Frame7.eGrid()
        Me.XtraTabPage11 = New DevExpress.XtraTab.XtraTabPage()
        Me.g96 = New Frame7.eGrid()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.pnlshow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshow.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.XtraTabPage1_1.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        Me.XtraTabPage4.SuspendLayout()
        Me.XtraTabPage5.SuspendLayout()
        Me.XtraTabPage6.SuspendLayout()
        Me.XtraTabPage7.SuspendLayout()
        Me.XtraTabPage8.SuspendLayout()
        Me.XtraTabPage9.SuspendLayout()
        Me.XtraTabPage10.SuspendLayout()
        Me.XtraTabPage11.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(8, 8)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1295, 568)
        Me.SplitContainer1.SplitterDistance = 238
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.AutoScroll = True
        Me.SplitContainer3.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.AutoScroll = True
        Me.SplitContainer3.Panel2.Controls.Add(Me.g10)
        Me.SplitContainer3.Size = New System.Drawing.Size(238, 568)
        Me.SplitContainer3.SplitterDistance = 172
        Me.SplitContainer3.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.pnlshow)
        Me.EPanel1.Controls.Add(Me.btn_show)
        Me.EPanel1.Controls.Add(Me.f_high_bc)
        Me.EPanel1.Controls.Add(Me.f_retr_dt1)
        Me.EPanel1.Controls.Add(Me.f_bs_cd)
        Me.EPanel1.Controls.Add(Me.f_co_cd)
        Me.EPanel1.Controls.Add(Me.f_dept_nm)
        Me.EPanel1.Controls.Add(Me.f_duty_bc)
        Me.EPanel1.Controls.Add(Me.f_retr_dt2)
        Me.EPanel1.Controls.Add(Me.f_emp_nm)
        Me.EPanel1.Controls.Add(Me.f_hire_dt1)
        Me.EPanel1.Controls.Add(Me.f_stat_bc)
        Me.EPanel1.Controls.Add(Me.f_emp_no)
        Me.EPanel1.Controls.Add(Me.f_hire_dt2)
        Me.EPanel1.Controls.Add(Me.f_dept_yn)
        Me.EPanel1.Controls.Add(Me.f_dept_cd)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(238, 172)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     검색조건"
        '
        'pnlshow
        '
        Me.pnlshow.Controls.Add(Me.f_work_kd)
        Me.pnlshow.Location = New System.Drawing.Point(77, 123)
        Me.pnlshow.Name = "pnlshow"
        Me.pnlshow.Size = New System.Drawing.Size(155, 49)
        Me.pnlshow.TabIndex = 92
        Me.pnlshow.Text = "     "
        Me.pnlshow.Visible = False
        '
        'f_work_kd
        '
        Me.f_work_kd.Location = New System.Drawing.Point(32, 1)
        Me.f_work_kd.Name = "f_work_kd"
        Me.f_work_kd.Size = New System.Drawing.Size(123, 21)
        Me.f_work_kd.TabIndex = 60
        Me.f_work_kd.Title = ""
        Me.f_work_kd.TitleWidth = 1
        '
        'btn_show
        '
        Me.btn_show.Location = New System.Drawing.Point(12, 123)
        Me.btn_show.Name = "btn_show"
        Me.btn_show.Size = New System.Drawing.Size(59, 21)
        Me.btn_show.TabIndex = 91
        Me.btn_show.Text = "유형"
        '
        'f_high_bc
        '
        Me.f_high_bc.Location = New System.Drawing.Point(536, 100)
        Me.f_high_bc.Name = "f_high_bc"
        Me.f_high_bc.Size = New System.Drawing.Size(240, 21)
        Me.f_high_bc.TabIndex = 89
        Me.f_high_bc.Title = "직위"
        '
        'f_retr_dt1
        '
        Me.f_retr_dt1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_retr_dt1.Location = New System.Drawing.Point(276, 52)
        Me.f_retr_dt1.Name = "f_retr_dt1"
        Me.f_retr_dt1.Size = New System.Drawing.Size(240, 21)
        Me.f_retr_dt1.TabIndex = 69
        Me.f_retr_dt1.Title = "퇴사일"
        '
        'f_bs_cd
        '
        Me.f_bs_cd.Location = New System.Drawing.Point(12, 28)
        Me.f_bs_cd.Name = "f_bs_cd"
        Me.f_bs_cd.Size = New System.Drawing.Size(220, 21)
        Me.f_bs_cd.TabIndex = 2
        Me.f_bs_cd.Title = "사업장"
        Me.f_bs_cd.TitleWidth = 98
        '
        'f_co_cd
        '
        Me.f_co_cd.Location = New System.Drawing.Point(276, 124)
        Me.f_co_cd.Name = "f_co_cd"
        Me.f_co_cd.Size = New System.Drawing.Size(240, 21)
        Me.f_co_cd.TabIndex = 2
        Me.f_co_cd.Title = " 법인"
        '
        'f_dept_nm
        '
        Me.f_dept_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_dept_nm.Location = New System.Drawing.Point(12, 52)
        Me.f_dept_nm.Name = "f_dept_nm"
        Me.f_dept_nm.Size = New System.Drawing.Size(220, 21)
        Me.f_dept_nm.TabIndex = 8
        Me.f_dept_nm.Title = "부서명"
        Me.f_dept_nm.TitleWidth = 98
        '
        'f_duty_bc
        '
        Me.f_duty_bc.Location = New System.Drawing.Point(536, 124)
        Me.f_duty_bc.Name = "f_duty_bc"
        Me.f_duty_bc.Size = New System.Drawing.Size(240, 21)
        Me.f_duty_bc.TabIndex = 88
        Me.f_duty_bc.Title = "직책"
        '
        'f_retr_dt2
        '
        Me.f_retr_dt2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_retr_dt2.Location = New System.Drawing.Point(400, 52)
        Me.f_retr_dt2.Name = "f_retr_dt2"
        Me.f_retr_dt2.Size = New System.Drawing.Size(240, 21)
        Me.f_retr_dt2.TabIndex = 69
        Me.f_retr_dt2.Title = "입사일"
        '
        'f_emp_nm
        '
        Me.f_emp_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_emp_nm.Location = New System.Drawing.Point(12, 76)
        Me.f_emp_nm.Name = "f_emp_nm"
        Me.f_emp_nm.Size = New System.Drawing.Size(220, 21)
        Me.f_emp_nm.TabIndex = 10
        Me.f_emp_nm.Title = "성명"
        Me.f_emp_nm.TitleWidth = 98
        '
        'f_hire_dt1
        '
        Me.f_hire_dt1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_hire_dt1.Location = New System.Drawing.Point(276, 28)
        Me.f_hire_dt1.Name = "f_hire_dt1"
        Me.f_hire_dt1.Size = New System.Drawing.Size(240, 21)
        Me.f_hire_dt1.TabIndex = 69
        Me.f_hire_dt1.Title = "입사일"
        '
        'f_stat_bc
        '
        Me.f_stat_bc.Location = New System.Drawing.Point(12, 100)
        Me.f_stat_bc.Name = "f_stat_bc"
        Me.f_stat_bc.Size = New System.Drawing.Size(220, 21)
        Me.f_stat_bc.TabIndex = 7
        Me.f_stat_bc.Title = "재직여부"
        Me.f_stat_bc.TitleWidth = 98
        '
        'f_emp_no
        '
        Me.f_emp_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_emp_no.Location = New System.Drawing.Point(536, 76)
        Me.f_emp_no.Name = "f_emp_no"
        Me.f_emp_no.Size = New System.Drawing.Size(240, 21)
        Me.f_emp_no.TabIndex = 9
        Me.f_emp_no.Title = "사번"
        '
        'f_hire_dt2
        '
        Me.f_hire_dt2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_hire_dt2.Location = New System.Drawing.Point(400, 28)
        Me.f_hire_dt2.Name = "f_hire_dt2"
        Me.f_hire_dt2.Size = New System.Drawing.Size(240, 21)
        Me.f_hire_dt2.TabIndex = 69
        Me.f_hire_dt2.Title = "입사일"
        '
        'f_dept_yn
        '
        Me.f_dept_yn.Caption = ""
        Me.f_dept_yn.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_dept_yn.Location = New System.Drawing.Point(276, 100)
        Me.f_dept_yn.Name = "f_dept_yn"
        Me.f_dept_yn.Size = New System.Drawing.Size(136, 21)
        Me.f_dept_yn.TabIndex = 78
        Me.f_dept_yn.Title = "하위부서포함"
        '
        'f_dept_cd
        '
        Me.f_dept_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.f_dept_cd.Location = New System.Drawing.Point(276, 76)
        Me.f_dept_cd.Name = "f_dept_cd"
        Me.f_dept_cd.Size = New System.Drawing.Size(240, 21)
        Me.f_dept_cd.TabIndex = 3
        Me.f_dept_cd.Title = "부서코드"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.ReadOnly = False
        Me.g10.RowHeight = -1
        Me.g10.Size = New System.Drawing.Size(238, 392)
        Me.g10.TabIndex = 2
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.AutoScroll = True
        Me.SplitContainer2.Panel1.Controls.Add(Me.EPanel3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.AutoScroll = True
        Me.SplitContainer2.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1053, 568)
        Me.SplitContainer2.SplitterDistance = 325
        Me.SplitContainer2.TabIndex = 65
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.SplitContainer4)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(1053, 325)
        Me.EPanel3.TabIndex = 63
        Me.EPanel3.Text = "     사원정보"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer4.Location = New System.Drawing.Point(2, 23)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.PictureBox3)
        Me.SplitContainer4.Panel1.Controls.Add(Me.photo)
        Me.SplitContainer4.Panel1.Controls.Add(Me.btn_pic)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.Panel2)
        Me.SplitContainer4.Size = New System.Drawing.Size(1049, 300)
        Me.SplitContainer4.SplitterDistance = 34
        Me.SplitContainer4.TabIndex = 3
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(5, 9)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 159
        Me.PictureBox3.TabStop = False
        '
        'photo
        '
        Me.photo.Location = New System.Drawing.Point(5, 44)
        Me.photo.Name = "photo"
        Me.photo.Size = New System.Drawing.Size(116, 148)
        Me.photo.SizeMode = Frame7.ImageSizeMode.Stretch
        Me.photo.TabIndex = 2
        Me.photo.TitleBorderStyle = Frame7.BorderStyle.None
        '
        'btn_pic
        '
        Me.btn_pic.Location = New System.Drawing.Point(4, 6)
        Me.btn_pic.Name = "btn_pic"
        Me.btn_pic.Size = New System.Drawing.Size(26, 30)
        Me.btn_pic.TabIndex = 4
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.Controls.Add(Me.eval_bc)
        Me.Panel2.Controls.Add(Me.age)
        Me.Panel2.Controls.Add(Me.work_mon)
        Me.Panel2.Controls.Add(Me.work_dept_nm)
        Me.Panel2.Controls.Add(Me.work_dept)
        Me.Panel2.Controls.Add(Me.emp_nm)
        Me.Panel2.Controls.Add(Me.high_bc)
        Me.Panel2.Controls.Add(Me.duty_bc)
        Me.Panel2.Controls.Add(Me.pro_to)
        Me.Panel2.Controls.Add(Me.sum_bc)
        Me.Panel2.Controls.Add(Me.cc_cd)
        Me.Panel2.Controls.Add(Me.fac_cd)
        Me.Panel2.Controls.Add(Me.work_bs)
        Me.Panel2.Controls.Add(Me.work_kd)
        Me.Panel2.Controls.Add(Me.job_nm)
        Me.Panel2.Controls.Add(Me.emp_nm3)
        Me.Panel2.Controls.Add(Me.retr_rmk)
        Me.Panel2.Controls.Add(Me.emp_nm2)
        Me.Panel2.Controls.Add(Me.bir_dt)
        Me.Panel2.Controls.Add(Me.retr_dt)
        Me.Panel2.Controls.Add(Me.dept_nm)
        Me.Panel2.Controls.Add(Me.pay_kd)
        Me.Panel2.Controls.Add(Me.stat_bc)
        Me.Panel2.Controls.Add(Me.reg_no)
        Me.Panel2.Controls.Add(Me.hire2_dt)
        Me.Panel2.Controls.Add(Me.luna_yn)
        Me.Panel2.Controls.Add(Me.hire_bc)
        Me.Panel2.Controls.Add(Me.send_bc)
        Me.Panel2.Controls.Add(Me.grp_bc)
        Me.Panel2.Controls.Add(Me.retr_bc)
        Me.Panel2.Controls.Add(Me.pro_fr)
        Me.Panel2.Controls.Add(Me.bs_cd)
        Me.Panel2.Controls.Add(Me.entr_bc)
        Me.Panel2.Controls.Add(Me.step_bc)
        Me.Panel2.Controls.Add(Me.rank_bc)
        Me.Panel2.Controls.Add(Me.emp_no)
        Me.Panel2.Controls.Add(Me.nat_cd)
        Me.Panel2.Controls.Add(Me.gen_ty)
        Me.Panel2.Controls.Add(Me.work_bc)
        Me.Panel2.Controls.Add(Me.hire_dt)
        Me.Panel2.Controls.Add(Me.dept_cd)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1011, 300)
        Me.Panel2.TabIndex = 2
        '
        'eval_bc
        '
        Me.eval_bc.Location = New System.Drawing.Point(488, 200)
        Me.eval_bc.Name = "eval_bc"
        Me.eval_bc.Size = New System.Drawing.Size(228, 21)
        Me.eval_bc.TabIndex = 101
        Me.eval_bc.Title = "고과구분"
        Me.eval_bc.TitleWidth = 108
        '
        'age
        '
        Me.age.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.age.Location = New System.Drawing.Point(140, 200)
        Me.age.Name = "age"
        Me.age.Size = New System.Drawing.Size(98, 21)
        Me.age.TabIndex = 100
        Me.age.Title = "연령"
        Me.age.TitleAlign = Frame7.Alignment.Center
        Me.age.TitleWidth = 50
        '
        'work_mon
        '
        Me.work_mon.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.work_mon.Location = New System.Drawing.Point(248, 272)
        Me.work_mon.Name = "work_mon"
        Me.work_mon.Size = New System.Drawing.Size(230, 21)
        Me.work_mon.TabIndex = 100
        Me.work_mon.Title = "근무개월"
        Me.work_mon.TitleWidth = 108
        '
        'work_dept_nm
        '
        Me.work_dept_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.work_dept_nm.Location = New System.Drawing.Point(480, 248)
        Me.work_dept_nm.Name = "work_dept_nm"
        Me.work_dept_nm.Size = New System.Drawing.Size(236, 21)
        Me.work_dept_nm.TabIndex = 99
        Me.work_dept_nm.Title = "근무부서명"
        Me.work_dept_nm.TitleWidth = 0
        '
        'work_dept
        '
        Me.work_dept.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.work_dept.Location = New System.Drawing.Point(248, 248)
        Me.work_dept.Name = "work_dept"
        Me.work_dept.Size = New System.Drawing.Size(230, 21)
        Me.work_dept.TabIndex = 98
        Me.work_dept.Title = "근무부서코드"
        Me.work_dept.TitleWidth = 108
        '
        'emp_nm
        '
        Me.emp_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.emp_nm.Location = New System.Drawing.Point(8, 32)
        Me.emp_nm.Name = "emp_nm"
        Me.emp_nm.Size = New System.Drawing.Size(230, 21)
        Me.emp_nm.TabIndex = 63
        Me.emp_nm.Title = "사원명"
        Me.emp_nm.TitleWidth = 108
        '
        'high_bc
        '
        Me.high_bc.Location = New System.Drawing.Point(248, 128)
        Me.high_bc.Name = "high_bc"
        Me.high_bc.Size = New System.Drawing.Size(230, 21)
        Me.high_bc.TabIndex = 89
        Me.high_bc.Title = "직위"
        Me.high_bc.TitleWidth = 108
        '
        'duty_bc
        '
        Me.duty_bc.Location = New System.Drawing.Point(248, 152)
        Me.duty_bc.Name = "duty_bc"
        Me.duty_bc.Size = New System.Drawing.Size(230, 21)
        Me.duty_bc.TabIndex = 88
        Me.duty_bc.Title = "직책"
        Me.duty_bc.TitleWidth = 108
        '
        'pro_to
        '
        Me.pro_to.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pro_to.Location = New System.Drawing.Point(488, 176)
        Me.pro_to.Name = "pro_to"
        Me.pro_to.Size = New System.Drawing.Size(230, 21)
        Me.pro_to.TabIndex = 76
        Me.pro_to.Title = "수습종료일"
        Me.pro_to.TitleWidth = 108
        '
        'sum_bc
        '
        Me.sum_bc.Location = New System.Drawing.Point(480, 272)
        Me.sum_bc.Name = "sum_bc"
        Me.sum_bc.Size = New System.Drawing.Size(236, 21)
        Me.sum_bc.TabIndex = 96
        Me.sum_bc.Title = "집계구분"
        Me.sum_bc.TitleWidth = 80
        '
        'cc_cd
        '
        Me.cc_cd.Location = New System.Drawing.Point(724, 37)
        Me.cc_cd.Name = "cc_cd"
        Me.cc_cd.Size = New System.Drawing.Size(233, 21)
        Me.cc_cd.TabIndex = 96
        Me.cc_cd.Title = "원가부문"
        Me.cc_cd.TitleWidth = 108
        '
        'fac_cd
        '
        Me.fac_cd.Location = New System.Drawing.Point(8, 272)
        Me.fac_cd.Name = "fac_cd"
        Me.fac_cd.Size = New System.Drawing.Size(230, 21)
        Me.fac_cd.TabIndex = 96
        Me.fac_cd.Title = "근무공장"
        Me.fac_cd.TitleWidth = 108
        '
        'work_bs
        '
        Me.work_bs.Location = New System.Drawing.Point(8, 248)
        Me.work_bs.Name = "work_bs"
        Me.work_bs.Size = New System.Drawing.Size(230, 21)
        Me.work_bs.TabIndex = 96
        Me.work_bs.Title = "근무사업장"
        Me.work_bs.TitleWidth = 108
        '
        'work_kd
        '
        Me.work_kd.Location = New System.Drawing.Point(248, 80)
        Me.work_kd.Name = "work_kd"
        Me.work_kd.Size = New System.Drawing.Size(230, 21)
        Me.work_kd.TabIndex = 83
        Me.work_kd.Title = "근무직유형"
        Me.work_kd.TitleWidth = 108
        '
        'job_nm
        '
        Me.job_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.job_nm.Location = New System.Drawing.Point(724, 10)
        Me.job_nm.Name = "job_nm"
        Me.job_nm.Size = New System.Drawing.Size(233, 21)
        Me.job_nm.TabIndex = 65
        Me.job_nm.Title = "담당업무명"
        Me.job_nm.TitleWidth = 80
        '
        'emp_nm3
        '
        Me.emp_nm3.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.emp_nm3.Location = New System.Drawing.Point(8, 80)
        Me.emp_nm3.Name = "emp_nm3"
        Me.emp_nm3.Size = New System.Drawing.Size(230, 21)
        Me.emp_nm3.TabIndex = 65
        Me.emp_nm3.Title = "한자"
        Me.emp_nm3.TitleWidth = 108
        '
        'retr_rmk
        '
        Me.retr_rmk.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.retr_rmk.Location = New System.Drawing.Point(488, 128)
        Me.retr_rmk.Name = "retr_rmk"
        Me.retr_rmk.Size = New System.Drawing.Size(230, 21)
        Me.retr_rmk.TabIndex = 94
        Me.retr_rmk.Title = "퇴직사유"
        Me.retr_rmk.TitleWidth = 108
        '
        'emp_nm2
        '
        Me.emp_nm2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.emp_nm2.Location = New System.Drawing.Point(8, 56)
        Me.emp_nm2.Name = "emp_nm2"
        Me.emp_nm2.Size = New System.Drawing.Size(230, 21)
        Me.emp_nm2.TabIndex = 64
        Me.emp_nm2.Title = "영문명"
        Me.emp_nm2.TitleWidth = 108
        '
        'bir_dt
        '
        Me.bir_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.bir_dt.Location = New System.Drawing.Point(8, 176)
        Me.bir_dt.Name = "bir_dt"
        Me.bir_dt.Size = New System.Drawing.Size(230, 21)
        Me.bir_dt.TabIndex = 77
        Me.bir_dt.Title = "생년월일"
        Me.bir_dt.TitleWidth = 108
        '
        'retr_dt
        '
        Me.retr_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.retr_dt.Location = New System.Drawing.Point(488, 80)
        Me.retr_dt.Name = "retr_dt"
        Me.retr_dt.Size = New System.Drawing.Size(230, 21)
        Me.retr_dt.TabIndex = 92
        Me.retr_dt.Title = "퇴사일"
        Me.retr_dt.TitleWidth = 108
        '
        'dept_nm
        '
        Me.dept_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dept_nm.Location = New System.Drawing.Point(480, 224)
        Me.dept_nm.Name = "dept_nm"
        Me.dept_nm.Size = New System.Drawing.Size(236, 21)
        Me.dept_nm.TabIndex = 80
        Me.dept_nm.Title = "소속부서명"
        Me.dept_nm.TitleWidth = 0
        '
        'pay_kd
        '
        Me.pay_kd.Location = New System.Drawing.Point(248, 104)
        Me.pay_kd.Name = "pay_kd"
        Me.pay_kd.Size = New System.Drawing.Size(230, 21)
        Me.pay_kd.TabIndex = 81
        Me.pay_kd.Title = "급여형태"
        Me.pay_kd.TitleWidth = 108
        '
        'stat_bc
        '
        Me.stat_bc.Location = New System.Drawing.Point(248, 8)
        Me.stat_bc.Name = "stat_bc"
        Me.stat_bc.Size = New System.Drawing.Size(230, 21)
        Me.stat_bc.TabIndex = 84
        Me.stat_bc.Title = "근무상태"
        Me.stat_bc.TitleWidth = 108
        '
        'reg_no
        '
        Me.reg_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.reg_no.Location = New System.Drawing.Point(8, 128)
        Me.reg_no.Name = "reg_no"
        Me.reg_no.Size = New System.Drawing.Size(230, 21)
        Me.reg_no.TabIndex = 74
        Me.reg_no.Title = "주민번호"
        Me.reg_no.TitleWidth = 108
        '
        'hire2_dt
        '
        Me.hire2_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.hire2_dt.Location = New System.Drawing.Point(488, 56)
        Me.hire2_dt.Name = "hire2_dt"
        Me.hire2_dt.Size = New System.Drawing.Size(230, 21)
        Me.hire2_dt.TabIndex = 70
        Me.hire2_dt.Title = "정규입사일"
        Me.hire2_dt.TitleWidth = 108
        '
        'luna_yn
        '
        Me.luna_yn.Caption = ""
        Me.luna_yn.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.luna_yn.Location = New System.Drawing.Point(8, 200)
        Me.luna_yn.Name = "luna_yn"
        Me.luna_yn.Size = New System.Drawing.Size(132, 21)
        Me.luna_yn.TabIndex = 78
        Me.luna_yn.Title = "음력여부"
        Me.luna_yn.TitleWidth = 108
        '
        'hire_bc
        '
        Me.hire_bc.Location = New System.Drawing.Point(248, 32)
        Me.hire_bc.Name = "hire_bc"
        Me.hire_bc.Size = New System.Drawing.Size(230, 21)
        Me.hire_bc.TabIndex = 85
        Me.hire_bc.Title = "입사구분"
        Me.hire_bc.TitleWidth = 108
        '
        'send_bc
        '
        Me.send_bc.Location = New System.Drawing.Point(724, 272)
        Me.send_bc.Name = "send_bc"
        Me.send_bc.Size = New System.Drawing.Size(234, 21)
        Me.send_bc.TabIndex = 93
        Me.send_bc.Title = "파견처구분"
        Me.send_bc.TitleWidth = 108
        '
        'grp_bc
        '
        Me.grp_bc.Location = New System.Drawing.Point(724, 248)
        Me.grp_bc.Name = "grp_bc"
        Me.grp_bc.Size = New System.Drawing.Size(234, 21)
        Me.grp_bc.TabIndex = 93
        Me.grp_bc.Title = "직군"
        Me.grp_bc.TitleWidth = 108
        '
        'retr_bc
        '
        Me.retr_bc.Location = New System.Drawing.Point(488, 104)
        Me.retr_bc.Name = "retr_bc"
        Me.retr_bc.Size = New System.Drawing.Size(230, 21)
        Me.retr_bc.TabIndex = 93
        Me.retr_bc.Title = "퇴직구분"
        Me.retr_bc.TitleWidth = 108
        '
        'pro_fr
        '
        Me.pro_fr.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pro_fr.Location = New System.Drawing.Point(488, 152)
        Me.pro_fr.Name = "pro_fr"
        Me.pro_fr.Size = New System.Drawing.Size(230, 21)
        Me.pro_fr.TabIndex = 72
        Me.pro_fr.Title = "수습시작일"
        Me.pro_fr.TitleWidth = 108
        '
        'bs_cd
        '
        Me.bs_cd.Location = New System.Drawing.Point(8, 224)
        Me.bs_cd.Name = "bs_cd"
        Me.bs_cd.Size = New System.Drawing.Size(230, 21)
        Me.bs_cd.TabIndex = 68
        Me.bs_cd.Title = "소속사업장"
        Me.bs_cd.TitleWidth = 108
        '
        'entr_bc
        '
        Me.entr_bc.Location = New System.Drawing.Point(488, 8)
        Me.entr_bc.Name = "entr_bc"
        Me.entr_bc.Size = New System.Drawing.Size(230, 21)
        Me.entr_bc.TabIndex = 86
        Me.entr_bc.Title = "채용구분"
        Me.entr_bc.TitleWidth = 108
        '
        'step_bc
        '
        Me.step_bc.Location = New System.Drawing.Point(248, 200)
        Me.step_bc.Name = "step_bc"
        Me.step_bc.Size = New System.Drawing.Size(230, 21)
        Me.step_bc.TabIndex = 87
        Me.step_bc.Title = "호봉"
        Me.step_bc.TitleWidth = 108
        '
        'rank_bc
        '
        Me.rank_bc.Location = New System.Drawing.Point(248, 176)
        Me.rank_bc.Name = "rank_bc"
        Me.rank_bc.Size = New System.Drawing.Size(230, 21)
        Me.rank_bc.TabIndex = 87
        Me.rank_bc.Title = "직급"
        Me.rank_bc.TitleWidth = 108
        '
        'emp_no
        '
        Me.emp_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.emp_no.Location = New System.Drawing.Point(8, 8)
        Me.emp_no.Name = "emp_no"
        Me.emp_no.Size = New System.Drawing.Size(230, 21)
        Me.emp_no.TabIndex = 66
        Me.emp_no.Title = "사번"
        Me.emp_no.TitleWidth = 108
        '
        'nat_cd
        '
        Me.nat_cd.Location = New System.Drawing.Point(8, 104)
        Me.nat_cd.Name = "nat_cd"
        Me.nat_cd.Size = New System.Drawing.Size(230, 21)
        Me.nat_cd.TabIndex = 73
        Me.nat_cd.Title = "국적"
        Me.nat_cd.TitleWidth = 108
        '
        'gen_ty
        '
        Me.gen_ty.Location = New System.Drawing.Point(8, 152)
        Me.gen_ty.Name = "gen_ty"
        Me.gen_ty.Size = New System.Drawing.Size(230, 21)
        Me.gen_ty.TabIndex = 75
        Me.gen_ty.Title = "성별"
        Me.gen_ty.TitleWidth = 108
        '
        'work_bc
        '
        Me.work_bc.Location = New System.Drawing.Point(248, 56)
        Me.work_bc.Name = "work_bc"
        Me.work_bc.Size = New System.Drawing.Size(230, 21)
        Me.work_bc.TabIndex = 82
        Me.work_bc.Title = "근무직구분"
        Me.work_bc.TitleWidth = 108
        '
        'hire_dt
        '
        Me.hire_dt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.hire_dt.Location = New System.Drawing.Point(488, 32)
        Me.hire_dt.Name = "hire_dt"
        Me.hire_dt.Size = New System.Drawing.Size(230, 21)
        Me.hire_dt.TabIndex = 69
        Me.hire_dt.Title = "입사일"
        Me.hire_dt.TitleWidth = 108
        '
        'dept_cd
        '
        Me.dept_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dept_cd.Location = New System.Drawing.Point(248, 224)
        Me.dept_cd.Name = "dept_cd"
        Me.dept_cd.Size = New System.Drawing.Size(230, 21)
        Me.dept_cd.TabIndex = 79
        Me.dept_cd.Title = "소속부서코드"
        Me.dept_cd.TitleWidth = 108
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1053, 239)
        Me.XtraTabControl1.TabIndex = 2
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage1_1, Me.XtraTabPage2, Me.XtraTabPage3, Me.XtraTabPage4, Me.XtraTabPage5, Me.XtraTabPage6, Me.XtraTabPage7, Me.XtraTabPage8, Me.XtraTabPage9, Me.XtraTabPage10, Me.XtraTabPage11})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.AlwaysScrollActiveControlIntoView = False
        Me.XtraTabPage1.AutoScroll = True
        Me.XtraTabPage1.Controls.Add(Me.woman_yn)
        Me.XtraTabPage1.Controls.Add(Me.hobby2)
        Me.XtraTabPage1.Controls.Add(Me.hobby1)
        Me.XtraTabPage1.Controls.Add(Me.merit_no)
        Me.XtraTabPage1.Controls.Add(Me.merit_bc)
        Me.XtraTabPage1.Controls.Add(Me.org_addr)
        Me.XtraTabPage1.Controls.Add(Me.zip_cd)
        Me.XtraTabPage1.Controls.Add(Me.email)
        Me.XtraTabPage1.Controls.Add(Me.card_no)
        Me.XtraTabPage1.Controls.Add(Me.car_no)
        Me.XtraTabPage1.Controls.Add(Me.mobile)
        Me.XtraTabPage1.Controls.Add(Me.home_tel)
        Me.XtraTabPage1.Controls.Add(Me.relig_bc)
        Me.XtraTabPage1.Controls.Add(Me.dept_tel)
        Me.XtraTabPage1.Controls.Add(Me.wed_yn)
        Me.XtraTabPage1.Controls.Add(Me.addr1)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage1.Text = "개인신상"
        '
        'woman_yn
        '
        Me.woman_yn.Caption = ""
        Me.woman_yn.Location = New System.Drawing.Point(12, 104)
        Me.woman_yn.Name = "woman_yn"
        Me.woman_yn.Size = New System.Drawing.Size(138, 21)
        Me.woman_yn.TabIndex = 159
        Me.woman_yn.Title = "부녀자여부"
        Me.woman_yn.TitleWidth = 80
        '
        'hobby2
        '
        Me.hobby2.Location = New System.Drawing.Point(516, 56)
        Me.hobby2.Name = "hobby2"
        Me.hobby2.Size = New System.Drawing.Size(240, 21)
        Me.hobby2.TabIndex = 158
        Me.hobby2.Title = "특기"
        '
        'hobby1
        '
        Me.hobby1.Location = New System.Drawing.Point(516, 32)
        Me.hobby1.Name = "hobby1"
        Me.hobby1.Size = New System.Drawing.Size(240, 21)
        Me.hobby1.TabIndex = 157
        Me.hobby1.Title = "취미"
        '
        'merit_no
        '
        Me.merit_no.Location = New System.Drawing.Point(260, 32)
        Me.merit_no.Name = "merit_no"
        Me.merit_no.Size = New System.Drawing.Size(240, 21)
        Me.merit_no.TabIndex = 156
        Me.merit_no.Title = "보훈번호"
        '
        'merit_bc
        '
        Me.merit_bc.Location = New System.Drawing.Point(260, 8)
        Me.merit_bc.Name = "merit_bc"
        Me.merit_bc.Size = New System.Drawing.Size(240, 21)
        Me.merit_bc.TabIndex = 155
        Me.merit_bc.Title = "보훈구분"
        '
        'org_addr
        '
        Me.org_addr.Location = New System.Drawing.Point(260, 131)
        Me.org_addr.Name = "org_addr"
        Me.org_addr.Size = New System.Drawing.Size(496, 21)
        Me.org_addr.TabIndex = 144
        Me.org_addr.Title = "본적"
        '
        'zip_cd
        '
        Me.zip_cd.Location = New System.Drawing.Point(260, 80)
        Me.zip_cd.Name = "zip_cd"
        Me.zip_cd.Size = New System.Drawing.Size(240, 21)
        Me.zip_cd.TabIndex = 141
        Me.zip_cd.Title = "우편번호"
        '
        'email
        '
        Me.email.Location = New System.Drawing.Point(12, 8)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(240, 21)
        Me.email.TabIndex = 140
        Me.email.Title = "E-Mail"
        Me.email.TitleWidth = 80
        '
        'card_no
        '
        Me.card_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.card_no.Location = New System.Drawing.Point(12, 131)
        Me.card_no.Name = "card_no"
        Me.card_no.Size = New System.Drawing.Size(240, 21)
        Me.card_no.TabIndex = 67
        Me.card_no.Title = "카드번호"
        '
        'car_no
        '
        Me.car_no.Location = New System.Drawing.Point(516, 8)
        Me.car_no.Name = "car_no"
        Me.car_no.Size = New System.Drawing.Size(240, 21)
        Me.car_no.TabIndex = 136
        Me.car_no.Title = "자동차번호"
        '
        'mobile
        '
        Me.mobile.Location = New System.Drawing.Point(12, 32)
        Me.mobile.Name = "mobile"
        Me.mobile.Size = New System.Drawing.Size(240, 21)
        Me.mobile.TabIndex = 138
        Me.mobile.Title = "핸드폰"
        Me.mobile.TitleWidth = 80
        '
        'home_tel
        '
        Me.home_tel.Location = New System.Drawing.Point(12, 56)
        Me.home_tel.Name = "home_tel"
        Me.home_tel.Size = New System.Drawing.Size(240, 21)
        Me.home_tel.TabIndex = 139
        Me.home_tel.Title = "집전화번호"
        Me.home_tel.TitleWidth = 80
        '
        'relig_bc
        '
        Me.relig_bc.Location = New System.Drawing.Point(260, 56)
        Me.relig_bc.Name = "relig_bc"
        Me.relig_bc.Size = New System.Drawing.Size(240, 21)
        Me.relig_bc.TabIndex = 135
        Me.relig_bc.Title = "종교"
        '
        'dept_tel
        '
        Me.dept_tel.Location = New System.Drawing.Point(12, 80)
        Me.dept_tel.Name = "dept_tel"
        Me.dept_tel.Size = New System.Drawing.Size(240, 21)
        Me.dept_tel.TabIndex = 137
        Me.dept_tel.Title = "내선번호"
        Me.dept_tel.TitleWidth = 80
        '
        'wed_yn
        '
        Me.wed_yn.Caption = ""
        Me.wed_yn.Location = New System.Drawing.Point(152, 104)
        Me.wed_yn.Name = "wed_yn"
        Me.wed_yn.Size = New System.Drawing.Size(100, 21)
        Me.wed_yn.TabIndex = 134
        Me.wed_yn.Title = "결혼여부"
        Me.wed_yn.TitleWidth = 80
        '
        'addr1
        '
        Me.addr1.Location = New System.Drawing.Point(260, 104)
        Me.addr1.Name = "addr1"
        Me.addr1.Size = New System.Drawing.Size(496, 21)
        Me.addr1.TabIndex = 142
        Me.addr1.Title = "주소1"
        '
        'XtraTabPage1_1
        '
        Me.XtraTabPage1_1.Controls.Add(Me.blood_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.ms_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.kind_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.rank1_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.hcap_yn)
        Me.XtraTabPage1_1.Controls.Add(Me.job_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.spc_yn)
        Me.XtraTabPage1_1.Controls.Add(Me.fr_dt)
        Me.XtraTabPage1_1.Controls.Add(Me.to_dt)
        Me.XtraTabPage1_1.Controls.Add(Me.hi)
        Me.XtraTabPage1_1.Controls.Add(Me.blood_rh_bc)
        Me.XtraTabPage1_1.Controls.Add(Me.weight)
        Me.XtraTabPage1_1.Controls.Add(Me.cblind_chk)
        Me.XtraTabPage1_1.Controls.Add(Me.sight_left)
        Me.XtraTabPage1_1.Controls.Add(Me.hcap_lv)
        Me.XtraTabPage1_1.Controls.Add(Me.sight_right)
        Me.XtraTabPage1_1.Controls.Add(Me.hcap_bc)
        Me.XtraTabPage1_1.Name = "XtraTabPage1_1"
        Me.XtraTabPage1_1.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage1_1.Text = "병역/신체"
        '
        'blood_bc
        '
        Me.blood_bc.Location = New System.Drawing.Point(508, 56)
        Me.blood_bc.Name = "blood_bc"
        Me.blood_bc.Size = New System.Drawing.Size(182, 21)
        Me.blood_bc.TabIndex = 127
        Me.blood_bc.Title = "혈액형(ABO/RH)"
        '
        'ms_bc
        '
        Me.ms_bc.Location = New System.Drawing.Point(12, 32)
        Me.ms_bc.Name = "ms_bc"
        Me.ms_bc.Size = New System.Drawing.Size(240, 21)
        Me.ms_bc.TabIndex = 147
        Me.ms_bc.Title = "역종 구분"
        '
        'kind_bc
        '
        Me.kind_bc.Location = New System.Drawing.Point(12, 56)
        Me.kind_bc.Name = "kind_bc"
        Me.kind_bc.Size = New System.Drawing.Size(240, 21)
        Me.kind_bc.TabIndex = 148
        Me.kind_bc.Title = "군별 구분"
        '
        'rank1_bc
        '
        Me.rank1_bc.Location = New System.Drawing.Point(12, 80)
        Me.rank1_bc.Name = "rank1_bc"
        Me.rank1_bc.Size = New System.Drawing.Size(240, 21)
        Me.rank1_bc.TabIndex = 149
        Me.rank1_bc.Title = "계급 구분"
        '
        'hcap_yn
        '
        Me.hcap_yn.Caption = ""
        Me.hcap_yn.Location = New System.Drawing.Point(260, 8)
        Me.hcap_yn.Name = "hcap_yn"
        Me.hcap_yn.Size = New System.Drawing.Size(240, 21)
        Me.hcap_yn.TabIndex = 145
        Me.hcap_yn.Title = "장애여부"
        '
        'job_bc
        '
        Me.job_bc.Location = New System.Drawing.Point(12, 104)
        Me.job_bc.Name = "job_bc"
        Me.job_bc.Size = New System.Drawing.Size(240, 21)
        Me.job_bc.TabIndex = 150
        Me.job_bc.Title = "병과 구분"
        '
        'spc_yn
        '
        Me.spc_yn.Caption = ""
        Me.spc_yn.Location = New System.Drawing.Point(12, 8)
        Me.spc_yn.Name = "spc_yn"
        Me.spc_yn.Size = New System.Drawing.Size(240, 21)
        Me.spc_yn.TabIndex = 154
        Me.spc_yn.Title = "병역특례여부"
        '
        'fr_dt
        '
        Me.fr_dt.Location = New System.Drawing.Point(260, 80)
        Me.fr_dt.Name = "fr_dt"
        Me.fr_dt.Size = New System.Drawing.Size(240, 21)
        Me.fr_dt.TabIndex = 152
        Me.fr_dt.Title = "복무 시작일"
        '
        'to_dt
        '
        Me.to_dt.Location = New System.Drawing.Point(260, 104)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(240, 21)
        Me.to_dt.TabIndex = 153
        Me.to_dt.Title = "복무 종료일"
        '
        'hi
        '
        Me.hi.Location = New System.Drawing.Point(508, 8)
        Me.hi.Name = "hi"
        Me.hi.Size = New System.Drawing.Size(240, 21)
        Me.hi.TabIndex = 125
        Me.hi.Title = "신장 (Cm)"
        '
        'blood_rh_bc
        '
        Me.blood_rh_bc.Location = New System.Drawing.Point(572, 56)
        Me.blood_rh_bc.Name = "blood_rh_bc"
        Me.blood_rh_bc.Size = New System.Drawing.Size(176, 21)
        Me.blood_rh_bc.TabIndex = 128
        Me.blood_rh_bc.Title = "RH"
        '
        'weight
        '
        Me.weight.Location = New System.Drawing.Point(508, 32)
        Me.weight.Name = "weight"
        Me.weight.Size = New System.Drawing.Size(240, 21)
        Me.weight.TabIndex = 126
        Me.weight.Title = "체중 (Kg)"
        '
        'cblind_chk
        '
        Me.cblind_chk.Caption = ""
        Me.cblind_chk.Location = New System.Drawing.Point(508, 104)
        Me.cblind_chk.Name = "cblind_chk"
        Me.cblind_chk.Size = New System.Drawing.Size(240, 21)
        Me.cblind_chk.TabIndex = 129
        Me.cblind_chk.Title = "색맹여부"
        '
        'sight_left
        '
        Me.sight_left.Location = New System.Drawing.Point(508, 80)
        Me.sight_left.Name = "sight_left"
        Me.sight_left.Size = New System.Drawing.Size(182, 21)
        Me.sight_left.TabIndex = 130
        Me.sight_left.Title = "시력(좌/우)"
        '
        'hcap_lv
        '
        Me.hcap_lv.Location = New System.Drawing.Point(260, 56)
        Me.hcap_lv.Name = "hcap_lv"
        Me.hcap_lv.Size = New System.Drawing.Size(240, 21)
        Me.hcap_lv.TabIndex = 133
        Me.hcap_lv.Title = "장애등급"
        '
        'sight_right
        '
        Me.sight_right.Location = New System.Drawing.Point(572, 80)
        Me.sight_right.Name = "sight_right"
        Me.sight_right.Size = New System.Drawing.Size(176, 21)
        Me.sight_right.TabIndex = 131
        Me.sight_right.Title = "시력(우)"
        '
        'hcap_bc
        '
        Me.hcap_bc.Location = New System.Drawing.Point(260, 32)
        Me.hcap_bc.Name = "hcap_bc"
        Me.hcap_bc.Size = New System.Drawing.Size(240, 21)
        Me.hcap_bc.TabIndex = 132
        Me.hcap_bc.Title = "장애구분"
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g20)
        Me.XtraTabPage2.Controls.Add(Me.Panel4)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage2.Text = "가족사항"
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.ReadOnly = False
        Me.g20.RecordNavigator = False
        Me.g20.RowHeight = -1
        Me.g20.Size = New System.Drawing.Size(1046, 209)
        Me.g20.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.AutoScroll = True
        Me.Panel4.AutoSize = True
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1046, 209)
        Me.Panel4.TabIndex = 1
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.AutoScroll = True
        Me.XtraTabPage3.Controls.Add(Me.g30)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage3.Text = "학력사항"
        '
        'g30
        '
        Me.g30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g30.Location = New System.Drawing.Point(0, 0)
        Me.g30.Name = "g30"
        Me.g30.ReadOnly = False
        Me.g30.RecordNavigator = False
        Me.g30.RowHeight = -1
        Me.g30.Size = New System.Drawing.Size(1046, 209)
        Me.g30.TabIndex = 0
        '
        'XtraTabPage4
        '
        Me.XtraTabPage4.AutoScroll = True
        Me.XtraTabPage4.Controls.Add(Me.g40)
        Me.XtraTabPage4.Name = "XtraTabPage4"
        Me.XtraTabPage4.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage4.Text = "경력사항"
        '
        'g40
        '
        Me.g40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g40.Location = New System.Drawing.Point(0, 0)
        Me.g40.Name = "g40"
        Me.g40.ReadOnly = False
        Me.g40.RecordNavigator = False
        Me.g40.RowHeight = -1
        Me.g40.Size = New System.Drawing.Size(1046, 209)
        Me.g40.TabIndex = 0
        '
        'XtraTabPage5
        '
        Me.XtraTabPage5.AutoScroll = True
        Me.XtraTabPage5.Controls.Add(Me.g50)
        Me.XtraTabPage5.Name = "XtraTabPage5"
        Me.XtraTabPage5.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage5.Text = "발령사항"
        '
        'g50
        '
        Me.g50.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g50.Location = New System.Drawing.Point(0, 0)
        Me.g50.Name = "g50"
        Me.g50.ReadOnly = False
        Me.g50.RecordNavigator = False
        Me.g50.RowHeight = -1
        Me.g50.Size = New System.Drawing.Size(1046, 209)
        Me.g50.TabIndex = 0
        '
        'XtraTabPage6
        '
        Me.XtraTabPage6.AutoScroll = True
        Me.XtraTabPage6.Controls.Add(Me.g60)
        Me.XtraTabPage6.Name = "XtraTabPage6"
        Me.XtraTabPage6.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage6.Text = "상벌사항"
        '
        'g60
        '
        Me.g60.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g60.Location = New System.Drawing.Point(0, 0)
        Me.g60.Name = "g60"
        Me.g60.ReadOnly = False
        Me.g60.RecordNavigator = False
        Me.g60.RowHeight = -1
        Me.g60.Size = New System.Drawing.Size(1046, 209)
        Me.g60.TabIndex = 0
        '
        'XtraTabPage7
        '
        Me.XtraTabPage7.AutoScroll = True
        Me.XtraTabPage7.Controls.Add(Me.g70)
        Me.XtraTabPage7.Name = "XtraTabPage7"
        Me.XtraTabPage7.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage7.Text = "외국어"
        '
        'g70
        '
        Me.g70.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g70.Location = New System.Drawing.Point(0, 0)
        Me.g70.Name = "g70"
        Me.g70.ReadOnly = False
        Me.g70.RecordNavigator = False
        Me.g70.RowHeight = -1
        Me.g70.Size = New System.Drawing.Size(1046, 209)
        Me.g70.TabIndex = 0
        '
        'XtraTabPage8
        '
        Me.XtraTabPage8.AutoScroll = True
        Me.XtraTabPage8.Controls.Add(Me.g80)
        Me.XtraTabPage8.Name = "XtraTabPage8"
        Me.XtraTabPage8.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage8.Text = "자격면허"
        '
        'g80
        '
        Me.g80.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g80.Location = New System.Drawing.Point(0, 0)
        Me.g80.Name = "g80"
        Me.g80.ReadOnly = False
        Me.g80.RecordNavigator = False
        Me.g80.RowHeight = -1
        Me.g80.Size = New System.Drawing.Size(1046, 209)
        Me.g80.TabIndex = 0
        '
        'XtraTabPage9
        '
        Me.XtraTabPage9.AutoScroll = True
        Me.XtraTabPage9.Controls.Add(Me.g90)
        Me.XtraTabPage9.Name = "XtraTabPage9"
        Me.XtraTabPage9.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage9.Text = "교육사항"
        '
        'g90
        '
        Me.g90.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g90.Location = New System.Drawing.Point(0, 0)
        Me.g90.Name = "g90"
        Me.g90.ReadOnly = False
        Me.g90.RecordNavigator = False
        Me.g90.RowHeight = -1
        Me.g90.Size = New System.Drawing.Size(1046, 209)
        Me.g90.TabIndex = 0
        '
        'XtraTabPage10
        '
        Me.XtraTabPage10.Controls.Add(Me.g95)
        Me.XtraTabPage10.Name = "XtraTabPage10"
        Me.XtraTabPage10.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage10.Text = "출장파견"
        '
        'g95
        '
        Me.g95.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g95.Location = New System.Drawing.Point(0, 0)
        Me.g95.Name = "g95"
        Me.g95.ReadOnly = False
        Me.g95.RecordNavigator = False
        Me.g95.RowHeight = -1
        Me.g95.Size = New System.Drawing.Size(1046, 209)
        Me.g95.TabIndex = 1
        '
        'XtraTabPage11
        '
        Me.XtraTabPage11.Controls.Add(Me.g96)
        Me.XtraTabPage11.Name = "XtraTabPage11"
        Me.XtraTabPage11.Size = New System.Drawing.Size(1046, 209)
        Me.XtraTabPage11.Text = "계좌이력"
        '
        'g96
        '
        Me.g96.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g96.Location = New System.Drawing.Point(0, 0)
        Me.g96.Name = "g96"
        Me.g96.ReadOnly = False
        Me.g96.RecordNavigator = False
        Me.g96.RowHeight = -1
        Me.g96.Size = New System.Drawing.Size(1046, 209)
        Me.g96.TabIndex = 2
        '
        'HRA100
        '
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "HRA100"
        Me.Size = New System.Drawing.Size(1326, 643)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.pnlshow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshow.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage1_1.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.XtraTabPage2.PerformLayout()
        Me.XtraTabPage3.ResumeLayout(False)
        Me.XtraTabPage4.ResumeLayout(False)
        Me.XtraTabPage5.ResumeLayout(False)
        Me.XtraTabPage6.ResumeLayout(False)
        Me.XtraTabPage7.ResumeLayout(False)
        Me.XtraTabPage8.ResumeLayout(False)
        Me.XtraTabPage9.ResumeLayout(False)
        Me.XtraTabPage10.ResumeLayout(False)
        Me.XtraTabPage11.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents f_bs_cd As Frame7.eCombo
    Friend WithEvents f_dept_cd As Frame7.eText
    Friend WithEvents EPanel3 As Frame7.ePanel
    Friend WithEvents high_bc As Frame7.eCombo
    Friend WithEvents duty_bc As Frame7.eCombo
    Friend WithEvents rank_bc As Frame7.eCombo
    Friend WithEvents entr_bc As Frame7.eCombo
    Friend WithEvents hire_bc As Frame7.eCombo
    Friend WithEvents stat_bc As Frame7.eCombo
    Friend WithEvents work_kd As Frame7.eCombo
    Friend WithEvents work_bc As Frame7.eCombo
    Friend WithEvents retr_dt As Frame7.eDate
    Friend WithEvents retr_rmk As Frame7.eText
    Friend WithEvents pay_kd As Frame7.eCombo
    Friend WithEvents luna_yn As Frame7.eCheck
    Friend WithEvents bir_dt As Frame7.eDate
    Friend WithEvents gen_ty As Frame7.eCombo
    Friend WithEvents reg_no As Frame7.eText
    Friend WithEvents retr_bc As Frame7.eCombo
    Friend WithEvents pro_to As Frame7.eDate
    Friend WithEvents nat_cd As Frame7.eCombo
    Friend WithEvents bs_cd As Frame7.eCombo
    Friend WithEvents pro_fr As Frame7.eDate
    Friend WithEvents hire2_dt As Frame7.eDate
    Friend WithEvents hire_dt As Frame7.eDate
    Friend WithEvents dept_nm As Frame7.eText
    Friend WithEvents emp_no As Frame7.eText
    Friend WithEvents dept_cd As Frame7.eText
    Friend WithEvents emp_nm As Frame7.eText
    Friend WithEvents emp_nm2 As Frame7.eText
    Friend WithEvents emp_nm3 As Frame7.eText
    Friend WithEvents card_no As Frame7.eText
    Friend WithEvents g10 As Frame7.eGrid
    Friend WithEvents photo As Frame7.eImage
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents work_bs As Frame7.eCombo
    Friend WithEvents spc_yn As Frame7.eCheck
    Friend WithEvents to_dt As Frame7.eDate
    Friend WithEvents fr_dt As Frame7.eDate
    Friend WithEvents job_bc As Frame7.eCombo
    Friend WithEvents rank1_bc As Frame7.eCombo
    Friend WithEvents kind_bc As Frame7.eCombo
    Friend WithEvents ms_bc As Frame7.eCombo
    Friend WithEvents hcap_yn As Frame7.eCheck
    Friend WithEvents org_addr As Frame7.eText
    Friend WithEvents zip_cd As Frame7.eText
    Friend WithEvents email As Frame7.eText
    Friend WithEvents car_no As Frame7.eText
    Friend WithEvents mobile As Frame7.eText
    Friend WithEvents home_tel As Frame7.eText
    Friend WithEvents relig_bc As Frame7.eCombo
    Friend WithEvents dept_tel As Frame7.eText
    Friend WithEvents wed_yn As Frame7.eCheck
    Friend WithEvents hcap_lv As Frame7.eText
    Friend WithEvents hcap_bc As Frame7.eCombo
    Friend WithEvents sight_left As Frame7.eText
    Friend WithEvents cblind_chk As Frame7.eCheck
    Friend WithEvents blood_bc As Frame7.eCombo
    Friend WithEvents weight As Frame7.eText
    Friend WithEvents hi As Frame7.eText
    Friend WithEvents blood_rh_bc As Frame7.eCombo
    Friend WithEvents sight_right As Frame7.eText
    Friend WithEvents addr1 As Frame7.eText
    Friend WithEvents merit_no As Frame7.eText
    Friend WithEvents merit_bc As Frame7.eCombo
    Friend WithEvents g20 As Frame7.eGrid
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g30 As Frame7.eGrid
    Friend WithEvents XtraTabPage4 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g40 As Frame7.eGrid
    Friend WithEvents XtraTabPage5 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g50 As Frame7.eGrid
    Friend WithEvents XtraTabPage6 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents g60 As Frame7.eGrid
    Friend WithEvents XtraTabPage7 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g70 As Frame7.eGrid
    Friend WithEvents XtraTabPage8 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g80 As Frame7.eGrid
    Friend WithEvents XtraTabPage9 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g90 As Frame7.eGrid
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents hobby1 As Frame7.eText
    Friend WithEvents hobby2 As Frame7.eText
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents f_stat_bc As Frame7.eCheckCombo
    Friend WithEvents work_dept As Frame7.eText
    Friend WithEvents work_dept_nm As Frame7.eText
    Friend WithEvents f_emp_nm As Frame7.eText
    Friend WithEvents f_emp_no As Frame7.eText
    Friend WithEvents f_dept_nm As Frame7.eText
    Friend WithEvents f_co_cd As Frame7.eCombo
    Friend WithEvents f_retr_dt1 As Frame7.eDate
    Friend WithEvents f_retr_dt2 As Frame7.eDate
    Friend WithEvents f_hire_dt1 As Frame7.eDate
    Friend WithEvents f_hire_dt2 As Frame7.eDate
    Friend WithEvents f_high_bc As Frame7.eCombo
    Friend WithEvents f_duty_bc As Frame7.eCombo
    Friend WithEvents f_dept_yn As Frame7.eCheck
    Friend WithEvents XtraTabPage10 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g95 As Frame7.eGrid
    Friend WithEvents btn_pic As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents XtraTabPage1_1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents step_bc As Frame7.eCombo
    Friend WithEvents grp_bc As Frame7.eCombo
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents cc_cd As Frame7.eCombo
    Friend WithEvents fac_cd As Frame7.eCombo
    Friend WithEvents sum_bc As Frame7.eCombo
    Friend WithEvents age As Frame7.eText
    Friend WithEvents work_mon As Frame7.eText
    Friend WithEvents eval_bc As Frame7.eCombo
    Friend WithEvents XtraTabPage11 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g96 As Frame7.eGrid
    Friend WithEvents woman_yn As Frame7.eCheck
    Friend WithEvents send_bc As Frame7.eCombo
    Friend WithEvents job_nm As Frame7.eText
    Friend WithEvents btn_show As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents pnlshow As Frame7.ePanel
    Friend WithEvents f_work_kd As Frame7.eCombo

End Class
