﻿Imports Frame7
Imports Base7
Imports Base7.Shared

Public Class LEC100

    Private Sub g10_CellValueChanging(ByVal sender As Object, ByVal ColumnName As String, ByVal RowIndex As Integer, ByRef Value As Object) Handles g10.CellValueChanging
        Dim custCnt As Integer
        Dim CustCd As String

        If ColumnName = "chk" Then
            If Value = "1" Then
                CustCd = g10.Text("cust_cd")

                '  동일 거래처  체크
                For iRow = 0 To g10.RowCount - 1
                    If CustCd <> g10.Text("cust_cd", iRow) And g10.ToBool("chk", iRow) Then
                        custCnt = ToDec(custCnt) + 1
                    End If
                Next

                If custCnt > 0 Then
                    MsgBox("동일한 거래처만 처리 가능 합니다")
                    g10.UpdateRow()
                    g10.Text("qty") = ""
                    g10.Text("chk", RowIndex) = ""


                    Exit Sub
                End If

                g10.Text("qty") = g10.Text("rem_qty")
            Else
                g10.Text("qty") = ""
            End If

        End If

    End Sub


    Private Sub btn_do_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_do.Click

        '선택 건수 확인
        If g10.CheckedRows("chk") = 0 Then
            Exit Sub
        End If

        Dim menuName As String = "LEC110"
        Dim ctr As Object = Parameter.MainFrame.Frame.CallMenuForm(menuName)

        ctr.Open3(g10.DataSet)

        'Dim Err_str As String


        'Err_str = ""

        'If in_fac.Text = "" Then
        '    Err_str = Err_str + "입고공장 누락"
        'End If

        'If in_wh.Text = "" Then
        '    Err_str = Err_str + "입고창고 누락"
        'End If
        'If dlv_dt.Text = "" Then
        '    Err_str = Err_str + "입고일자 누락"
        'End If


        'If Err_str <> "" Then
        '    MsgBox(Err_str)
        '    Exit Sub
        'End If

        'If MessageYesNoCancel("납품 등록 하시겠습니까 ?") = MsgBoxResult.Yes Then
        '    Me.Save()
        '    dlv_no.Text = ""
        '    Me.Open()
        'End If
        ''Dim iRow As Integer = 0
        ''Dim menuName As String = "LEA100"
        ''Dim ctr As Object = Parameter.MainFrame.Frame.CallMenuForm(menuName)

        ''For iRow = 0 To g10.RowCount - 1
        ''    If g10.Text("chk", iRow) = "1" Then
        ''        ctr.Open2(g10.Text("po_no", iRow), g10.Text("po_sq", iRow), g10.Text("itm_id", iRow), g10.Text("itm_cd", iRow), g10.Text("itm_nm", iRow), g10.Text("spec", iRow), g10.Text("dlv_in_qty", iRow), _
        ''                  g10.Text("cust_cd", iRow), g10.Text("cust_nm", iRow), in_fac.Text, in_wh.Text, dlv_dt.Text)

        ''    End If
        ''Next
    End Sub

    Private Sub po_chk_CheckedChanged(sender As Object, e As System.EventArgs) Handles po_chk.CheckedChanged
        MyBase.Open()
    End Sub

End Class
