﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MES_PR1120C002
    Inherits Base7.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MES_PR1120C002))
        Me.SplitMain = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.BaseDt = New Frame7.eDate()
        Me.FAC_CD = New Frame7.eCombo()
        Me.GONG_CD = New Frame7.eCombo()
        Me.PanelMain = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PR_Rt1 = New System.Windows.Forms.ProgressBar()
        Me.RunRt1 = New System.Windows.Forms.Label()
        Me.MC_Nm1 = New System.Windows.Forms.Label()
        Me.NG_Rt1 = New System.Windows.Forms.Label()
        Me.CYCLE_Time1 = New System.Windows.Forms.Label()
        Me.PR_Qty1 = New System.Windows.Forms.Label()
        Me.Lot_No1 = New System.Windows.Forms.Label()
        Me.NG_Qty1 = New System.Windows.Forms.Label()
        Me.Tot_Qty1 = New System.Windows.Forms.Label()
        Me.JOB_Qty1 = New System.Windows.Forms.Label()
        Me.GD_Nm1 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.PR_Rt16 = New System.Windows.Forms.ProgressBar()
        Me.RunRt16 = New System.Windows.Forms.Label()
        Me.MC_Nm16 = New System.Windows.Forms.Label()
        Me.NG_Rt16 = New System.Windows.Forms.Label()
        Me.CYCLE_Time16 = New System.Windows.Forms.Label()
        Me.PR_Qty16 = New System.Windows.Forms.Label()
        Me.Lot_No16 = New System.Windows.Forms.Label()
        Me.NG_Qty16 = New System.Windows.Forms.Label()
        Me.Tot_Qty16 = New System.Windows.Forms.Label()
        Me.JOB_Qty16 = New System.Windows.Forms.Label()
        Me.GD_Nm16 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.PR_Rt12 = New System.Windows.Forms.ProgressBar()
        Me.RunRt12 = New System.Windows.Forms.Label()
        Me.MC_Nm12 = New System.Windows.Forms.Label()
        Me.NG_Rt12 = New System.Windows.Forms.Label()
        Me.CYCLE_Time12 = New System.Windows.Forms.Label()
        Me.PR_Qty12 = New System.Windows.Forms.Label()
        Me.Lot_No12 = New System.Windows.Forms.Label()
        Me.NG_Qty12 = New System.Windows.Forms.Label()
        Me.Tot_Qty12 = New System.Windows.Forms.Label()
        Me.JOB_Qty12 = New System.Windows.Forms.Label()
        Me.GD_Nm12 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.PR_Rt15 = New System.Windows.Forms.ProgressBar()
        Me.RunRt15 = New System.Windows.Forms.Label()
        Me.MC_Nm15 = New System.Windows.Forms.Label()
        Me.NG_Rt15 = New System.Windows.Forms.Label()
        Me.CYCLE_Time15 = New System.Windows.Forms.Label()
        Me.PR_Qty15 = New System.Windows.Forms.Label()
        Me.Lot_No15 = New System.Windows.Forms.Label()
        Me.NG_Qty15 = New System.Windows.Forms.Label()
        Me.Tot_Qty15 = New System.Windows.Forms.Label()
        Me.JOB_Qty15 = New System.Windows.Forms.Label()
        Me.GD_Nm15 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.PR_Rt11 = New System.Windows.Forms.ProgressBar()
        Me.RunRt11 = New System.Windows.Forms.Label()
        Me.MC_Nm11 = New System.Windows.Forms.Label()
        Me.NG_Rt11 = New System.Windows.Forms.Label()
        Me.CYCLE_Time11 = New System.Windows.Forms.Label()
        Me.PR_Qty11 = New System.Windows.Forms.Label()
        Me.Lot_No11 = New System.Windows.Forms.Label()
        Me.NG_Qty11 = New System.Windows.Forms.Label()
        Me.Tot_Qty11 = New System.Windows.Forms.Label()
        Me.JOB_Qty11 = New System.Windows.Forms.Label()
        Me.GD_Nm11 = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.PR_Rt14 = New System.Windows.Forms.ProgressBar()
        Me.RunRt14 = New System.Windows.Forms.Label()
        Me.MC_Nm14 = New System.Windows.Forms.Label()
        Me.NG_Rt14 = New System.Windows.Forms.Label()
        Me.CYCLE_Time14 = New System.Windows.Forms.Label()
        Me.PR_Qty14 = New System.Windows.Forms.Label()
        Me.Lot_No14 = New System.Windows.Forms.Label()
        Me.NG_Qty14 = New System.Windows.Forms.Label()
        Me.Tot_Qty14 = New System.Windows.Forms.Label()
        Me.JOB_Qty14 = New System.Windows.Forms.Label()
        Me.GD_Nm14 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.PR_Rt8 = New System.Windows.Forms.ProgressBar()
        Me.RunRt8 = New System.Windows.Forms.Label()
        Me.MC_Nm8 = New System.Windows.Forms.Label()
        Me.NG_Rt8 = New System.Windows.Forms.Label()
        Me.CYCLE_Time8 = New System.Windows.Forms.Label()
        Me.PR_Qty8 = New System.Windows.Forms.Label()
        Me.Lot_No8 = New System.Windows.Forms.Label()
        Me.NG_Qty8 = New System.Windows.Forms.Label()
        Me.Tot_Qty8 = New System.Windows.Forms.Label()
        Me.JOB_Qty8 = New System.Windows.Forms.Label()
        Me.GD_Nm8 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.PR_Rt13 = New System.Windows.Forms.ProgressBar()
        Me.RunRt13 = New System.Windows.Forms.Label()
        Me.MC_Nm13 = New System.Windows.Forms.Label()
        Me.NG_Rt13 = New System.Windows.Forms.Label()
        Me.CYCLE_Time13 = New System.Windows.Forms.Label()
        Me.PR_Qty13 = New System.Windows.Forms.Label()
        Me.Lot_No13 = New System.Windows.Forms.Label()
        Me.NG_Qty13 = New System.Windows.Forms.Label()
        Me.Tot_Qty13 = New System.Windows.Forms.Label()
        Me.JOB_Qty13 = New System.Windows.Forms.Label()
        Me.GD_Nm13 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.PR_Rt10 = New System.Windows.Forms.ProgressBar()
        Me.RunRt10 = New System.Windows.Forms.Label()
        Me.MC_Nm10 = New System.Windows.Forms.Label()
        Me.NG_Rt10 = New System.Windows.Forms.Label()
        Me.CYCLE_Time10 = New System.Windows.Forms.Label()
        Me.PR_Qty10 = New System.Windows.Forms.Label()
        Me.Lot_No10 = New System.Windows.Forms.Label()
        Me.NG_Qty10 = New System.Windows.Forms.Label()
        Me.Tot_Qty10 = New System.Windows.Forms.Label()
        Me.JOB_Qty10 = New System.Windows.Forms.Label()
        Me.GD_Nm10 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PR_Rt4 = New System.Windows.Forms.ProgressBar()
        Me.RunRt4 = New System.Windows.Forms.Label()
        Me.MC_Nm4 = New System.Windows.Forms.Label()
        Me.NG_Rt4 = New System.Windows.Forms.Label()
        Me.CYCLE_Time4 = New System.Windows.Forms.Label()
        Me.PR_Qty4 = New System.Windows.Forms.Label()
        Me.Lot_No4 = New System.Windows.Forms.Label()
        Me.NG_Qty4 = New System.Windows.Forms.Label()
        Me.Tot_Qty4 = New System.Windows.Forms.Label()
        Me.JOB_Qty4 = New System.Windows.Forms.Label()
        Me.GD_Nm4 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.PR_Rt9 = New System.Windows.Forms.ProgressBar()
        Me.RunRt9 = New System.Windows.Forms.Label()
        Me.MC_Nm9 = New System.Windows.Forms.Label()
        Me.NG_Rt9 = New System.Windows.Forms.Label()
        Me.CYCLE_Time9 = New System.Windows.Forms.Label()
        Me.PR_Qty9 = New System.Windows.Forms.Label()
        Me.Lot_No9 = New System.Windows.Forms.Label()
        Me.NG_Qty9 = New System.Windows.Forms.Label()
        Me.Tot_Qty9 = New System.Windows.Forms.Label()
        Me.JOB_Qty9 = New System.Windows.Forms.Label()
        Me.GD_Nm9 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.PR_Rt7 = New System.Windows.Forms.ProgressBar()
        Me.RunRt7 = New System.Windows.Forms.Label()
        Me.MC_Nm7 = New System.Windows.Forms.Label()
        Me.NG_Rt7 = New System.Windows.Forms.Label()
        Me.CYCLE_Time7 = New System.Windows.Forms.Label()
        Me.PR_Qty7 = New System.Windows.Forms.Label()
        Me.Lot_No7 = New System.Windows.Forms.Label()
        Me.NG_Qty7 = New System.Windows.Forms.Label()
        Me.Tot_Qty7 = New System.Windows.Forms.Label()
        Me.JOB_Qty7 = New System.Windows.Forms.Label()
        Me.GD_Nm7 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PR_Rt3 = New System.Windows.Forms.ProgressBar()
        Me.RunRt3 = New System.Windows.Forms.Label()
        Me.MC_Nm3 = New System.Windows.Forms.Label()
        Me.NG_Rt3 = New System.Windows.Forms.Label()
        Me.CYCLE_Time3 = New System.Windows.Forms.Label()
        Me.PR_Qty3 = New System.Windows.Forms.Label()
        Me.Lot_No3 = New System.Windows.Forms.Label()
        Me.NG_Qty3 = New System.Windows.Forms.Label()
        Me.Tot_Qty3 = New System.Windows.Forms.Label()
        Me.JOB_Qty3 = New System.Windows.Forms.Label()
        Me.GD_Nm3 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.PR_Rt6 = New System.Windows.Forms.ProgressBar()
        Me.RunRt6 = New System.Windows.Forms.Label()
        Me.MC_Nm6 = New System.Windows.Forms.Label()
        Me.NG_Rt6 = New System.Windows.Forms.Label()
        Me.CYCLE_Time6 = New System.Windows.Forms.Label()
        Me.PR_Qty6 = New System.Windows.Forms.Label()
        Me.Lot_No6 = New System.Windows.Forms.Label()
        Me.NG_Qty6 = New System.Windows.Forms.Label()
        Me.Tot_Qty6 = New System.Windows.Forms.Label()
        Me.JOB_Qty6 = New System.Windows.Forms.Label()
        Me.GD_Nm6 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.PR_Rt5 = New System.Windows.Forms.ProgressBar()
        Me.RunRt5 = New System.Windows.Forms.Label()
        Me.MC_Nm5 = New System.Windows.Forms.Label()
        Me.NG_Rt5 = New System.Windows.Forms.Label()
        Me.CYCLE_Time5 = New System.Windows.Forms.Label()
        Me.PR_Qty5 = New System.Windows.Forms.Label()
        Me.Lot_No5 = New System.Windows.Forms.Label()
        Me.NG_Qty5 = New System.Windows.Forms.Label()
        Me.Tot_Qty5 = New System.Windows.Forms.Label()
        Me.JOB_Qty5 = New System.Windows.Forms.Label()
        Me.GD_Nm5 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PR_Rt2 = New System.Windows.Forms.ProgressBar()
        Me.RunRt2 = New System.Windows.Forms.Label()
        Me.MC_Nm2 = New System.Windows.Forms.Label()
        Me.NG_Rt2 = New System.Windows.Forms.Label()
        Me.CYCLE_Time2 = New System.Windows.Forms.Label()
        Me.PR_Qty2 = New System.Windows.Forms.Label()
        Me.Lot_No2 = New System.Windows.Forms.Label()
        Me.NG_Qty2 = New System.Windows.Forms.Label()
        Me.Tot_Qty2 = New System.Windows.Forms.Label()
        Me.JOB_Qty2 = New System.Windows.Forms.Label()
        Me.GD_Nm2 = New System.Windows.Forms.Label()
        Me.SplitMain.Panel1.SuspendLayout()
        Me.SplitMain.Panel2.SuspendLayout()
        Me.SplitMain.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        Me.PanelMain.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitMain
        '
        Me.SplitMain.BackColor = System.Drawing.Color.Transparent
        Me.SplitMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitMain.Location = New System.Drawing.Point(0, 0)
        Me.SplitMain.Name = "SplitMain"
        Me.SplitMain.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitMain.Panel1
        '
        Me.SplitMain.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitMain.Panel2
        '
        Me.SplitMain.Panel2.AutoScroll = True
        Me.SplitMain.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.SplitMain.Panel2.Controls.Add(Me.PanelMain)
        Me.SplitMain.Size = New System.Drawing.Size(1300, 800)
        Me.SplitMain.SplitterDistance = 51
        Me.SplitMain.TabIndex = 5
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.BaseDt)
        Me.EPanel1.Controls.Add(Me.FAC_CD)
        Me.EPanel1.Controls.Add(Me.GONG_CD)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1300, 51)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     검색조건"
        '
        'BaseDt
        '
        Me.BaseDt.Location = New System.Drawing.Point(15, 26)
        Me.BaseDt.Name = "BaseDt"
        Me.BaseDt.Size = New System.Drawing.Size(199, 21)
        Me.BaseDt.TabIndex = 80
        Me.BaseDt.Title = "기준일자"
        Me.BaseDt.TitleWidth = 80
        '
        'FAC_CD
        '
        Me.FAC_CD.Location = New System.Drawing.Point(224, 26)
        Me.FAC_CD.Name = "FAC_CD"
        Me.FAC_CD.Size = New System.Drawing.Size(220, 21)
        Me.FAC_CD.TabIndex = 73
        Me.FAC_CD.Title = "공장"
        Me.FAC_CD.TitleWidth = 80
        '
        'GONG_CD
        '
        Me.GONG_CD.Location = New System.Drawing.Point(454, 26)
        Me.GONG_CD.Name = "GONG_CD"
        Me.GONG_CD.Size = New System.Drawing.Size(220, 21)
        Me.GONG_CD.TabIndex = 74
        Me.GONG_CD.Title = "공정구분"
        Me.GONG_CD.TitleWidth = 80
        '
        'PanelMain
        '
        Me.PanelMain.BackColor = System.Drawing.Color.Transparent
        Me.PanelMain.Controls.Add(Me.Panel1)
        Me.PanelMain.Controls.Add(Me.Panel16)
        Me.PanelMain.Controls.Add(Me.Panel12)
        Me.PanelMain.Controls.Add(Me.Panel15)
        Me.PanelMain.Controls.Add(Me.Panel11)
        Me.PanelMain.Controls.Add(Me.Panel14)
        Me.PanelMain.Controls.Add(Me.Panel8)
        Me.PanelMain.Controls.Add(Me.Panel13)
        Me.PanelMain.Controls.Add(Me.Panel10)
        Me.PanelMain.Controls.Add(Me.Panel4)
        Me.PanelMain.Controls.Add(Me.Panel9)
        Me.PanelMain.Controls.Add(Me.Panel7)
        Me.PanelMain.Controls.Add(Me.Panel3)
        Me.PanelMain.Controls.Add(Me.Panel6)
        Me.PanelMain.Controls.Add(Me.Panel5)
        Me.PanelMain.Controls.Add(Me.Panel2)
        Me.PanelMain.Location = New System.Drawing.Point(3, 3)
        Me.PanelMain.Name = "PanelMain"
        Me.PanelMain.Size = New System.Drawing.Size(1028, 643)
        Me.PanelMain.TabIndex = 17
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.PR_Rt1)
        Me.Panel1.Controls.Add(Me.RunRt1)
        Me.Panel1.Controls.Add(Me.MC_Nm1)
        Me.Panel1.Controls.Add(Me.NG_Rt1)
        Me.Panel1.Controls.Add(Me.CYCLE_Time1)
        Me.Panel1.Controls.Add(Me.PR_Qty1)
        Me.Panel1.Controls.Add(Me.Lot_No1)
        Me.Panel1.Controls.Add(Me.NG_Qty1)
        Me.Panel1.Controls.Add(Me.Tot_Qty1)
        Me.Panel1.Controls.Add(Me.JOB_Qty1)
        Me.Panel1.Controls.Add(Me.GD_Nm1)
        Me.Panel1.Location = New System.Drawing.Point(5, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(252, 155)
        Me.Panel1.TabIndex = 0
        '
        'PR_Rt1
        '
        Me.PR_Rt1.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt1.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt1.Name = "PR_Rt1"
        Me.PR_Rt1.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt1.Step = 5
        Me.PR_Rt1.TabIndex = 0
        '
        'RunRt1
        '
        Me.RunRt1.BackColor = System.Drawing.Color.Transparent
        Me.RunRt1.ForeColor = System.Drawing.Color.White
        Me.RunRt1.Location = New System.Drawing.Point(142, 4)
        Me.RunRt1.Name = "RunRt1"
        Me.RunRt1.Size = New System.Drawing.Size(103, 21)
        Me.RunRt1.TabIndex = 1
        Me.RunRt1.Text = "가동률 :     %"
        Me.RunRt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm1
        '
        Me.MC_Nm1.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm1.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm1.ForeColor = System.Drawing.Color.White
        Me.MC_Nm1.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm1.Name = "MC_Nm1"
        Me.MC_Nm1.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm1.TabIndex = 0
        Me.MC_Nm1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt1
        '
        Me.NG_Rt1.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt1.Name = "NG_Rt1"
        Me.NG_Rt1.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt1.TabIndex = 9
        Me.NG_Rt1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time1
        '
        Me.CYCLE_Time1.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time1.Name = "CYCLE_Time1"
        Me.CYCLE_Time1.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time1.TabIndex = 4
        Me.CYCLE_Time1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty1
        '
        Me.PR_Qty1.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty1.Name = "PR_Qty1"
        Me.PR_Qty1.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty1.TabIndex = 7
        Me.PR_Qty1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No1
        '
        Me.Lot_No1.Font = New System.Drawing.Font("굴림", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Lot_No1.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No1.Name = "Lot_No1"
        Me.Lot_No1.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No1.TabIndex = 2
        Me.Lot_No1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty1
        '
        Me.NG_Qty1.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty1.Name = "NG_Qty1"
        Me.NG_Qty1.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty1.TabIndex = 8
        Me.NG_Qty1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty1
        '
        Me.Tot_Qty1.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty1.Name = "Tot_Qty1"
        Me.Tot_Qty1.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty1.TabIndex = 6
        Me.Tot_Qty1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty1
        '
        Me.JOB_Qty1.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty1.Name = "JOB_Qty1"
        Me.JOB_Qty1.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty1.TabIndex = 5
        Me.JOB_Qty1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm1
        '
        Me.GD_Nm1.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm1.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm1.Name = "GD_Nm1"
        Me.GD_Nm1.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm1.TabIndex = 3
        Me.GD_Nm1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel16
        '
        Me.Panel16.BackgroundImage = CType(resources.GetObject("Panel16.BackgroundImage"), System.Drawing.Image)
        Me.Panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel16.Controls.Add(Me.PR_Rt16)
        Me.Panel16.Controls.Add(Me.RunRt16)
        Me.Panel16.Controls.Add(Me.MC_Nm16)
        Me.Panel16.Controls.Add(Me.NG_Rt16)
        Me.Panel16.Controls.Add(Me.CYCLE_Time16)
        Me.Panel16.Controls.Add(Me.PR_Qty16)
        Me.Panel16.Controls.Add(Me.Lot_No16)
        Me.Panel16.Controls.Add(Me.NG_Qty16)
        Me.Panel16.Controls.Add(Me.Tot_Qty16)
        Me.Panel16.Controls.Add(Me.JOB_Qty16)
        Me.Panel16.Controls.Add(Me.GD_Nm16)
        Me.Panel16.Location = New System.Drawing.Point(770, 477)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(252, 155)
        Me.Panel16.TabIndex = 15
        '
        'PR_Rt16
        '
        Me.PR_Rt16.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt16.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt16.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt16.Name = "PR_Rt16"
        Me.PR_Rt16.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt16.Step = 5
        Me.PR_Rt16.TabIndex = 44
        '
        'RunRt16
        '
        Me.RunRt16.BackColor = System.Drawing.Color.Transparent
        Me.RunRt16.ForeColor = System.Drawing.Color.White
        Me.RunRt16.Location = New System.Drawing.Point(142, 4)
        Me.RunRt16.Name = "RunRt16"
        Me.RunRt16.Size = New System.Drawing.Size(103, 21)
        Me.RunRt16.TabIndex = 45
        Me.RunRt16.Text = "가동률 :     %"
        Me.RunRt16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm16
        '
        Me.MC_Nm16.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm16.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm16.ForeColor = System.Drawing.Color.White
        Me.MC_Nm16.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm16.Name = "MC_Nm16"
        Me.MC_Nm16.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm16.TabIndex = 43
        Me.MC_Nm16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt16
        '
        Me.NG_Rt16.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt16.Name = "NG_Rt16"
        Me.NG_Rt16.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt16.TabIndex = 53
        Me.NG_Rt16.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time16
        '
        Me.CYCLE_Time16.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time16.Name = "CYCLE_Time16"
        Me.CYCLE_Time16.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time16.TabIndex = 48
        Me.CYCLE_Time16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty16
        '
        Me.PR_Qty16.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty16.Name = "PR_Qty16"
        Me.PR_Qty16.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty16.TabIndex = 51
        Me.PR_Qty16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No16
        '
        Me.Lot_No16.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No16.Name = "Lot_No16"
        Me.Lot_No16.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No16.TabIndex = 46
        Me.Lot_No16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty16
        '
        Me.NG_Qty16.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty16.Name = "NG_Qty16"
        Me.NG_Qty16.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty16.TabIndex = 52
        Me.NG_Qty16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty16
        '
        Me.Tot_Qty16.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty16.Name = "Tot_Qty16"
        Me.Tot_Qty16.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty16.TabIndex = 50
        Me.Tot_Qty16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty16
        '
        Me.JOB_Qty16.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty16.Name = "JOB_Qty16"
        Me.JOB_Qty16.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty16.TabIndex = 49
        Me.JOB_Qty16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm16
        '
        Me.GD_Nm16.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm16.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm16.Name = "GD_Nm16"
        Me.GD_Nm16.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm16.TabIndex = 47
        Me.GD_Nm16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel12
        '
        Me.Panel12.BackgroundImage = CType(resources.GetObject("Panel12.BackgroundImage"), System.Drawing.Image)
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.PR_Rt12)
        Me.Panel12.Controls.Add(Me.RunRt12)
        Me.Panel12.Controls.Add(Me.MC_Nm12)
        Me.Panel12.Controls.Add(Me.NG_Rt12)
        Me.Panel12.Controls.Add(Me.CYCLE_Time12)
        Me.Panel12.Controls.Add(Me.PR_Qty12)
        Me.Panel12.Controls.Add(Me.Lot_No12)
        Me.Panel12.Controls.Add(Me.NG_Qty12)
        Me.Panel12.Controls.Add(Me.Tot_Qty12)
        Me.Panel12.Controls.Add(Me.JOB_Qty12)
        Me.Panel12.Controls.Add(Me.GD_Nm12)
        Me.Panel12.Location = New System.Drawing.Point(770, 319)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(252, 155)
        Me.Panel12.TabIndex = 11
        '
        'PR_Rt12
        '
        Me.PR_Rt12.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt12.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt12.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt12.Name = "PR_Rt12"
        Me.PR_Rt12.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt12.Step = 5
        Me.PR_Rt12.TabIndex = 44
        '
        'RunRt12
        '
        Me.RunRt12.BackColor = System.Drawing.Color.Transparent
        Me.RunRt12.ForeColor = System.Drawing.Color.White
        Me.RunRt12.Location = New System.Drawing.Point(142, 4)
        Me.RunRt12.Name = "RunRt12"
        Me.RunRt12.Size = New System.Drawing.Size(103, 21)
        Me.RunRt12.TabIndex = 45
        Me.RunRt12.Text = "가동률 :     %"
        Me.RunRt12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm12
        '
        Me.MC_Nm12.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm12.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm12.ForeColor = System.Drawing.Color.White
        Me.MC_Nm12.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm12.Name = "MC_Nm12"
        Me.MC_Nm12.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm12.TabIndex = 43
        Me.MC_Nm12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt12
        '
        Me.NG_Rt12.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt12.Name = "NG_Rt12"
        Me.NG_Rt12.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt12.TabIndex = 53
        Me.NG_Rt12.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time12
        '
        Me.CYCLE_Time12.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time12.Name = "CYCLE_Time12"
        Me.CYCLE_Time12.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time12.TabIndex = 48
        Me.CYCLE_Time12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty12
        '
        Me.PR_Qty12.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty12.Name = "PR_Qty12"
        Me.PR_Qty12.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty12.TabIndex = 51
        Me.PR_Qty12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No12
        '
        Me.Lot_No12.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No12.Name = "Lot_No12"
        Me.Lot_No12.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No12.TabIndex = 46
        Me.Lot_No12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty12
        '
        Me.NG_Qty12.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty12.Name = "NG_Qty12"
        Me.NG_Qty12.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty12.TabIndex = 52
        Me.NG_Qty12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty12
        '
        Me.Tot_Qty12.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty12.Name = "Tot_Qty12"
        Me.Tot_Qty12.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty12.TabIndex = 50
        Me.Tot_Qty12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty12
        '
        Me.JOB_Qty12.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty12.Name = "JOB_Qty12"
        Me.JOB_Qty12.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty12.TabIndex = 49
        Me.JOB_Qty12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm12
        '
        Me.GD_Nm12.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm12.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm12.Name = "GD_Nm12"
        Me.GD_Nm12.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm12.TabIndex = 47
        Me.GD_Nm12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel15
        '
        Me.Panel15.BackgroundImage = CType(resources.GetObject("Panel15.BackgroundImage"), System.Drawing.Image)
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.PR_Rt15)
        Me.Panel15.Controls.Add(Me.RunRt15)
        Me.Panel15.Controls.Add(Me.MC_Nm15)
        Me.Panel15.Controls.Add(Me.NG_Rt15)
        Me.Panel15.Controls.Add(Me.CYCLE_Time15)
        Me.Panel15.Controls.Add(Me.PR_Qty15)
        Me.Panel15.Controls.Add(Me.Lot_No15)
        Me.Panel15.Controls.Add(Me.NG_Qty15)
        Me.Panel15.Controls.Add(Me.Tot_Qty15)
        Me.Panel15.Controls.Add(Me.JOB_Qty15)
        Me.Panel15.Controls.Add(Me.GD_Nm15)
        Me.Panel15.Location = New System.Drawing.Point(515, 477)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(252, 155)
        Me.Panel15.TabIndex = 14
        '
        'PR_Rt15
        '
        Me.PR_Rt15.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt15.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt15.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt15.Name = "PR_Rt15"
        Me.PR_Rt15.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt15.Step = 5
        Me.PR_Rt15.TabIndex = 44
        '
        'RunRt15
        '
        Me.RunRt15.BackColor = System.Drawing.Color.Transparent
        Me.RunRt15.ForeColor = System.Drawing.Color.White
        Me.RunRt15.Location = New System.Drawing.Point(142, 4)
        Me.RunRt15.Name = "RunRt15"
        Me.RunRt15.Size = New System.Drawing.Size(103, 21)
        Me.RunRt15.TabIndex = 45
        Me.RunRt15.Text = "가동률 :     %"
        Me.RunRt15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm15
        '
        Me.MC_Nm15.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm15.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm15.ForeColor = System.Drawing.Color.White
        Me.MC_Nm15.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm15.Name = "MC_Nm15"
        Me.MC_Nm15.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm15.TabIndex = 43
        Me.MC_Nm15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt15
        '
        Me.NG_Rt15.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt15.Name = "NG_Rt15"
        Me.NG_Rt15.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt15.TabIndex = 53
        Me.NG_Rt15.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time15
        '
        Me.CYCLE_Time15.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time15.Name = "CYCLE_Time15"
        Me.CYCLE_Time15.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time15.TabIndex = 48
        Me.CYCLE_Time15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty15
        '
        Me.PR_Qty15.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty15.Name = "PR_Qty15"
        Me.PR_Qty15.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty15.TabIndex = 51
        Me.PR_Qty15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No15
        '
        Me.Lot_No15.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No15.Name = "Lot_No15"
        Me.Lot_No15.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No15.TabIndex = 46
        Me.Lot_No15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty15
        '
        Me.NG_Qty15.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty15.Name = "NG_Qty15"
        Me.NG_Qty15.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty15.TabIndex = 52
        Me.NG_Qty15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty15
        '
        Me.Tot_Qty15.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty15.Name = "Tot_Qty15"
        Me.Tot_Qty15.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty15.TabIndex = 50
        Me.Tot_Qty15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty15
        '
        Me.JOB_Qty15.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty15.Name = "JOB_Qty15"
        Me.JOB_Qty15.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty15.TabIndex = 49
        Me.JOB_Qty15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm15
        '
        Me.GD_Nm15.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm15.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm15.Name = "GD_Nm15"
        Me.GD_Nm15.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm15.TabIndex = 47
        Me.GD_Nm15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel11
        '
        Me.Panel11.BackgroundImage = CType(resources.GetObject("Panel11.BackgroundImage"), System.Drawing.Image)
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.PR_Rt11)
        Me.Panel11.Controls.Add(Me.RunRt11)
        Me.Panel11.Controls.Add(Me.MC_Nm11)
        Me.Panel11.Controls.Add(Me.NG_Rt11)
        Me.Panel11.Controls.Add(Me.CYCLE_Time11)
        Me.Panel11.Controls.Add(Me.PR_Qty11)
        Me.Panel11.Controls.Add(Me.Lot_No11)
        Me.Panel11.Controls.Add(Me.NG_Qty11)
        Me.Panel11.Controls.Add(Me.Tot_Qty11)
        Me.Panel11.Controls.Add(Me.JOB_Qty11)
        Me.Panel11.Controls.Add(Me.GD_Nm11)
        Me.Panel11.Location = New System.Drawing.Point(515, 319)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(252, 155)
        Me.Panel11.TabIndex = 10
        '
        'PR_Rt11
        '
        Me.PR_Rt11.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt11.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt11.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt11.Name = "PR_Rt11"
        Me.PR_Rt11.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt11.Step = 5
        Me.PR_Rt11.TabIndex = 44
        '
        'RunRt11
        '
        Me.RunRt11.BackColor = System.Drawing.Color.Transparent
        Me.RunRt11.ForeColor = System.Drawing.Color.White
        Me.RunRt11.Location = New System.Drawing.Point(142, 4)
        Me.RunRt11.Name = "RunRt11"
        Me.RunRt11.Size = New System.Drawing.Size(103, 21)
        Me.RunRt11.TabIndex = 45
        Me.RunRt11.Text = "가동률 :     %"
        Me.RunRt11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm11
        '
        Me.MC_Nm11.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm11.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm11.ForeColor = System.Drawing.Color.White
        Me.MC_Nm11.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm11.Name = "MC_Nm11"
        Me.MC_Nm11.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm11.TabIndex = 43
        Me.MC_Nm11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt11
        '
        Me.NG_Rt11.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt11.Name = "NG_Rt11"
        Me.NG_Rt11.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt11.TabIndex = 53
        Me.NG_Rt11.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time11
        '
        Me.CYCLE_Time11.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time11.Name = "CYCLE_Time11"
        Me.CYCLE_Time11.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time11.TabIndex = 48
        Me.CYCLE_Time11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty11
        '
        Me.PR_Qty11.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty11.Name = "PR_Qty11"
        Me.PR_Qty11.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty11.TabIndex = 51
        Me.PR_Qty11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No11
        '
        Me.Lot_No11.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No11.Name = "Lot_No11"
        Me.Lot_No11.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No11.TabIndex = 46
        Me.Lot_No11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty11
        '
        Me.NG_Qty11.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty11.Name = "NG_Qty11"
        Me.NG_Qty11.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty11.TabIndex = 52
        Me.NG_Qty11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty11
        '
        Me.Tot_Qty11.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty11.Name = "Tot_Qty11"
        Me.Tot_Qty11.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty11.TabIndex = 50
        Me.Tot_Qty11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty11
        '
        Me.JOB_Qty11.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty11.Name = "JOB_Qty11"
        Me.JOB_Qty11.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty11.TabIndex = 49
        Me.JOB_Qty11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm11
        '
        Me.GD_Nm11.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm11.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm11.Name = "GD_Nm11"
        Me.GD_Nm11.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm11.TabIndex = 47
        Me.GD_Nm11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel14
        '
        Me.Panel14.BackgroundImage = CType(resources.GetObject("Panel14.BackgroundImage"), System.Drawing.Image)
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.PR_Rt14)
        Me.Panel14.Controls.Add(Me.RunRt14)
        Me.Panel14.Controls.Add(Me.MC_Nm14)
        Me.Panel14.Controls.Add(Me.NG_Rt14)
        Me.Panel14.Controls.Add(Me.CYCLE_Time14)
        Me.Panel14.Controls.Add(Me.PR_Qty14)
        Me.Panel14.Controls.Add(Me.Lot_No14)
        Me.Panel14.Controls.Add(Me.NG_Qty14)
        Me.Panel14.Controls.Add(Me.Tot_Qty14)
        Me.Panel14.Controls.Add(Me.JOB_Qty14)
        Me.Panel14.Controls.Add(Me.GD_Nm14)
        Me.Panel14.Location = New System.Drawing.Point(260, 477)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(252, 155)
        Me.Panel14.TabIndex = 13
        '
        'PR_Rt14
        '
        Me.PR_Rt14.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt14.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt14.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt14.Name = "PR_Rt14"
        Me.PR_Rt14.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt14.Step = 5
        Me.PR_Rt14.TabIndex = 44
        '
        'RunRt14
        '
        Me.RunRt14.BackColor = System.Drawing.Color.Transparent
        Me.RunRt14.ForeColor = System.Drawing.Color.White
        Me.RunRt14.Location = New System.Drawing.Point(142, 4)
        Me.RunRt14.Name = "RunRt14"
        Me.RunRt14.Size = New System.Drawing.Size(103, 21)
        Me.RunRt14.TabIndex = 45
        Me.RunRt14.Text = "가동률 :     %"
        Me.RunRt14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm14
        '
        Me.MC_Nm14.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm14.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm14.ForeColor = System.Drawing.Color.White
        Me.MC_Nm14.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm14.Name = "MC_Nm14"
        Me.MC_Nm14.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm14.TabIndex = 43
        Me.MC_Nm14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt14
        '
        Me.NG_Rt14.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt14.Name = "NG_Rt14"
        Me.NG_Rt14.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt14.TabIndex = 53
        Me.NG_Rt14.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time14
        '
        Me.CYCLE_Time14.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time14.Name = "CYCLE_Time14"
        Me.CYCLE_Time14.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time14.TabIndex = 48
        Me.CYCLE_Time14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty14
        '
        Me.PR_Qty14.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty14.Name = "PR_Qty14"
        Me.PR_Qty14.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty14.TabIndex = 51
        Me.PR_Qty14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No14
        '
        Me.Lot_No14.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No14.Name = "Lot_No14"
        Me.Lot_No14.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No14.TabIndex = 46
        Me.Lot_No14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty14
        '
        Me.NG_Qty14.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty14.Name = "NG_Qty14"
        Me.NG_Qty14.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty14.TabIndex = 52
        Me.NG_Qty14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty14
        '
        Me.Tot_Qty14.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty14.Name = "Tot_Qty14"
        Me.Tot_Qty14.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty14.TabIndex = 50
        Me.Tot_Qty14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty14
        '
        Me.JOB_Qty14.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty14.Name = "JOB_Qty14"
        Me.JOB_Qty14.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty14.TabIndex = 49
        Me.JOB_Qty14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm14
        '
        Me.GD_Nm14.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm14.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm14.Name = "GD_Nm14"
        Me.GD_Nm14.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm14.TabIndex = 47
        Me.GD_Nm14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel8
        '
        Me.Panel8.BackgroundImage = CType(resources.GetObject("Panel8.BackgroundImage"), System.Drawing.Image)
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.PR_Rt8)
        Me.Panel8.Controls.Add(Me.RunRt8)
        Me.Panel8.Controls.Add(Me.MC_Nm8)
        Me.Panel8.Controls.Add(Me.NG_Rt8)
        Me.Panel8.Controls.Add(Me.CYCLE_Time8)
        Me.Panel8.Controls.Add(Me.PR_Qty8)
        Me.Panel8.Controls.Add(Me.Lot_No8)
        Me.Panel8.Controls.Add(Me.NG_Qty8)
        Me.Panel8.Controls.Add(Me.Tot_Qty8)
        Me.Panel8.Controls.Add(Me.JOB_Qty8)
        Me.Panel8.Controls.Add(Me.GD_Nm8)
        Me.Panel8.Location = New System.Drawing.Point(770, 161)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(252, 155)
        Me.Panel8.TabIndex = 7
        '
        'PR_Rt8
        '
        Me.PR_Rt8.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt8.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt8.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt8.Name = "PR_Rt8"
        Me.PR_Rt8.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt8.Step = 5
        Me.PR_Rt8.TabIndex = 44
        '
        'RunRt8
        '
        Me.RunRt8.BackColor = System.Drawing.Color.Transparent
        Me.RunRt8.ForeColor = System.Drawing.Color.White
        Me.RunRt8.Location = New System.Drawing.Point(142, 4)
        Me.RunRt8.Name = "RunRt8"
        Me.RunRt8.Size = New System.Drawing.Size(103, 21)
        Me.RunRt8.TabIndex = 45
        Me.RunRt8.Text = "가동률 :     %"
        Me.RunRt8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm8
        '
        Me.MC_Nm8.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm8.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm8.ForeColor = System.Drawing.Color.White
        Me.MC_Nm8.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm8.Name = "MC_Nm8"
        Me.MC_Nm8.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm8.TabIndex = 43
        Me.MC_Nm8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt8
        '
        Me.NG_Rt8.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt8.Name = "NG_Rt8"
        Me.NG_Rt8.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt8.TabIndex = 53
        Me.NG_Rt8.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time8
        '
        Me.CYCLE_Time8.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time8.Name = "CYCLE_Time8"
        Me.CYCLE_Time8.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time8.TabIndex = 48
        Me.CYCLE_Time8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty8
        '
        Me.PR_Qty8.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty8.Name = "PR_Qty8"
        Me.PR_Qty8.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty8.TabIndex = 51
        Me.PR_Qty8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No8
        '
        Me.Lot_No8.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No8.Name = "Lot_No8"
        Me.Lot_No8.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No8.TabIndex = 46
        Me.Lot_No8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty8
        '
        Me.NG_Qty8.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty8.Name = "NG_Qty8"
        Me.NG_Qty8.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty8.TabIndex = 52
        Me.NG_Qty8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty8
        '
        Me.Tot_Qty8.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty8.Name = "Tot_Qty8"
        Me.Tot_Qty8.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty8.TabIndex = 50
        Me.Tot_Qty8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty8
        '
        Me.JOB_Qty8.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty8.Name = "JOB_Qty8"
        Me.JOB_Qty8.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty8.TabIndex = 49
        Me.JOB_Qty8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm8
        '
        Me.GD_Nm8.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm8.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm8.Name = "GD_Nm8"
        Me.GD_Nm8.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm8.TabIndex = 47
        Me.GD_Nm8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel13
        '
        Me.Panel13.BackgroundImage = CType(resources.GetObject("Panel13.BackgroundImage"), System.Drawing.Image)
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.PR_Rt13)
        Me.Panel13.Controls.Add(Me.RunRt13)
        Me.Panel13.Controls.Add(Me.MC_Nm13)
        Me.Panel13.Controls.Add(Me.NG_Rt13)
        Me.Panel13.Controls.Add(Me.CYCLE_Time13)
        Me.Panel13.Controls.Add(Me.PR_Qty13)
        Me.Panel13.Controls.Add(Me.Lot_No13)
        Me.Panel13.Controls.Add(Me.NG_Qty13)
        Me.Panel13.Controls.Add(Me.Tot_Qty13)
        Me.Panel13.Controls.Add(Me.JOB_Qty13)
        Me.Panel13.Controls.Add(Me.GD_Nm13)
        Me.Panel13.Location = New System.Drawing.Point(6, 477)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(252, 155)
        Me.Panel13.TabIndex = 12
        '
        'PR_Rt13
        '
        Me.PR_Rt13.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt13.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt13.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt13.Name = "PR_Rt13"
        Me.PR_Rt13.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt13.Step = 5
        Me.PR_Rt13.TabIndex = 44
        '
        'RunRt13
        '
        Me.RunRt13.BackColor = System.Drawing.Color.Transparent
        Me.RunRt13.ForeColor = System.Drawing.Color.White
        Me.RunRt13.Location = New System.Drawing.Point(142, 4)
        Me.RunRt13.Name = "RunRt13"
        Me.RunRt13.Size = New System.Drawing.Size(103, 21)
        Me.RunRt13.TabIndex = 45
        Me.RunRt13.Text = "가동률 :     %"
        Me.RunRt13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm13
        '
        Me.MC_Nm13.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm13.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm13.ForeColor = System.Drawing.Color.White
        Me.MC_Nm13.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm13.Name = "MC_Nm13"
        Me.MC_Nm13.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm13.TabIndex = 43
        Me.MC_Nm13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt13
        '
        Me.NG_Rt13.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt13.Name = "NG_Rt13"
        Me.NG_Rt13.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt13.TabIndex = 53
        Me.NG_Rt13.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time13
        '
        Me.CYCLE_Time13.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time13.Name = "CYCLE_Time13"
        Me.CYCLE_Time13.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time13.TabIndex = 48
        Me.CYCLE_Time13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty13
        '
        Me.PR_Qty13.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty13.Name = "PR_Qty13"
        Me.PR_Qty13.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty13.TabIndex = 51
        Me.PR_Qty13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No13
        '
        Me.Lot_No13.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No13.Name = "Lot_No13"
        Me.Lot_No13.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No13.TabIndex = 46
        Me.Lot_No13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty13
        '
        Me.NG_Qty13.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty13.Name = "NG_Qty13"
        Me.NG_Qty13.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty13.TabIndex = 52
        Me.NG_Qty13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty13
        '
        Me.Tot_Qty13.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty13.Name = "Tot_Qty13"
        Me.Tot_Qty13.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty13.TabIndex = 50
        Me.Tot_Qty13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty13
        '
        Me.JOB_Qty13.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty13.Name = "JOB_Qty13"
        Me.JOB_Qty13.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty13.TabIndex = 49
        Me.JOB_Qty13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm13
        '
        Me.GD_Nm13.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm13.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm13.Name = "GD_Nm13"
        Me.GD_Nm13.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm13.TabIndex = 47
        Me.GD_Nm13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel10
        '
        Me.Panel10.BackgroundImage = CType(resources.GetObject("Panel10.BackgroundImage"), System.Drawing.Image)
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.PR_Rt10)
        Me.Panel10.Controls.Add(Me.RunRt10)
        Me.Panel10.Controls.Add(Me.MC_Nm10)
        Me.Panel10.Controls.Add(Me.NG_Rt10)
        Me.Panel10.Controls.Add(Me.CYCLE_Time10)
        Me.Panel10.Controls.Add(Me.PR_Qty10)
        Me.Panel10.Controls.Add(Me.Lot_No10)
        Me.Panel10.Controls.Add(Me.NG_Qty10)
        Me.Panel10.Controls.Add(Me.Tot_Qty10)
        Me.Panel10.Controls.Add(Me.JOB_Qty10)
        Me.Panel10.Controls.Add(Me.GD_Nm10)
        Me.Panel10.Location = New System.Drawing.Point(260, 319)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(252, 155)
        Me.Panel10.TabIndex = 9
        '
        'PR_Rt10
        '
        Me.PR_Rt10.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt10.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt10.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt10.Name = "PR_Rt10"
        Me.PR_Rt10.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt10.Step = 5
        Me.PR_Rt10.TabIndex = 44
        '
        'RunRt10
        '
        Me.RunRt10.BackColor = System.Drawing.Color.Transparent
        Me.RunRt10.ForeColor = System.Drawing.Color.White
        Me.RunRt10.Location = New System.Drawing.Point(142, 4)
        Me.RunRt10.Name = "RunRt10"
        Me.RunRt10.Size = New System.Drawing.Size(103, 21)
        Me.RunRt10.TabIndex = 45
        Me.RunRt10.Text = "가동률 :     %"
        Me.RunRt10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm10
        '
        Me.MC_Nm10.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm10.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm10.ForeColor = System.Drawing.Color.White
        Me.MC_Nm10.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm10.Name = "MC_Nm10"
        Me.MC_Nm10.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm10.TabIndex = 43
        Me.MC_Nm10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt10
        '
        Me.NG_Rt10.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt10.Name = "NG_Rt10"
        Me.NG_Rt10.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt10.TabIndex = 53
        Me.NG_Rt10.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time10
        '
        Me.CYCLE_Time10.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time10.Name = "CYCLE_Time10"
        Me.CYCLE_Time10.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time10.TabIndex = 48
        Me.CYCLE_Time10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty10
        '
        Me.PR_Qty10.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty10.Name = "PR_Qty10"
        Me.PR_Qty10.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty10.TabIndex = 51
        Me.PR_Qty10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No10
        '
        Me.Lot_No10.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No10.Name = "Lot_No10"
        Me.Lot_No10.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No10.TabIndex = 46
        Me.Lot_No10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty10
        '
        Me.NG_Qty10.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty10.Name = "NG_Qty10"
        Me.NG_Qty10.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty10.TabIndex = 52
        Me.NG_Qty10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty10
        '
        Me.Tot_Qty10.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty10.Name = "Tot_Qty10"
        Me.Tot_Qty10.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty10.TabIndex = 50
        Me.Tot_Qty10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty10
        '
        Me.JOB_Qty10.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty10.Name = "JOB_Qty10"
        Me.JOB_Qty10.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty10.TabIndex = 49
        Me.JOB_Qty10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm10
        '
        Me.GD_Nm10.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm10.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm10.Name = "GD_Nm10"
        Me.GD_Nm10.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm10.TabIndex = 47
        Me.GD_Nm10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.PR_Rt4)
        Me.Panel4.Controls.Add(Me.RunRt4)
        Me.Panel4.Controls.Add(Me.MC_Nm4)
        Me.Panel4.Controls.Add(Me.NG_Rt4)
        Me.Panel4.Controls.Add(Me.CYCLE_Time4)
        Me.Panel4.Controls.Add(Me.PR_Qty4)
        Me.Panel4.Controls.Add(Me.Lot_No4)
        Me.Panel4.Controls.Add(Me.NG_Qty4)
        Me.Panel4.Controls.Add(Me.Tot_Qty4)
        Me.Panel4.Controls.Add(Me.JOB_Qty4)
        Me.Panel4.Controls.Add(Me.GD_Nm4)
        Me.Panel4.Location = New System.Drawing.Point(770, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(252, 155)
        Me.Panel4.TabIndex = 3
        '
        'PR_Rt4
        '
        Me.PR_Rt4.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt4.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt4.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt4.Name = "PR_Rt4"
        Me.PR_Rt4.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt4.Step = 5
        Me.PR_Rt4.TabIndex = 44
        '
        'RunRt4
        '
        Me.RunRt4.BackColor = System.Drawing.Color.Transparent
        Me.RunRt4.ForeColor = System.Drawing.Color.White
        Me.RunRt4.Location = New System.Drawing.Point(142, 4)
        Me.RunRt4.Name = "RunRt4"
        Me.RunRt4.Size = New System.Drawing.Size(103, 21)
        Me.RunRt4.TabIndex = 45
        Me.RunRt4.Text = "가동률 :     %"
        Me.RunRt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm4
        '
        Me.MC_Nm4.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm4.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm4.ForeColor = System.Drawing.Color.White
        Me.MC_Nm4.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm4.Name = "MC_Nm4"
        Me.MC_Nm4.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm4.TabIndex = 43
        Me.MC_Nm4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt4
        '
        Me.NG_Rt4.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt4.Name = "NG_Rt4"
        Me.NG_Rt4.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt4.TabIndex = 53
        Me.NG_Rt4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time4
        '
        Me.CYCLE_Time4.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time4.Name = "CYCLE_Time4"
        Me.CYCLE_Time4.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time4.TabIndex = 48
        Me.CYCLE_Time4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty4
        '
        Me.PR_Qty4.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty4.Name = "PR_Qty4"
        Me.PR_Qty4.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty4.TabIndex = 51
        Me.PR_Qty4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No4
        '
        Me.Lot_No4.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No4.Name = "Lot_No4"
        Me.Lot_No4.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No4.TabIndex = 46
        Me.Lot_No4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty4
        '
        Me.NG_Qty4.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty4.Name = "NG_Qty4"
        Me.NG_Qty4.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty4.TabIndex = 52
        Me.NG_Qty4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty4
        '
        Me.Tot_Qty4.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty4.Name = "Tot_Qty4"
        Me.Tot_Qty4.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty4.TabIndex = 50
        Me.Tot_Qty4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty4
        '
        Me.JOB_Qty4.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty4.Name = "JOB_Qty4"
        Me.JOB_Qty4.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty4.TabIndex = 49
        Me.JOB_Qty4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm4
        '
        Me.GD_Nm4.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm4.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm4.Name = "GD_Nm4"
        Me.GD_Nm4.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm4.TabIndex = 47
        Me.GD_Nm4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel9
        '
        Me.Panel9.BackgroundImage = CType(resources.GetObject("Panel9.BackgroundImage"), System.Drawing.Image)
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.PR_Rt9)
        Me.Panel9.Controls.Add(Me.RunRt9)
        Me.Panel9.Controls.Add(Me.MC_Nm9)
        Me.Panel9.Controls.Add(Me.NG_Rt9)
        Me.Panel9.Controls.Add(Me.CYCLE_Time9)
        Me.Panel9.Controls.Add(Me.PR_Qty9)
        Me.Panel9.Controls.Add(Me.Lot_No9)
        Me.Panel9.Controls.Add(Me.NG_Qty9)
        Me.Panel9.Controls.Add(Me.Tot_Qty9)
        Me.Panel9.Controls.Add(Me.JOB_Qty9)
        Me.Panel9.Controls.Add(Me.GD_Nm9)
        Me.Panel9.Location = New System.Drawing.Point(5, 319)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(252, 155)
        Me.Panel9.TabIndex = 8
        '
        'PR_Rt9
        '
        Me.PR_Rt9.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt9.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt9.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt9.Name = "PR_Rt9"
        Me.PR_Rt9.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt9.Step = 5
        Me.PR_Rt9.TabIndex = 44
        '
        'RunRt9
        '
        Me.RunRt9.BackColor = System.Drawing.Color.Transparent
        Me.RunRt9.ForeColor = System.Drawing.Color.White
        Me.RunRt9.Location = New System.Drawing.Point(142, 4)
        Me.RunRt9.Name = "RunRt9"
        Me.RunRt9.Size = New System.Drawing.Size(103, 21)
        Me.RunRt9.TabIndex = 45
        Me.RunRt9.Text = "가동률 :     %"
        Me.RunRt9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm9
        '
        Me.MC_Nm9.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm9.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm9.ForeColor = System.Drawing.Color.White
        Me.MC_Nm9.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm9.Name = "MC_Nm9"
        Me.MC_Nm9.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm9.TabIndex = 43
        Me.MC_Nm9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt9
        '
        Me.NG_Rt9.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt9.Name = "NG_Rt9"
        Me.NG_Rt9.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt9.TabIndex = 53
        Me.NG_Rt9.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time9
        '
        Me.CYCLE_Time9.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time9.Name = "CYCLE_Time9"
        Me.CYCLE_Time9.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time9.TabIndex = 48
        Me.CYCLE_Time9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty9
        '
        Me.PR_Qty9.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty9.Name = "PR_Qty9"
        Me.PR_Qty9.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty9.TabIndex = 51
        Me.PR_Qty9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No9
        '
        Me.Lot_No9.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No9.Name = "Lot_No9"
        Me.Lot_No9.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No9.TabIndex = 46
        Me.Lot_No9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty9
        '
        Me.NG_Qty9.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty9.Name = "NG_Qty9"
        Me.NG_Qty9.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty9.TabIndex = 52
        Me.NG_Qty9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty9
        '
        Me.Tot_Qty9.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty9.Name = "Tot_Qty9"
        Me.Tot_Qty9.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty9.TabIndex = 50
        Me.Tot_Qty9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty9
        '
        Me.JOB_Qty9.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty9.Name = "JOB_Qty9"
        Me.JOB_Qty9.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty9.TabIndex = 49
        Me.JOB_Qty9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm9
        '
        Me.GD_Nm9.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm9.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm9.Name = "GD_Nm9"
        Me.GD_Nm9.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm9.TabIndex = 47
        Me.GD_Nm9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel7
        '
        Me.Panel7.BackgroundImage = CType(resources.GetObject("Panel7.BackgroundImage"), System.Drawing.Image)
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.PR_Rt7)
        Me.Panel7.Controls.Add(Me.RunRt7)
        Me.Panel7.Controls.Add(Me.MC_Nm7)
        Me.Panel7.Controls.Add(Me.NG_Rt7)
        Me.Panel7.Controls.Add(Me.CYCLE_Time7)
        Me.Panel7.Controls.Add(Me.PR_Qty7)
        Me.Panel7.Controls.Add(Me.Lot_No7)
        Me.Panel7.Controls.Add(Me.NG_Qty7)
        Me.Panel7.Controls.Add(Me.Tot_Qty7)
        Me.Panel7.Controls.Add(Me.JOB_Qty7)
        Me.Panel7.Controls.Add(Me.GD_Nm7)
        Me.Panel7.Location = New System.Drawing.Point(515, 161)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(252, 155)
        Me.Panel7.TabIndex = 6
        '
        'PR_Rt7
        '
        Me.PR_Rt7.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt7.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt7.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt7.Name = "PR_Rt7"
        Me.PR_Rt7.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt7.Step = 5
        Me.PR_Rt7.TabIndex = 44
        '
        'RunRt7
        '
        Me.RunRt7.BackColor = System.Drawing.Color.Transparent
        Me.RunRt7.ForeColor = System.Drawing.Color.White
        Me.RunRt7.Location = New System.Drawing.Point(142, 4)
        Me.RunRt7.Name = "RunRt7"
        Me.RunRt7.Size = New System.Drawing.Size(103, 21)
        Me.RunRt7.TabIndex = 45
        Me.RunRt7.Text = "가동률 :     %"
        Me.RunRt7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm7
        '
        Me.MC_Nm7.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm7.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm7.ForeColor = System.Drawing.Color.White
        Me.MC_Nm7.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm7.Name = "MC_Nm7"
        Me.MC_Nm7.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm7.TabIndex = 43
        Me.MC_Nm7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt7
        '
        Me.NG_Rt7.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt7.Name = "NG_Rt7"
        Me.NG_Rt7.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt7.TabIndex = 53
        Me.NG_Rt7.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time7
        '
        Me.CYCLE_Time7.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time7.Name = "CYCLE_Time7"
        Me.CYCLE_Time7.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time7.TabIndex = 48
        Me.CYCLE_Time7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty7
        '
        Me.PR_Qty7.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty7.Name = "PR_Qty7"
        Me.PR_Qty7.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty7.TabIndex = 51
        Me.PR_Qty7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No7
        '
        Me.Lot_No7.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No7.Name = "Lot_No7"
        Me.Lot_No7.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No7.TabIndex = 46
        Me.Lot_No7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty7
        '
        Me.NG_Qty7.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty7.Name = "NG_Qty7"
        Me.NG_Qty7.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty7.TabIndex = 52
        Me.NG_Qty7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty7
        '
        Me.Tot_Qty7.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty7.Name = "Tot_Qty7"
        Me.Tot_Qty7.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty7.TabIndex = 50
        Me.Tot_Qty7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty7
        '
        Me.JOB_Qty7.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty7.Name = "JOB_Qty7"
        Me.JOB_Qty7.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty7.TabIndex = 49
        Me.JOB_Qty7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm7
        '
        Me.GD_Nm7.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm7.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm7.Name = "GD_Nm7"
        Me.GD_Nm7.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm7.TabIndex = 47
        Me.GD_Nm7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel3
        '
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.PR_Rt3)
        Me.Panel3.Controls.Add(Me.RunRt3)
        Me.Panel3.Controls.Add(Me.MC_Nm3)
        Me.Panel3.Controls.Add(Me.NG_Rt3)
        Me.Panel3.Controls.Add(Me.CYCLE_Time3)
        Me.Panel3.Controls.Add(Me.PR_Qty3)
        Me.Panel3.Controls.Add(Me.Lot_No3)
        Me.Panel3.Controls.Add(Me.NG_Qty3)
        Me.Panel3.Controls.Add(Me.Tot_Qty3)
        Me.Panel3.Controls.Add(Me.JOB_Qty3)
        Me.Panel3.Controls.Add(Me.GD_Nm3)
        Me.Panel3.Location = New System.Drawing.Point(515, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(252, 155)
        Me.Panel3.TabIndex = 2
        '
        'PR_Rt3
        '
        Me.PR_Rt3.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt3.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt3.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt3.Name = "PR_Rt3"
        Me.PR_Rt3.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt3.Step = 5
        Me.PR_Rt3.TabIndex = 44
        '
        'RunRt3
        '
        Me.RunRt3.BackColor = System.Drawing.Color.Transparent
        Me.RunRt3.ForeColor = System.Drawing.Color.White
        Me.RunRt3.Location = New System.Drawing.Point(142, 4)
        Me.RunRt3.Name = "RunRt3"
        Me.RunRt3.Size = New System.Drawing.Size(103, 21)
        Me.RunRt3.TabIndex = 45
        Me.RunRt3.Text = "가동률 :     %"
        Me.RunRt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm3
        '
        Me.MC_Nm3.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm3.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm3.ForeColor = System.Drawing.Color.White
        Me.MC_Nm3.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm3.Name = "MC_Nm3"
        Me.MC_Nm3.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm3.TabIndex = 43
        Me.MC_Nm3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt3
        '
        Me.NG_Rt3.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt3.Name = "NG_Rt3"
        Me.NG_Rt3.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt3.TabIndex = 53
        Me.NG_Rt3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time3
        '
        Me.CYCLE_Time3.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time3.Name = "CYCLE_Time3"
        Me.CYCLE_Time3.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time3.TabIndex = 48
        Me.CYCLE_Time3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty3
        '
        Me.PR_Qty3.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty3.Name = "PR_Qty3"
        Me.PR_Qty3.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty3.TabIndex = 51
        Me.PR_Qty3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No3
        '
        Me.Lot_No3.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No3.Name = "Lot_No3"
        Me.Lot_No3.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No3.TabIndex = 46
        Me.Lot_No3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty3
        '
        Me.NG_Qty3.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty3.Name = "NG_Qty3"
        Me.NG_Qty3.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty3.TabIndex = 52
        Me.NG_Qty3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty3
        '
        Me.Tot_Qty3.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty3.Name = "Tot_Qty3"
        Me.Tot_Qty3.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty3.TabIndex = 50
        Me.Tot_Qty3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty3
        '
        Me.JOB_Qty3.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty3.Name = "JOB_Qty3"
        Me.JOB_Qty3.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty3.TabIndex = 49
        Me.JOB_Qty3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm3
        '
        Me.GD_Nm3.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm3.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm3.Name = "GD_Nm3"
        Me.GD_Nm3.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm3.TabIndex = 47
        Me.GD_Nm3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel6
        '
        Me.Panel6.BackgroundImage = CType(resources.GetObject("Panel6.BackgroundImage"), System.Drawing.Image)
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.PR_Rt6)
        Me.Panel6.Controls.Add(Me.RunRt6)
        Me.Panel6.Controls.Add(Me.MC_Nm6)
        Me.Panel6.Controls.Add(Me.NG_Rt6)
        Me.Panel6.Controls.Add(Me.CYCLE_Time6)
        Me.Panel6.Controls.Add(Me.PR_Qty6)
        Me.Panel6.Controls.Add(Me.Lot_No6)
        Me.Panel6.Controls.Add(Me.NG_Qty6)
        Me.Panel6.Controls.Add(Me.Tot_Qty6)
        Me.Panel6.Controls.Add(Me.JOB_Qty6)
        Me.Panel6.Controls.Add(Me.GD_Nm6)
        Me.Panel6.Location = New System.Drawing.Point(260, 161)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(252, 155)
        Me.Panel6.TabIndex = 5
        '
        'PR_Rt6
        '
        Me.PR_Rt6.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt6.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt6.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt6.Name = "PR_Rt6"
        Me.PR_Rt6.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt6.Step = 5
        Me.PR_Rt6.TabIndex = 44
        '
        'RunRt6
        '
        Me.RunRt6.BackColor = System.Drawing.Color.Transparent
        Me.RunRt6.ForeColor = System.Drawing.Color.White
        Me.RunRt6.Location = New System.Drawing.Point(142, 4)
        Me.RunRt6.Name = "RunRt6"
        Me.RunRt6.Size = New System.Drawing.Size(103, 21)
        Me.RunRt6.TabIndex = 45
        Me.RunRt6.Text = "가동률 :     %"
        Me.RunRt6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm6
        '
        Me.MC_Nm6.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm6.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm6.ForeColor = System.Drawing.Color.White
        Me.MC_Nm6.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm6.Name = "MC_Nm6"
        Me.MC_Nm6.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm6.TabIndex = 43
        Me.MC_Nm6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt6
        '
        Me.NG_Rt6.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt6.Name = "NG_Rt6"
        Me.NG_Rt6.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt6.TabIndex = 53
        Me.NG_Rt6.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time6
        '
        Me.CYCLE_Time6.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time6.Name = "CYCLE_Time6"
        Me.CYCLE_Time6.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time6.TabIndex = 48
        Me.CYCLE_Time6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty6
        '
        Me.PR_Qty6.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty6.Name = "PR_Qty6"
        Me.PR_Qty6.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty6.TabIndex = 51
        Me.PR_Qty6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No6
        '
        Me.Lot_No6.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No6.Name = "Lot_No6"
        Me.Lot_No6.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No6.TabIndex = 46
        Me.Lot_No6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty6
        '
        Me.NG_Qty6.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty6.Name = "NG_Qty6"
        Me.NG_Qty6.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty6.TabIndex = 52
        Me.NG_Qty6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty6
        '
        Me.Tot_Qty6.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty6.Name = "Tot_Qty6"
        Me.Tot_Qty6.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty6.TabIndex = 50
        Me.Tot_Qty6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty6
        '
        Me.JOB_Qty6.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty6.Name = "JOB_Qty6"
        Me.JOB_Qty6.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty6.TabIndex = 49
        Me.JOB_Qty6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm6
        '
        Me.GD_Nm6.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm6.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm6.Name = "GD_Nm6"
        Me.GD_Nm6.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm6.TabIndex = 47
        Me.GD_Nm6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.BackgroundImage = CType(resources.GetObject("Panel5.BackgroundImage"), System.Drawing.Image)
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.PR_Rt5)
        Me.Panel5.Controls.Add(Me.RunRt5)
        Me.Panel5.Controls.Add(Me.MC_Nm5)
        Me.Panel5.Controls.Add(Me.NG_Rt5)
        Me.Panel5.Controls.Add(Me.CYCLE_Time5)
        Me.Panel5.Controls.Add(Me.PR_Qty5)
        Me.Panel5.Controls.Add(Me.Lot_No5)
        Me.Panel5.Controls.Add(Me.NG_Qty5)
        Me.Panel5.Controls.Add(Me.Tot_Qty5)
        Me.Panel5.Controls.Add(Me.JOB_Qty5)
        Me.Panel5.Controls.Add(Me.GD_Nm5)
        Me.Panel5.Location = New System.Drawing.Point(5, 161)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(252, 155)
        Me.Panel5.TabIndex = 4
        '
        'PR_Rt5
        '
        Me.PR_Rt5.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt5.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt5.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt5.Name = "PR_Rt5"
        Me.PR_Rt5.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt5.Step = 5
        Me.PR_Rt5.TabIndex = 44
        '
        'RunRt5
        '
        Me.RunRt5.BackColor = System.Drawing.Color.Transparent
        Me.RunRt5.ForeColor = System.Drawing.Color.White
        Me.RunRt5.Location = New System.Drawing.Point(142, 4)
        Me.RunRt5.Name = "RunRt5"
        Me.RunRt5.Size = New System.Drawing.Size(103, 21)
        Me.RunRt5.TabIndex = 45
        Me.RunRt5.Text = "가동률 :     %"
        Me.RunRt5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm5
        '
        Me.MC_Nm5.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm5.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm5.ForeColor = System.Drawing.Color.White
        Me.MC_Nm5.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm5.Name = "MC_Nm5"
        Me.MC_Nm5.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm5.TabIndex = 43
        Me.MC_Nm5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt5
        '
        Me.NG_Rt5.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt5.Name = "NG_Rt5"
        Me.NG_Rt5.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt5.TabIndex = 53
        Me.NG_Rt5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time5
        '
        Me.CYCLE_Time5.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time5.Name = "CYCLE_Time5"
        Me.CYCLE_Time5.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time5.TabIndex = 48
        Me.CYCLE_Time5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty5
        '
        Me.PR_Qty5.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty5.Name = "PR_Qty5"
        Me.PR_Qty5.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty5.TabIndex = 51
        Me.PR_Qty5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No5
        '
        Me.Lot_No5.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No5.Name = "Lot_No5"
        Me.Lot_No5.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No5.TabIndex = 46
        Me.Lot_No5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty5
        '
        Me.NG_Qty5.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty5.Name = "NG_Qty5"
        Me.NG_Qty5.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty5.TabIndex = 52
        Me.NG_Qty5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty5
        '
        Me.Tot_Qty5.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty5.Name = "Tot_Qty5"
        Me.Tot_Qty5.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty5.TabIndex = 50
        Me.Tot_Qty5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty5
        '
        Me.JOB_Qty5.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty5.Name = "JOB_Qty5"
        Me.JOB_Qty5.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty5.TabIndex = 49
        Me.JOB_Qty5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm5
        '
        Me.GD_Nm5.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm5.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm5.Name = "GD_Nm5"
        Me.GD_Nm5.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm5.TabIndex = 47
        Me.GD_Nm5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.PR_Rt2)
        Me.Panel2.Controls.Add(Me.RunRt2)
        Me.Panel2.Controls.Add(Me.MC_Nm2)
        Me.Panel2.Controls.Add(Me.NG_Rt2)
        Me.Panel2.Controls.Add(Me.CYCLE_Time2)
        Me.Panel2.Controls.Add(Me.PR_Qty2)
        Me.Panel2.Controls.Add(Me.Lot_No2)
        Me.Panel2.Controls.Add(Me.NG_Qty2)
        Me.Panel2.Controls.Add(Me.Tot_Qty2)
        Me.Panel2.Controls.Add(Me.JOB_Qty2)
        Me.Panel2.Controls.Add(Me.GD_Nm2)
        Me.Panel2.Location = New System.Drawing.Point(260, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(252, 155)
        Me.Panel2.TabIndex = 1
        '
        'PR_Rt2
        '
        Me.PR_Rt2.BackColor = System.Drawing.Color.Silver
        Me.PR_Rt2.ForeColor = System.Drawing.Color.DodgerBlue
        Me.PR_Rt2.Location = New System.Drawing.Point(4, 131)
        Me.PR_Rt2.Name = "PR_Rt2"
        Me.PR_Rt2.Size = New System.Drawing.Size(122, 19)
        Me.PR_Rt2.Step = 5
        Me.PR_Rt2.TabIndex = 22
        '
        'RunRt2
        '
        Me.RunRt2.BackColor = System.Drawing.Color.Transparent
        Me.RunRt2.ForeColor = System.Drawing.Color.White
        Me.RunRt2.Location = New System.Drawing.Point(142, 4)
        Me.RunRt2.Name = "RunRt2"
        Me.RunRt2.Size = New System.Drawing.Size(103, 21)
        Me.RunRt2.TabIndex = 23
        Me.RunRt2.Text = "가동률 :     %"
        Me.RunRt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MC_Nm2
        '
        Me.MC_Nm2.BackColor = System.Drawing.Color.Transparent
        Me.MC_Nm2.Font = New System.Drawing.Font("굴림", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MC_Nm2.ForeColor = System.Drawing.Color.White
        Me.MC_Nm2.Location = New System.Drawing.Point(3, 1)
        Me.MC_Nm2.Name = "MC_Nm2"
        Me.MC_Nm2.Size = New System.Drawing.Size(245, 24)
        Me.MC_Nm2.TabIndex = 21
        Me.MC_Nm2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Rt2
        '
        Me.NG_Rt2.Location = New System.Drawing.Point(180, 128)
        Me.NG_Rt2.Name = "NG_Rt2"
        Me.NG_Rt2.Size = New System.Drawing.Size(42, 23)
        Me.NG_Rt2.TabIndex = 31
        Me.NG_Rt2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'CYCLE_Time2
        '
        Me.CYCLE_Time2.Location = New System.Drawing.Point(204, 53)
        Me.CYCLE_Time2.Name = "CYCLE_Time2"
        Me.CYCLE_Time2.Size = New System.Drawing.Size(42, 23)
        Me.CYCLE_Time2.TabIndex = 26
        Me.CYCLE_Time2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PR_Qty2
        '
        Me.PR_Qty2.Location = New System.Drawing.Point(180, 79)
        Me.PR_Qty2.Name = "PR_Qty2"
        Me.PR_Qty2.Size = New System.Drawing.Size(66, 23)
        Me.PR_Qty2.TabIndex = 29
        Me.PR_Qty2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lot_No2
        '
        Me.Lot_No2.Location = New System.Drawing.Point(46, 53)
        Me.Lot_No2.Name = "Lot_No2"
        Me.Lot_No2.Size = New System.Drawing.Size(109, 23)
        Me.Lot_No2.TabIndex = 24
        Me.Lot_No2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NG_Qty2
        '
        Me.NG_Qty2.Location = New System.Drawing.Point(180, 104)
        Me.NG_Qty2.Name = "NG_Qty2"
        Me.NG_Qty2.Size = New System.Drawing.Size(66, 23)
        Me.NG_Qty2.TabIndex = 30
        Me.NG_Qty2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tot_Qty2
        '
        Me.Tot_Qty2.Location = New System.Drawing.Point(60, 104)
        Me.Tot_Qty2.Name = "Tot_Qty2"
        Me.Tot_Qty2.Size = New System.Drawing.Size(66, 23)
        Me.Tot_Qty2.TabIndex = 28
        Me.Tot_Qty2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'JOB_Qty2
        '
        Me.JOB_Qty2.Location = New System.Drawing.Point(60, 79)
        Me.JOB_Qty2.Name = "JOB_Qty2"
        Me.JOB_Qty2.Size = New System.Drawing.Size(66, 23)
        Me.JOB_Qty2.TabIndex = 27
        Me.JOB_Qty2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GD_Nm2
        '
        Me.GD_Nm2.BackColor = System.Drawing.Color.Transparent
        Me.GD_Nm2.Location = New System.Drawing.Point(3, 28)
        Me.GD_Nm2.Name = "GD_Nm2"
        Me.GD_Nm2.Size = New System.Drawing.Size(243, 24)
        Me.GD_Nm2.TabIndex = 25
        Me.GD_Nm2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MES_PR1120C002
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitMain)
        Me.Name = "MES_PR1120C002"
        Me.Size = New System.Drawing.Size(1300, 800)
        Me.Controls.SetChildIndex(Me.SplitMain, 0)
        Me.SplitMain.Panel1.ResumeLayout(False)
        Me.SplitMain.Panel2.ResumeLayout(False)
        Me.SplitMain.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.PanelMain.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitMain As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents BaseDt As Frame7.eDate
    Friend WithEvents FAC_CD As Frame7.eCombo
    Friend WithEvents GONG_CD As Frame7.eCombo
    Friend WithEvents PanelMain As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PR_Rt1 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt1 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm1 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt1 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time1 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty1 As System.Windows.Forms.Label
    Friend WithEvents Lot_No1 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty1 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty1 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty1 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm1 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PR_Rt2 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt2 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm2 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt2 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time2 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty2 As System.Windows.Forms.Label
    Friend WithEvents Lot_No2 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty2 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty2 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty2 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm2 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt3 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt3 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm3 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt3 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time3 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty3 As System.Windows.Forms.Label
    Friend WithEvents Lot_No3 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty3 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty3 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty3 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm3 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt4 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt4 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm4 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt4 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time4 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty4 As System.Windows.Forms.Label
    Friend WithEvents Lot_No4 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty4 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty4 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty4 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm4 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt5 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt5 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm5 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt5 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time5 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty5 As System.Windows.Forms.Label
    Friend WithEvents Lot_No5 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty5 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty5 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty5 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm5 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt6 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt6 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm6 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt6 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time6 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty6 As System.Windows.Forms.Label
    Friend WithEvents Lot_No6 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty6 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty6 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty6 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm6 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt7 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt7 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm7 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt7 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time7 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty7 As System.Windows.Forms.Label
    Friend WithEvents Lot_No7 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty7 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty7 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty7 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm7 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt8 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt8 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm8 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt8 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time8 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty8 As System.Windows.Forms.Label
    Friend WithEvents Lot_No8 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty8 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty8 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty8 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm8 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt9 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt9 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm9 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt9 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time9 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty9 As System.Windows.Forms.Label
    Friend WithEvents Lot_No9 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty9 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty9 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty9 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm9 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt10 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt10 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm10 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt10 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time10 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty10 As System.Windows.Forms.Label
    Friend WithEvents Lot_No10 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty10 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty10 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty10 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm10 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt11 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt11 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm11 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt11 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time11 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty11 As System.Windows.Forms.Label
    Friend WithEvents Lot_No11 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty11 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty11 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty11 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm11 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt12 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt12 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm12 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt12 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time12 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty12 As System.Windows.Forms.Label
    Friend WithEvents Lot_No12 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty12 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty12 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty12 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm12 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt13 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt13 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm13 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt13 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time13 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty13 As System.Windows.Forms.Label
    Friend WithEvents Lot_No13 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty13 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty13 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty13 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm13 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt14 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt14 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm14 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt14 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time14 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty14 As System.Windows.Forms.Label
    Friend WithEvents Lot_No14 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty14 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty14 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty14 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm14 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt15 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt15 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm15 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt15 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time15 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty15 As System.Windows.Forms.Label
    Friend WithEvents Lot_No15 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty15 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty15 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty15 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm15 As System.Windows.Forms.Label
    Friend WithEvents PR_Rt16 As System.Windows.Forms.ProgressBar
    Friend WithEvents RunRt16 As System.Windows.Forms.Label
    Friend WithEvents MC_Nm16 As System.Windows.Forms.Label
    Friend WithEvents NG_Rt16 As System.Windows.Forms.Label
    Friend WithEvents CYCLE_Time16 As System.Windows.Forms.Label
    Friend WithEvents PR_Qty16 As System.Windows.Forms.Label
    Friend WithEvents Lot_No16 As System.Windows.Forms.Label
    Friend WithEvents NG_Qty16 As System.Windows.Forms.Label
    Friend WithEvents Tot_Qty16 As System.Windows.Forms.Label
    Friend WithEvents JOB_Qty16 As System.Windows.Forms.Label
    Friend WithEvents GD_Nm16 As System.Windows.Forms.Label

End Class
