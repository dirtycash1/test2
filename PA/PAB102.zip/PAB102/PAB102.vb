﻿Imports Frame7
Imports Base7
Imports Base7.Shared

Public Class PAB102


    Private Sub PAB102_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnlCopy.Visible = False
        '    'Form Load되면서 바로 입력할 수 있게 신규상태로 만든다
        'Me.New_Form()

    End Sub

    'Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
    '    Select Case mty
    '        Case MenuType.Open

    '            Me.open_form()

    '            'Case MenuType.Save

    '            'Case MenuType.New

    '        Case Else
    '            MyBase.MenuButton_Click(mty)
    '    End Select

    'End Sub

    'Private Sub open_form()

    '    Me.Open()

    '    emp_no2.Text = g10.Text("emp_no", 0)
    '    emp_nm2.Text = g10.Text("emp_nm", 0)
    '    dept_nm.Text = g10.Text("dept_nm", 0)
    '    duty_bc.Text = g10.Text("duty_bc", 0)
    '    tot_amt.Text = g10.Text("tot_pay", 0)
    '    tot_de.Text = g10.Text("tot_de", 0)
    '    pay_amt.Text = g10.Text("pay_amt", 0)

    'End Sub

    'Private Sub g10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles g10.Click


    '    If g10.RowCount > 0 Then

    '        emp_no2.Text = g10.Text("emp_no", g10.RowIndex)
    '        emp_nm2.Text = g10.Text("emp_nm", g10.RowIndex)
    '        dept_nm.Text = g10.Text("dept_nm", g10.RowIndex)
    '        duty_bc.Text = g10.Text("duty_bc", g10.RowIndex)
    '        tot_amt.Text = g10.Text("tot_pay", g10.RowIndex)
    '        tot_de.Text = g10.Text("tot_de", g10.RowIndex)
    '        pay_amt.Text = g10.Text("pay_amt", g10.RowIndex)

    '    End If

    'End Sub

    Private Sub btn_copy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_copy.Click
        pnlCopy.Visible = Not pnlCopy.Visible
    End Sub

End Class
