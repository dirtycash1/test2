﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WI_PR1122
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WI_PR1122))
        Me.spc_1 = New System.Windows.Forms.SplitContainer()
        Me.tab1 = New DevExpress.XtraTab.XtraTabControl()
        Me.tp1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.find_lot_no = New Frame7.eText()
        Me.find_mc_cd = New Frame7.eCombo()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_cancel = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_find = New DevExpress.XtraEditors.SimpleButton()
        Me.find_visible = New System.Windows.Forms.CheckBox()
        Me.find_to = New Frame7.eDate()
        Me.find_from = New Frame7.eDate()
        Me.find_gd_nm = New Frame7.eText()
        Me.find_stts = New Frame7.eCombo()
        Me.g_list = New Frame7.eGrid()
        Me.tp2 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.find_mc_cd2 = New Frame7.eCombo()
        Me.find_job_no2 = New Frame7.eText()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btn_cancel2 = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_find2 = New DevExpress.XtraEditors.SimpleButton()
        Me.find_visible2 = New System.Windows.Forms.CheckBox()
        Me.find_to2 = New Frame7.eDate()
        Me.find_from2 = New Frame7.eDate()
        Me.find_gd_nm2 = New Frame7.eText()
        Me.g_list2 = New Frame7.eGrid()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.BB_PS_NM = New Frame7.eText()
        Me.BB_PS_CD = New Frame7.eText()
        Me.btn_lot_print = New DevExpress.XtraEditors.SimpleButton()
        Me.cr_sp = New Frame7.eText()
        Me.mold_cd = New Frame7.eText()
        Me.btn_new = New DevExpress.XtraEditors.SimpleButton()
        Me.sample_qty = New Frame7.eText()
        Me.pop_qty = New Frame7.eText()
        Me.mate_qty = New Frame7.eText()
        Me.spec30 = New Frame7.eText()
        Me.stts = New Frame7.eCombo()
        Me.mate_no = New Frame7.eText()
        Me.pr_no = New Frame7.eText()
        Me.sa_cd = New Frame7.eCombo()
        Me.gong_cd = New Frame7.eCombo()
        Me.ja_cd = New Frame7.eText()
        Me.unit_cd = New Frame7.eCombo()
        Me.new_gdcd = New Frame7.eText()
        Me.new_gdnm = New Frame7.eText()
        Me.btn_save = New DevExpress.XtraEditors.SimpleButton()
        Me.pr_dt = New Frame7.eDate()
        Me.from_dt = New Frame7.eDate()
        Me.new_spec = New Frame7.eText()
        Me.twh_cd = New Frame7.eCombo()
        Me.fwh_cd = New Frame7.eCombo()
        Me.from_time = New Frame7.eText()
        Me.pr_jobno = New Frame7.eText()
        Me.ps_nm = New Frame7.eText()
        Me.mc_cd = New Frame7.eCombo()
        Me.to_time = New Frame7.eText()
        Me.lot_no = New Frame7.eText()
        Me.job_no = New Frame7.eText()
        Me.ps_cd = New Frame7.eText()
        Me.XtraTabControl2 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage8 = New DevExpress.XtraTab.XtraTabPage()
        Me.remark = New Frame7.eMemo()
        Me.POP_SP = New Frame7.eText()
        Me.job_seq = New Frame7.eText()
        Me.gd_cd = New Frame7.eText()
        Me.to_dt = New Frame7.eDate()
        Me.spec = New Frame7.eText()
        Me.wa_cd = New Frame7.eCombo()
        Me.gd_nm = New Frame7.eText()
        Me.pr_qty = New Frame7.eText()
        Me.job_qty = New Frame7.eText()
        Me.ng_qty = New Frame7.eText()
        Me.tot_qty = New Frame7.eText()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.g_body1 = New Frame7.eGrid()
        Me.XtraTabControl12 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage10 = New DevExpress.XtraTab.XtraTabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG2 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET2 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox39 = New System.Windows.Forms.PictureBox()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox31 = New System.Windows.Forms.PictureBox()
        Me.PictureBox38 = New System.Windows.Forms.PictureBox()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox37 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox36 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox35 = New System.Windows.Forms.PictureBox()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox27 = New System.Windows.Forms.PictureBox()
        Me.PictureBox28 = New System.Windows.Forms.PictureBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG4 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET4 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox79 = New System.Windows.Forms.PictureBox()
        Me.PictureBox78 = New System.Windows.Forms.PictureBox()
        Me.PictureBox77 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox75 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox73 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.PictureBox71 = New System.Windows.Forms.PictureBox()
        Me.PictureBox68 = New System.Windows.Forms.PictureBox()
        Me.PictureBox69 = New System.Windows.Forms.PictureBox()
        Me.PictureBox67 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.PictureBox65 = New System.Windows.Forms.PictureBox()
        Me.PictureBox64 = New System.Windows.Forms.PictureBox()
        Me.PictureBox62 = New System.Windows.Forms.PictureBox()
        Me.PictureBox63 = New System.Windows.Forms.PictureBox()
        Me.PictureBox61 = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG3 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET3 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox59 = New System.Windows.Forms.PictureBox()
        Me.PictureBox58 = New System.Windows.Forms.PictureBox()
        Me.PictureBox57 = New System.Windows.Forms.PictureBox()
        Me.PictureBox56 = New System.Windows.Forms.PictureBox()
        Me.PictureBox55 = New System.Windows.Forms.PictureBox()
        Me.PictureBox54 = New System.Windows.Forms.PictureBox()
        Me.PictureBox53 = New System.Windows.Forms.PictureBox()
        Me.PictureBox52 = New System.Windows.Forms.PictureBox()
        Me.PictureBox51 = New System.Windows.Forms.PictureBox()
        Me.PictureBox48 = New System.Windows.Forms.PictureBox()
        Me.PictureBox49 = New System.Windows.Forms.PictureBox()
        Me.PictureBox47 = New System.Windows.Forms.PictureBox()
        Me.PictureBox46 = New System.Windows.Forms.PictureBox()
        Me.PictureBox45 = New System.Windows.Forms.PictureBox()
        Me.PictureBox44 = New System.Windows.Forms.PictureBox()
        Me.PictureBox42 = New System.Windows.Forms.PictureBox()
        Me.PictureBox43 = New System.Windows.Forms.PictureBox()
        Me.PictureBox41 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.RESET = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.XtraTabPage11 = New DevExpress.XtraTab.XtraTabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG6 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET6 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox119 = New System.Windows.Forms.PictureBox()
        Me.PictureBox112 = New System.Windows.Forms.PictureBox()
        Me.PictureBox109 = New System.Windows.Forms.PictureBox()
        Me.PictureBox111 = New System.Windows.Forms.PictureBox()
        Me.PictureBox118 = New System.Windows.Forms.PictureBox()
        Me.PictureBox114 = New System.Windows.Forms.PictureBox()
        Me.PictureBox113 = New System.Windows.Forms.PictureBox()
        Me.PictureBox117 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox116 = New System.Windows.Forms.PictureBox()
        Me.PictureBox103 = New System.Windows.Forms.PictureBox()
        Me.PictureBox115 = New System.Windows.Forms.PictureBox()
        Me.PictureBox101 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox106 = New System.Windows.Forms.PictureBox()
        Me.PictureBox107 = New System.Windows.Forms.PictureBox()
        Me.PictureBox108 = New System.Windows.Forms.PictureBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG8 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET8 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox159 = New System.Windows.Forms.PictureBox()
        Me.PictureBox158 = New System.Windows.Forms.PictureBox()
        Me.PictureBox157 = New System.Windows.Forms.PictureBox()
        Me.PictureBox156 = New System.Windows.Forms.PictureBox()
        Me.PictureBox155 = New System.Windows.Forms.PictureBox()
        Me.PictureBox154 = New System.Windows.Forms.PictureBox()
        Me.PictureBox153 = New System.Windows.Forms.PictureBox()
        Me.PictureBox152 = New System.Windows.Forms.PictureBox()
        Me.PictureBox151 = New System.Windows.Forms.PictureBox()
        Me.PictureBox148 = New System.Windows.Forms.PictureBox()
        Me.PictureBox149 = New System.Windows.Forms.PictureBox()
        Me.PictureBox147 = New System.Windows.Forms.PictureBox()
        Me.PictureBox146 = New System.Windows.Forms.PictureBox()
        Me.PictureBox145 = New System.Windows.Forms.PictureBox()
        Me.PictureBox144 = New System.Windows.Forms.PictureBox()
        Me.PictureBox142 = New System.Windows.Forms.PictureBox()
        Me.PictureBox143 = New System.Windows.Forms.PictureBox()
        Me.PictureBox141 = New System.Windows.Forms.PictureBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG7 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET7 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox139 = New System.Windows.Forms.PictureBox()
        Me.PictureBox138 = New System.Windows.Forms.PictureBox()
        Me.PictureBox137 = New System.Windows.Forms.PictureBox()
        Me.PictureBox136 = New System.Windows.Forms.PictureBox()
        Me.PictureBox135 = New System.Windows.Forms.PictureBox()
        Me.PictureBox134 = New System.Windows.Forms.PictureBox()
        Me.PictureBox133 = New System.Windows.Forms.PictureBox()
        Me.PictureBox132 = New System.Windows.Forms.PictureBox()
        Me.PictureBox131 = New System.Windows.Forms.PictureBox()
        Me.PictureBox128 = New System.Windows.Forms.PictureBox()
        Me.PictureBox129 = New System.Windows.Forms.PictureBox()
        Me.PictureBox127 = New System.Windows.Forms.PictureBox()
        Me.PictureBox126 = New System.Windows.Forms.PictureBox()
        Me.PictureBox125 = New System.Windows.Forms.PictureBox()
        Me.PictureBox124 = New System.Windows.Forms.PictureBox()
        Me.PictureBox122 = New System.Windows.Forms.PictureBox()
        Me.PictureBox123 = New System.Windows.Forms.PictureBox()
        Me.PictureBox121 = New System.Windows.Forms.PictureBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG5 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox92 = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.PictureBox98 = New System.Windows.Forms.PictureBox()
        Me.PictureBox97 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox95 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.RESET5 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox93 = New System.Windows.Forms.PictureBox()
        Me.PictureBox91 = New System.Windows.Forms.PictureBox()
        Me.PictureBox89 = New System.Windows.Forms.PictureBox()
        Me.PictureBox88 = New System.Windows.Forms.PictureBox()
        Me.PictureBox87 = New System.Windows.Forms.PictureBox()
        Me.PictureBox86 = New System.Windows.Forms.PictureBox()
        Me.PictureBox85 = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.PictureBox82 = New System.Windows.Forms.PictureBox()
        Me.PictureBox83 = New System.Windows.Forms.PictureBox()
        Me.PictureBox81 = New System.Windows.Forms.PictureBox()
        Me.XtraTabPage12 = New DevExpress.XtraTab.XtraTabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG10 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET10 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox199 = New System.Windows.Forms.PictureBox()
        Me.PictureBox192 = New System.Windows.Forms.PictureBox()
        Me.PictureBox189 = New System.Windows.Forms.PictureBox()
        Me.PictureBox191 = New System.Windows.Forms.PictureBox()
        Me.PictureBox198 = New System.Windows.Forms.PictureBox()
        Me.PictureBox194 = New System.Windows.Forms.PictureBox()
        Me.PictureBox193 = New System.Windows.Forms.PictureBox()
        Me.PictureBox197 = New System.Windows.Forms.PictureBox()
        Me.PictureBox182 = New System.Windows.Forms.PictureBox()
        Me.PictureBox196 = New System.Windows.Forms.PictureBox()
        Me.PictureBox183 = New System.Windows.Forms.PictureBox()
        Me.PictureBox195 = New System.Windows.Forms.PictureBox()
        Me.PictureBox181 = New System.Windows.Forms.PictureBox()
        Me.PictureBox184 = New System.Windows.Forms.PictureBox()
        Me.PictureBox185 = New System.Windows.Forms.PictureBox()
        Me.PictureBox186 = New System.Windows.Forms.PictureBox()
        Me.PictureBox187 = New System.Windows.Forms.PictureBox()
        Me.PictureBox188 = New System.Windows.Forms.PictureBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG12 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET12 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox239 = New System.Windows.Forms.PictureBox()
        Me.PictureBox238 = New System.Windows.Forms.PictureBox()
        Me.PictureBox237 = New System.Windows.Forms.PictureBox()
        Me.PictureBox236 = New System.Windows.Forms.PictureBox()
        Me.PictureBox235 = New System.Windows.Forms.PictureBox()
        Me.PictureBox234 = New System.Windows.Forms.PictureBox()
        Me.PictureBox233 = New System.Windows.Forms.PictureBox()
        Me.PictureBox232 = New System.Windows.Forms.PictureBox()
        Me.PictureBox231 = New System.Windows.Forms.PictureBox()
        Me.PictureBox228 = New System.Windows.Forms.PictureBox()
        Me.PictureBox229 = New System.Windows.Forms.PictureBox()
        Me.PictureBox227 = New System.Windows.Forms.PictureBox()
        Me.PictureBox226 = New System.Windows.Forms.PictureBox()
        Me.PictureBox225 = New System.Windows.Forms.PictureBox()
        Me.PictureBox224 = New System.Windows.Forms.PictureBox()
        Me.PictureBox222 = New System.Windows.Forms.PictureBox()
        Me.PictureBox223 = New System.Windows.Forms.PictureBox()
        Me.PictureBox221 = New System.Windows.Forms.PictureBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG11 = New DevExpress.XtraEditors.SimpleButton()
        Me.RESET11 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox219 = New System.Windows.Forms.PictureBox()
        Me.PictureBox218 = New System.Windows.Forms.PictureBox()
        Me.PictureBox217 = New System.Windows.Forms.PictureBox()
        Me.PictureBox216 = New System.Windows.Forms.PictureBox()
        Me.PictureBox215 = New System.Windows.Forms.PictureBox()
        Me.PictureBox214 = New System.Windows.Forms.PictureBox()
        Me.PictureBox213 = New System.Windows.Forms.PictureBox()
        Me.PictureBox212 = New System.Windows.Forms.PictureBox()
        Me.PictureBox211 = New System.Windows.Forms.PictureBox()
        Me.PictureBox208 = New System.Windows.Forms.PictureBox()
        Me.PictureBox209 = New System.Windows.Forms.PictureBox()
        Me.PictureBox207 = New System.Windows.Forms.PictureBox()
        Me.PictureBox206 = New System.Windows.Forms.PictureBox()
        Me.PictureBox205 = New System.Windows.Forms.PictureBox()
        Me.PictureBox204 = New System.Windows.Forms.PictureBox()
        Me.PictureBox202 = New System.Windows.Forms.PictureBox()
        Me.PictureBox203 = New System.Windows.Forms.PictureBox()
        Me.PictureBox201 = New System.Windows.Forms.PictureBox()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.SAVE_IMG9 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox172 = New System.Windows.Forms.PictureBox()
        Me.PictureBox179 = New System.Windows.Forms.PictureBox()
        Me.PictureBox178 = New System.Windows.Forms.PictureBox()
        Me.PictureBox177 = New System.Windows.Forms.PictureBox()
        Me.PictureBox176 = New System.Windows.Forms.PictureBox()
        Me.PictureBox175 = New System.Windows.Forms.PictureBox()
        Me.PictureBox174 = New System.Windows.Forms.PictureBox()
        Me.RESET9 = New DevExpress.XtraEditors.SimpleButton()
        Me.PictureBox173 = New System.Windows.Forms.PictureBox()
        Me.PictureBox171 = New System.Windows.Forms.PictureBox()
        Me.PictureBox169 = New System.Windows.Forms.PictureBox()
        Me.PictureBox168 = New System.Windows.Forms.PictureBox()
        Me.PictureBox167 = New System.Windows.Forms.PictureBox()
        Me.PictureBox166 = New System.Windows.Forms.PictureBox()
        Me.PictureBox165 = New System.Windows.Forms.PictureBox()
        Me.PictureBox164 = New System.Windows.Forms.PictureBox()
        Me.PictureBox162 = New System.Windows.Forms.PictureBox()
        Me.PictureBox163 = New System.Windows.Forms.PictureBox()
        Me.PictureBox161 = New System.Windows.Forms.PictureBox()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body = New Frame7.eGrid()
        Me.XtraTabPage3 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body2 = New Frame7.eGrid()
        Me.XtraTabPage4 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body3 = New Frame7.eGrid()
        Me.XtraTabPage5 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body4 = New Frame7.eGrid()
        Me.XtraTabPage6 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body5 = New Frame7.eGrid()
        Me.stop_yn = New Frame7.eText()
        Me.spc_1.Panel1.SuspendLayout()
        Me.spc_1.Panel2.SuspendLayout()
        Me.spc_1.SuspendLayout()
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab1.SuspendLayout()
        Me.tp1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.tp2.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl2.SuspendLayout()
        Me.XtraTabPage8.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.XtraTabControl12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl12.SuspendLayout()
        Me.XtraTabPage10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage11.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox159, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox158, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox157, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox156, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox155, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox154, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox153, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox152, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox148, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox149, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox147, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox146, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox145, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox143, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox122, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage12.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.PictureBox199, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox192, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox189, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox191, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox198, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox194, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox193, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox197, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox182, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox196, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox183, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox195, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox181, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox184, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox185, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox186, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox187, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox188, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        CType(Me.PictureBox239, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox238, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox237, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox236, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox235, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox234, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox233, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox232, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox231, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox228, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox229, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox227, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox226, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox225, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox224, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox222, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox223, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox221, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox11.SuspendLayout()
        CType(Me.PictureBox219, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox218, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox217, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox216, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox215, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox214, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox213, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox212, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox211, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox208, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox209, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox207, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox206, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox205, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox204, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox202, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox203, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox201, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox12.SuspendLayout()
        CType(Me.PictureBox172, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox179, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox178, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox177, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox176, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox175, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox174, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox173, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox171, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox169, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox164, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox162, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox163, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox161, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabPage2.SuspendLayout()
        Me.XtraTabPage3.SuspendLayout()
        Me.XtraTabPage4.SuspendLayout()
        Me.XtraTabPage5.SuspendLayout()
        Me.XtraTabPage6.SuspendLayout()
        Me.SuspendLayout()
        '
        'spc_1
        '
        Me.spc_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spc_1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.spc_1.Location = New System.Drawing.Point(0, 0)
        Me.spc_1.Name = "spc_1"
        '
        'spc_1.Panel1
        '
        Me.spc_1.Panel1.Controls.Add(Me.tab1)
        '
        'spc_1.Panel2
        '
        Me.spc_1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.spc_1.Size = New System.Drawing.Size(1615, 611)
        Me.spc_1.SplitterDistance = 374
        Me.spc_1.TabIndex = 11
        '
        'tab1
        '
        Me.tab1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tab1.Location = New System.Drawing.Point(0, 0)
        Me.tab1.Name = "tab1"
        Me.tab1.SelectedTabPage = Me.tp1
        Me.tab1.Size = New System.Drawing.Size(374, 611)
        Me.tab1.TabIndex = 50
        Me.tab1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tp1, Me.tp2})
        '
        'tp1
        '
        Me.tp1.Controls.Add(Me.SplitContainer1)
        Me.tp1.Name = "tp1"
        Me.tp1.Size = New System.Drawing.Size(367, 581)
        Me.tp1.Text = "검색 조건"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.g_list)
        Me.SplitContainer1.Size = New System.Drawing.Size(367, 581)
        Me.SplitContainer1.SplitterDistance = 201
        Me.SplitContainer1.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.find_lot_no)
        Me.Panel2.Controls.Add(Me.find_mc_cd)
        Me.Panel2.Controls.Add(Me.Panel1)
        Me.Panel2.Controls.Add(Me.find_to)
        Me.Panel2.Controls.Add(Me.find_from)
        Me.Panel2.Controls.Add(Me.find_gd_nm)
        Me.Panel2.Controls.Add(Me.find_stts)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(367, 201)
        Me.Panel2.TabIndex = 1
        '
        'find_lot_no
        '
        Me.find_lot_no.ColumnName = "find_paymenterm_cd"
        Me.find_lot_no.Location = New System.Drawing.Point(25, 54)
        Me.find_lot_no.Name = "find_lot_no"
        Me.find_lot_no.Size = New System.Drawing.Size(273, 21)
        Me.find_lot_no.TabIndex = 53
        Me.find_lot_no.TableName = "find_paymenterm_cd"
        Me.find_lot_no.Title = "Sheet No."
        Me.find_lot_no.TitleWidth = 60
        '
        'find_mc_cd
        '
        Me.find_mc_cd.Location = New System.Drawing.Point(25, 102)
        Me.find_mc_cd.Name = "find_mc_cd"
        Me.find_mc_cd.Size = New System.Drawing.Size(273, 21)
        Me.find_mc_cd.TabIndex = 52
        Me.find_mc_cd.Title = "기계"
        Me.find_mc_cd.TitleWidth = 60
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.btn_cancel)
        Me.Panel1.Controls.Add(Me.btn_find)
        Me.Panel1.Controls.Add(Me.find_visible)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 160)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(367, 41)
        Me.Panel1.TabIndex = 2
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(98, 6)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(72, 27)
        Me.btn_cancel.TabIndex = 72
        Me.btn_cancel.Text = "취   소"
        '
        'btn_find
        '
        Me.btn_find.Location = New System.Drawing.Point(10, 6)
        Me.btn_find.Name = "btn_find"
        Me.btn_find.Size = New System.Drawing.Size(72, 27)
        Me.btn_find.TabIndex = 71
        Me.btn_find.Text = "검   색"
        '
        'find_visible
        '
        Me.find_visible.AutoSize = True
        Me.find_visible.Checked = True
        Me.find_visible.CheckState = System.Windows.Forms.CheckState.Checked
        Me.find_visible.Dock = System.Windows.Forms.DockStyle.Right
        Me.find_visible.Location = New System.Drawing.Point(273, 0)
        Me.find_visible.Name = "find_visible"
        Me.find_visible.Size = New System.Drawing.Size(92, 39)
        Me.find_visible.TabIndex = 48
        Me.find_visible.Text = "선택 후 숨김"
        Me.find_visible.UseVisualStyleBackColor = True
        '
        'find_to
        '
        Me.find_to.Location = New System.Drawing.Point(187, 30)
        Me.find_to.Name = "find_to"
        Me.find_to.Size = New System.Drawing.Size(111, 21)
        Me.find_to.TabIndex = 51
        Me.find_to.Title = "~"
        Me.find_to.TitleWidth = 10
        '
        'find_from
        '
        Me.find_from.Location = New System.Drawing.Point(25, 30)
        Me.find_from.Name = "find_from"
        Me.find_from.Size = New System.Drawing.Size(159, 21)
        Me.find_from.TabIndex = 50
        Me.find_from.Title = "기간"
        Me.find_from.TitleWidth = 60
        '
        'find_gd_nm
        '
        Me.find_gd_nm.ColumnName = "find_paymenterm_cd"
        Me.find_gd_nm.Location = New System.Drawing.Point(25, 78)
        Me.find_gd_nm.Name = "find_gd_nm"
        Me.find_gd_nm.Size = New System.Drawing.Size(273, 21)
        Me.find_gd_nm.TabIndex = 48
        Me.find_gd_nm.TableName = "find_paymenterm_cd"
        Me.find_gd_nm.Title = "제품명"
        Me.find_gd_nm.TitleWidth = 60
        '
        'find_stts
        '
        Me.find_stts.Location = New System.Drawing.Point(25, 126)
        Me.find_stts.Name = "find_stts"
        Me.find_stts.Size = New System.Drawing.Size(159, 21)
        Me.find_stts.TabIndex = 49
        Me.find_stts.Title = "상태"
        Me.find_stts.TitleWidth = 60
        '
        'g_list
        '
        Me.g_list.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_list.Location = New System.Drawing.Point(0, 0)
        Me.g_list.Name = "g_list"
        Me.g_list.ReadOnly = False
        Me.g_list.RowHeight = -1
        Me.g_list.Size = New System.Drawing.Size(367, 376)
        Me.g_list.TabIndex = 0
        '
        'tp2
        '
        Me.tp2.Controls.Add(Me.SplitContainer4)
        Me.tp2.Name = "tp2"
        Me.tp2.Size = New System.Drawing.Size(367, 581)
        Me.tp2.Text = "등록할 자료"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.Panel3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.g_list2)
        Me.SplitContainer4.Size = New System.Drawing.Size(367, 581)
        Me.SplitContainer4.SplitterDistance = 182
        Me.SplitContainer4.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.find_mc_cd2)
        Me.Panel3.Controls.Add(Me.find_job_no2)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.find_to2)
        Me.Panel3.Controls.Add(Me.find_from2)
        Me.Panel3.Controls.Add(Me.find_gd_nm2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(367, 182)
        Me.Panel3.TabIndex = 0
        '
        'find_mc_cd2
        '
        Me.find_mc_cd2.Location = New System.Drawing.Point(25, 78)
        Me.find_mc_cd2.Name = "find_mc_cd2"
        Me.find_mc_cd2.Size = New System.Drawing.Size(273, 21)
        Me.find_mc_cd2.TabIndex = 53
        Me.find_mc_cd2.Title = "기계"
        Me.find_mc_cd2.TitleWidth = 60
        '
        'find_job_no2
        '
        Me.find_job_no2.ColumnName = "find_paymenterm_cd"
        Me.find_job_no2.Location = New System.Drawing.Point(25, 102)
        Me.find_job_no2.Name = "find_job_no2"
        Me.find_job_no2.Size = New System.Drawing.Size(273, 21)
        Me.find_job_no2.TabIndex = 52
        Me.find_job_no2.TableName = "find_paymenterm_cd"
        Me.find_job_no2.Title = "생산지시번호"
        Me.find_job_no2.TitleWidth = 80
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.btn_cancel2)
        Me.Panel4.Controls.Add(Me.btn_find2)
        Me.Panel4.Controls.Add(Me.find_visible2)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 141)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(367, 41)
        Me.Panel4.TabIndex = 2
        '
        'btn_cancel2
        '
        Me.btn_cancel2.Location = New System.Drawing.Point(98, 6)
        Me.btn_cancel2.Name = "btn_cancel2"
        Me.btn_cancel2.Size = New System.Drawing.Size(72, 27)
        Me.btn_cancel2.TabIndex = 72
        Me.btn_cancel2.Text = "취   소"
        '
        'btn_find2
        '
        Me.btn_find2.Location = New System.Drawing.Point(10, 6)
        Me.btn_find2.Name = "btn_find2"
        Me.btn_find2.Size = New System.Drawing.Size(72, 27)
        Me.btn_find2.TabIndex = 71
        Me.btn_find2.Text = "검   색"
        '
        'find_visible2
        '
        Me.find_visible2.AutoSize = True
        Me.find_visible2.Checked = True
        Me.find_visible2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.find_visible2.Dock = System.Windows.Forms.DockStyle.Right
        Me.find_visible2.Location = New System.Drawing.Point(273, 0)
        Me.find_visible2.Name = "find_visible2"
        Me.find_visible2.Size = New System.Drawing.Size(92, 39)
        Me.find_visible2.TabIndex = 48
        Me.find_visible2.Text = "선택 후 숨김"
        Me.find_visible2.UseVisualStyleBackColor = True
        '
        'find_to2
        '
        Me.find_to2.Location = New System.Drawing.Point(187, 30)
        Me.find_to2.Name = "find_to2"
        Me.find_to2.Size = New System.Drawing.Size(111, 21)
        Me.find_to2.TabIndex = 51
        Me.find_to2.Title = "~"
        Me.find_to2.TitleWidth = 10
        '
        'find_from2
        '
        Me.find_from2.Location = New System.Drawing.Point(25, 30)
        Me.find_from2.Name = "find_from2"
        Me.find_from2.Size = New System.Drawing.Size(159, 21)
        Me.find_from2.TabIndex = 50
        Me.find_from2.Title = "기간"
        Me.find_from2.TitleWidth = 60
        '
        'find_gd_nm2
        '
        Me.find_gd_nm2.ColumnName = "find_paymenterm_cd"
        Me.find_gd_nm2.Location = New System.Drawing.Point(25, 54)
        Me.find_gd_nm2.Name = "find_gd_nm2"
        Me.find_gd_nm2.Size = New System.Drawing.Size(273, 21)
        Me.find_gd_nm2.TabIndex = 48
        Me.find_gd_nm2.TableName = "find_paymenterm_cd"
        Me.find_gd_nm2.Title = "품명"
        Me.find_gd_nm2.TitleWidth = 60
        '
        'g_list2
        '
        Me.g_list2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_list2.Location = New System.Drawing.Point(0, 0)
        Me.g_list2.Name = "g_list2"
        Me.g_list2.ReadOnly = False
        Me.g_list2.RowHeight = -1
        Me.g_list2.Size = New System.Drawing.Size(367, 395)
        Me.g_list2.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1237, 611)
        Me.SplitContainer2.SplitterDistance = 284
        Me.SplitContainer2.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.stop_yn)
        Me.EPanel1.Controls.Add(Me.BB_PS_NM)
        Me.EPanel1.Controls.Add(Me.BB_PS_CD)
        Me.EPanel1.Controls.Add(Me.btn_lot_print)
        Me.EPanel1.Controls.Add(Me.cr_sp)
        Me.EPanel1.Controls.Add(Me.mold_cd)
        Me.EPanel1.Controls.Add(Me.btn_new)
        Me.EPanel1.Controls.Add(Me.sample_qty)
        Me.EPanel1.Controls.Add(Me.pop_qty)
        Me.EPanel1.Controls.Add(Me.mate_qty)
        Me.EPanel1.Controls.Add(Me.spec30)
        Me.EPanel1.Controls.Add(Me.stts)
        Me.EPanel1.Controls.Add(Me.mate_no)
        Me.EPanel1.Controls.Add(Me.pr_no)
        Me.EPanel1.Controls.Add(Me.sa_cd)
        Me.EPanel1.Controls.Add(Me.gong_cd)
        Me.EPanel1.Controls.Add(Me.ja_cd)
        Me.EPanel1.Controls.Add(Me.unit_cd)
        Me.EPanel1.Controls.Add(Me.new_gdcd)
        Me.EPanel1.Controls.Add(Me.new_gdnm)
        Me.EPanel1.Controls.Add(Me.btn_save)
        Me.EPanel1.Controls.Add(Me.pr_dt)
        Me.EPanel1.Controls.Add(Me.from_dt)
        Me.EPanel1.Controls.Add(Me.new_spec)
        Me.EPanel1.Controls.Add(Me.twh_cd)
        Me.EPanel1.Controls.Add(Me.fwh_cd)
        Me.EPanel1.Controls.Add(Me.from_time)
        Me.EPanel1.Controls.Add(Me.pr_jobno)
        Me.EPanel1.Controls.Add(Me.ps_nm)
        Me.EPanel1.Controls.Add(Me.mc_cd)
        Me.EPanel1.Controls.Add(Me.to_time)
        Me.EPanel1.Controls.Add(Me.lot_no)
        Me.EPanel1.Controls.Add(Me.job_no)
        Me.EPanel1.Controls.Add(Me.ps_cd)
        Me.EPanel1.Controls.Add(Me.XtraTabControl2)
        Me.EPanel1.Controls.Add(Me.POP_SP)
        Me.EPanel1.Controls.Add(Me.job_seq)
        Me.EPanel1.Controls.Add(Me.gd_cd)
        Me.EPanel1.Controls.Add(Me.to_dt)
        Me.EPanel1.Controls.Add(Me.spec)
        Me.EPanel1.Controls.Add(Me.wa_cd)
        Me.EPanel1.Controls.Add(Me.gd_nm)
        Me.EPanel1.Controls.Add(Me.pr_qty)
        Me.EPanel1.Controls.Add(Me.job_qty)
        Me.EPanel1.Controls.Add(Me.ng_qty)
        Me.EPanel1.Controls.Add(Me.tot_qty)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1237, 284)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     EPanel1"
        '
        'BB_PS_NM
        '
        Me.BB_PS_NM.ColumnName = "BB_PS_NM"
        Me.BB_PS_NM.Location = New System.Drawing.Point(1056, 38)
        Me.BB_PS_NM.Name = "BB_PS_NM"
        Me.BB_PS_NM.Size = New System.Drawing.Size(115, 21)
        Me.BB_PS_NM.TabIndex = 147
        Me.BB_PS_NM.TableName = "BB_PS_NM"
        Me.BB_PS_NM.Title = "부서"
        Me.BB_PS_NM.TitleWidth = 0
        '
        'BB_PS_CD
        '
        Me.BB_PS_CD.ColumnName = "BB_PS_CD"
        Me.BB_PS_CD.Location = New System.Drawing.Point(900, 38)
        Me.BB_PS_CD.Name = "BB_PS_CD"
        Me.BB_PS_CD.Size = New System.Drawing.Size(150, 21)
        Me.BB_PS_CD.TabIndex = 146
        Me.BB_PS_CD.TableName = "BB_PS_CD"
        Me.BB_PS_CD.Title = "기포작성자"
        Me.BB_PS_CD.TitleWidth = 70
        '
        'btn_lot_print
        '
        Me.btn_lot_print.Location = New System.Drawing.Point(1064, 79)
        Me.btn_lot_print.Name = "btn_lot_print"
        Me.btn_lot_print.Size = New System.Drawing.Size(107, 45)
        Me.btn_lot_print.TabIndex = 145
        Me.btn_lot_print.Text = "체크시트 발행"
        '
        'cr_sp
        '
        Me.cr_sp.ColumnName = "job_no"
        Me.cr_sp.Location = New System.Drawing.Point(576, 230)
        Me.cr_sp.Name = "cr_sp"
        Me.cr_sp.Size = New System.Drawing.Size(63, 21)
        Me.cr_sp.TabIndex = 132
        Me.cr_sp.TableName = "job_no"
        Me.cr_sp.Title = "S.P"
        Me.cr_sp.TitleWidth = 0
        '
        'mold_cd
        '
        Me.mold_cd.ColumnName = "job_no"
        Me.mold_cd.Location = New System.Drawing.Point(342, 230)
        Me.mold_cd.Name = "mold_cd"
        Me.mold_cd.Size = New System.Drawing.Size(228, 21)
        Me.mold_cd.TabIndex = 131
        Me.mold_cd.TableName = "job_no"
        Me.mold_cd.Title = "금형 NO."
        Me.mold_cd.TitleWidth = 98
        '
        'btn_new
        '
        Me.btn_new.Location = New System.Drawing.Point(900, 70)
        Me.btn_new.Name = "btn_new"
        Me.btn_new.Size = New System.Drawing.Size(107, 45)
        Me.btn_new.TabIndex = 133
        Me.btn_new.Text = "LOT 분리작업"
        '
        'sample_qty
        '
        Me.sample_qty.ColumnName = "ps_cd"
        Me.sample_qty.Location = New System.Drawing.Point(693, 254)
        Me.sample_qty.Name = "sample_qty"
        Me.sample_qty.Size = New System.Drawing.Size(201, 21)
        Me.sample_qty.TabIndex = 129
        Me.sample_qty.TableName = "ps_cd"
        Me.sample_qty.Title = "불량"
        Me.sample_qty.TitleWidth = 70
        '
        'pop_qty
        '
        Me.pop_qty.ColumnName = "job_no"
        Me.pop_qty.Location = New System.Drawing.Point(342, 254)
        Me.pop_qty.Name = "pop_qty"
        Me.pop_qty.Size = New System.Drawing.Size(297, 21)
        Me.pop_qty.TabIndex = 130
        Me.pop_qty.TableName = "job_no"
        Me.pop_qty.Title = "S.P"
        Me.pop_qty.TitleWidth = 98
        '
        'mate_qty
        '
        Me.mate_qty.ColumnName = "ps_cd"
        Me.mate_qty.Location = New System.Drawing.Point(500, 301)
        Me.mate_qty.Name = "mate_qty"
        Me.mate_qty.Size = New System.Drawing.Size(201, 21)
        Me.mate_qty.TabIndex = 124
        Me.mate_qty.TableName = "ps_cd"
        Me.mate_qty.Title = "약품투입량"
        Me.mate_qty.TitleWidth = 70
        '
        'spec30
        '
        Me.spec30.ColumnName = "job_no"
        Me.spec30.Location = New System.Drawing.Point(342, 158)
        Me.spec30.Name = "spec30"
        Me.spec30.Size = New System.Drawing.Size(297, 21)
        Me.spec30.TabIndex = 126
        Me.spec30.TableName = "job_no"
        Me.spec30.Title = "S.P"
        Me.spec30.TitleWidth = 98
        '
        'stts
        '
        Me.stts.Location = New System.Drawing.Point(693, 62)
        Me.stts.Name = "stts"
        Me.stts.Size = New System.Drawing.Size(201, 21)
        Me.stts.TabIndex = 122
        Me.stts.Title = "상태"
        Me.stts.TitleWidth = 70
        '
        'mate_no
        '
        Me.mate_no.ColumnName = "job_no"
        Me.mate_no.Location = New System.Drawing.Point(28, 344)
        Me.mate_no.Name = "mate_no"
        Me.mate_no.Size = New System.Drawing.Size(297, 21)
        Me.mate_no.TabIndex = 120
        Me.mate_no.TableName = "job_no"
        Me.mate_no.Title = "약품번호"
        Me.mate_no.TitleWidth = 98
        '
        'pr_no
        '
        Me.pr_no.ColumnName = "job_no"
        Me.pr_no.Location = New System.Drawing.Point(28, 38)
        Me.pr_no.Name = "pr_no"
        Me.pr_no.Size = New System.Drawing.Size(233, 21)
        Me.pr_no.TabIndex = 89
        Me.pr_no.TableName = "job_no"
        Me.pr_no.Title = "생산실적번호"
        Me.pr_no.TitleWidth = 98
        '
        'sa_cd
        '
        Me.sa_cd.Location = New System.Drawing.Point(693, 86)
        Me.sa_cd.Name = "sa_cd"
        Me.sa_cd.Size = New System.Drawing.Size(201, 21)
        Me.sa_cd.TabIndex = 121
        Me.sa_cd.Title = "사업장"
        Me.sa_cd.TitleWidth = 70
        '
        'gong_cd
        '
        Me.gong_cd.Location = New System.Drawing.Point(28, 62)
        Me.gong_cd.Name = "gong_cd"
        Me.gong_cd.Size = New System.Drawing.Size(296, 21)
        Me.gong_cd.TabIndex = 119
        Me.gong_cd.Title = "공정"
        Me.gong_cd.TitleWidth = 98
        '
        'ja_cd
        '
        Me.ja_cd.ColumnName = "ps_cd"
        Me.ja_cd.Location = New System.Drawing.Point(342, 328)
        Me.ja_cd.Name = "ja_cd"
        Me.ja_cd.Size = New System.Drawing.Size(297, 21)
        Me.ja_cd.TabIndex = 123
        Me.ja_cd.TableName = "ps_cd"
        Me.ja_cd.Title = "약품코드"
        Me.ja_cd.TitleWidth = 98
        '
        'unit_cd
        '
        Me.unit_cd.Location = New System.Drawing.Point(28, 158)
        Me.unit_cd.Name = "unit_cd"
        Me.unit_cd.Size = New System.Drawing.Size(233, 21)
        Me.unit_cd.TabIndex = 109
        Me.unit_cd.Title = "단위"
        Me.unit_cd.TitleWidth = 98
        '
        'new_gdcd
        '
        Me.new_gdcd.ColumnName = "ps_cd"
        Me.new_gdcd.Location = New System.Drawing.Point(342, 86)
        Me.new_gdcd.Name = "new_gdcd"
        Me.new_gdcd.Size = New System.Drawing.Size(297, 21)
        Me.new_gdcd.TabIndex = 111
        Me.new_gdcd.TableName = "ps_cd"
        Me.new_gdcd.Title = "실적입고품목"
        Me.new_gdcd.TitleWidth = 98
        '
        'new_gdnm
        '
        Me.new_gdnm.ColumnName = "ps_cd"
        Me.new_gdnm.Location = New System.Drawing.Point(342, 110)
        Me.new_gdnm.Name = "new_gdnm"
        Me.new_gdnm.Size = New System.Drawing.Size(297, 21)
        Me.new_gdnm.TabIndex = 112
        Me.new_gdnm.TableName = "ps_cd"
        Me.new_gdnm.Title = "품명"
        Me.new_gdnm.TitleWidth = 98
        '
        'btn_save
        '
        Me.btn_save.Location = New System.Drawing.Point(900, 121)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(107, 45)
        Me.btn_save.TabIndex = 73
        Me.btn_save.Text = "검사결과 저장"
        '
        'pr_dt
        '
        Me.pr_dt.ColumnName = "plan_dt"
        Me.pr_dt.Location = New System.Drawing.Point(693, 38)
        Me.pr_dt.Name = "pr_dt"
        Me.pr_dt.Size = New System.Drawing.Size(201, 21)
        Me.pr_dt.TabIndex = 92
        Me.pr_dt.TableName = "plan_dt"
        Me.pr_dt.Title = "생산일자"
        Me.pr_dt.TitleWidth = 70
        '
        'from_dt
        '
        Me.from_dt.ColumnName = "plan_dt"
        Me.from_dt.Location = New System.Drawing.Point(28, 206)
        Me.from_dt.Name = "from_dt"
        Me.from_dt.Size = New System.Drawing.Size(233, 21)
        Me.from_dt.TabIndex = 103
        Me.from_dt.TableName = "plan_dt"
        Me.from_dt.Title = "생산시작일시"
        Me.from_dt.TitleWidth = 98
        '
        'new_spec
        '
        Me.new_spec.ColumnName = "ps_cd"
        Me.new_spec.Location = New System.Drawing.Point(342, 134)
        Me.new_spec.Name = "new_spec"
        Me.new_spec.Size = New System.Drawing.Size(297, 21)
        Me.new_spec.TabIndex = 113
        Me.new_spec.TableName = "ps_cd"
        Me.new_spec.Title = "규격"
        Me.new_spec.TitleWidth = 98
        '
        'twh_cd
        '
        Me.twh_cd.Location = New System.Drawing.Point(693, 134)
        Me.twh_cd.Name = "twh_cd"
        Me.twh_cd.Size = New System.Drawing.Size(201, 21)
        Me.twh_cd.TabIndex = 116
        Me.twh_cd.Title = "출고창고"
        Me.twh_cd.TitleWidth = 70
        '
        'fwh_cd
        '
        Me.fwh_cd.Location = New System.Drawing.Point(693, 110)
        Me.fwh_cd.Name = "fwh_cd"
        Me.fwh_cd.Size = New System.Drawing.Size(201, 21)
        Me.fwh_cd.TabIndex = 115
        Me.fwh_cd.Title = "입고창고"
        Me.fwh_cd.TitleWidth = 70
        '
        'from_time
        '
        Me.from_time.ColumnName = "ps_cd"
        Me.from_time.Location = New System.Drawing.Point(267, 206)
        Me.from_time.Name = "from_time"
        Me.from_time.Size = New System.Drawing.Size(57, 21)
        Me.from_time.TabIndex = 105
        Me.from_time.TableName = "ps_cd"
        Me.from_time.Title = "약품번호"
        Me.from_time.TitleWidth = 0
        '
        'pr_jobno
        '
        Me.pr_jobno.ColumnName = "job_no"
        Me.pr_jobno.Location = New System.Drawing.Point(342, 62)
        Me.pr_jobno.Name = "pr_jobno"
        Me.pr_jobno.Size = New System.Drawing.Size(297, 21)
        Me.pr_jobno.TabIndex = 114
        Me.pr_jobno.TableName = "job_no"
        Me.pr_jobno.Title = "생산지시번호"
        Me.pr_jobno.TitleWidth = 98
        '
        'ps_nm
        '
        Me.ps_nm.ColumnName = "pl_nm"
        Me.ps_nm.Location = New System.Drawing.Point(524, 38)
        Me.ps_nm.Name = "ps_nm"
        Me.ps_nm.Size = New System.Drawing.Size(115, 21)
        Me.ps_nm.TabIndex = 91
        Me.ps_nm.TableName = "pl_nm"
        Me.ps_nm.Title = "부서"
        Me.ps_nm.TitleWidth = 0
        '
        'mc_cd
        '
        Me.mc_cd.Location = New System.Drawing.Point(342, 206)
        Me.mc_cd.Name = "mc_cd"
        Me.mc_cd.Size = New System.Drawing.Size(297, 21)
        Me.mc_cd.TabIndex = 107
        Me.mc_cd.Title = "기계"
        Me.mc_cd.TitleWidth = 98
        '
        'to_time
        '
        Me.to_time.ColumnName = "ps_cd"
        Me.to_time.Location = New System.Drawing.Point(267, 230)
        Me.to_time.Name = "to_time"
        Me.to_time.Size = New System.Drawing.Size(57, 21)
        Me.to_time.TabIndex = 106
        Me.to_time.TableName = "ps_cd"
        Me.to_time.Title = "약품번호"
        Me.to_time.TitleWidth = 0
        '
        'lot_no
        '
        Me.lot_no.Location = New System.Drawing.Point(28, 182)
        Me.lot_no.Name = "lot_no"
        Me.lot_no.Size = New System.Drawing.Size(297, 21)
        Me.lot_no.TabIndex = 102
        Me.lot_no.Title = "LOT NO."
        Me.lot_no.TitleWidth = 98
        '
        'job_no
        '
        Me.job_no.ColumnName = "job_no"
        Me.job_no.Location = New System.Drawing.Point(209, 254)
        Me.job_no.Name = "job_no"
        Me.job_no.Size = New System.Drawing.Size(254, 21)
        Me.job_no.TabIndex = 88
        Me.job_no.TableName = "job_no"
        Me.job_no.Title = "생산지시번호"
        Me.job_no.TitleWidth = 98
        '
        'ps_cd
        '
        Me.ps_cd.ColumnName = "ps_cd"
        Me.ps_cd.Location = New System.Drawing.Point(342, 38)
        Me.ps_cd.Name = "ps_cd"
        Me.ps_cd.Size = New System.Drawing.Size(176, 21)
        Me.ps_cd.TabIndex = 90
        Me.ps_cd.TableName = "ps_cd"
        Me.ps_cd.Title = "작성자"
        Me.ps_cd.TitleWidth = 98
        '
        'XtraTabControl2
        '
        Me.XtraTabControl2.AccessibleName = ""
        Me.XtraTabControl2.Location = New System.Drawing.Point(900, 171)
        Me.XtraTabControl2.Name = "XtraTabControl2"
        Me.XtraTabControl2.SelectedTabPage = Me.XtraTabPage8
        Me.XtraTabControl2.Size = New System.Drawing.Size(276, 104)
        Me.XtraTabControl2.TabIndex = 144
        Me.XtraTabControl2.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage8})
        '
        'XtraTabPage8
        '
        Me.XtraTabPage8.Controls.Add(Me.remark)
        Me.XtraTabPage8.Name = "XtraTabPage8"
        Me.XtraTabPage8.Size = New System.Drawing.Size(269, 74)
        Me.XtraTabPage8.Text = "XtraTabPage8"
        '
        'remark
        '
        Me.remark.Dock = System.Windows.Forms.DockStyle.Fill
        Me.remark.Location = New System.Drawing.Point(0, 0)
        Me.remark.Name = "remark"
        Me.remark.Size = New System.Drawing.Size(269, 74)
        Me.remark.TabIndex = 0
        Me.remark.TitleWidth = 0
        '
        'POP_SP
        '
        Me.POP_SP.ColumnName = "job_no"
        Me.POP_SP.Location = New System.Drawing.Point(28, 254)
        Me.POP_SP.Name = "POP_SP"
        Me.POP_SP.Size = New System.Drawing.Size(296, 21)
        Me.POP_SP.TabIndex = 88
        Me.POP_SP.TableName = "job_no"
        Me.POP_SP.Title = "코아 S.P"
        Me.POP_SP.TitleWidth = 98
        '
        'job_seq
        '
        Me.job_seq.ColumnName = "job_no"
        Me.job_seq.Location = New System.Drawing.Point(287, 254)
        Me.job_seq.Name = "job_seq"
        Me.job_seq.Size = New System.Drawing.Size(37, 21)
        Me.job_seq.TabIndex = 110
        Me.job_seq.TableName = "job_no"
        Me.job_seq.Title = "생산지시번호"
        Me.job_seq.TitleWidth = 0
        '
        'gd_cd
        '
        Me.gd_cd.ColumnName = "ps_cd"
        Me.gd_cd.Location = New System.Drawing.Point(28, 86)
        Me.gd_cd.Name = "gd_cd"
        Me.gd_cd.Size = New System.Drawing.Size(297, 21)
        Me.gd_cd.TabIndex = 94
        Me.gd_cd.TableName = "ps_cd"
        Me.gd_cd.Title = "품목"
        Me.gd_cd.TitleWidth = 98
        '
        'to_dt
        '
        Me.to_dt.ColumnName = "plan_dt"
        Me.to_dt.Location = New System.Drawing.Point(28, 230)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(233, 21)
        Me.to_dt.TabIndex = 104
        Me.to_dt.TableName = "plan_dt"
        Me.to_dt.Title = "생산완료일시"
        Me.to_dt.TitleWidth = 98
        '
        'spec
        '
        Me.spec.ColumnName = "ps_cd"
        Me.spec.Location = New System.Drawing.Point(28, 134)
        Me.spec.Name = "spec"
        Me.spec.Size = New System.Drawing.Size(297, 21)
        Me.spec.TabIndex = 96
        Me.spec.TableName = "ps_cd"
        Me.spec.Title = "규격"
        Me.spec.TitleWidth = 98
        '
        'wa_cd
        '
        Me.wa_cd.Location = New System.Drawing.Point(342, 182)
        Me.wa_cd.Name = "wa_cd"
        Me.wa_cd.Size = New System.Drawing.Size(297, 21)
        Me.wa_cd.TabIndex = 93
        Me.wa_cd.Title = "작업장"
        Me.wa_cd.TitleWidth = 98
        '
        'gd_nm
        '
        Me.gd_nm.ColumnName = "ps_cd"
        Me.gd_nm.Location = New System.Drawing.Point(28, 110)
        Me.gd_nm.Name = "gd_nm"
        Me.gd_nm.Size = New System.Drawing.Size(297, 21)
        Me.gd_nm.TabIndex = 95
        Me.gd_nm.TableName = "ps_cd"
        Me.gd_nm.Title = "품명"
        Me.gd_nm.TitleWidth = 98
        '
        'pr_qty
        '
        Me.pr_qty.ColumnName = "ps_cd"
        Me.pr_qty.Location = New System.Drawing.Point(693, 206)
        Me.pr_qty.Name = "pr_qty"
        Me.pr_qty.Size = New System.Drawing.Size(201, 21)
        Me.pr_qty.TabIndex = 100
        Me.pr_qty.TableName = "ps_cd"
        Me.pr_qty.Title = "양품"
        Me.pr_qty.TitleWidth = 70
        '
        'job_qty
        '
        Me.job_qty.ColumnName = "ps_cd"
        Me.job_qty.Location = New System.Drawing.Point(693, 158)
        Me.job_qty.Name = "job_qty"
        Me.job_qty.Size = New System.Drawing.Size(201, 21)
        Me.job_qty.TabIndex = 98
        Me.job_qty.TableName = "ps_cd"
        Me.job_qty.Title = "지시수량"
        Me.job_qty.TitleWidth = 70
        '
        'ng_qty
        '
        Me.ng_qty.ColumnName = "ps_cd"
        Me.ng_qty.Location = New System.Drawing.Point(693, 230)
        Me.ng_qty.Name = "ng_qty"
        Me.ng_qty.Size = New System.Drawing.Size(201, 21)
        Me.ng_qty.TabIndex = 101
        Me.ng_qty.TableName = "ps_cd"
        Me.ng_qty.Title = "불량"
        Me.ng_qty.TitleWidth = 70
        '
        'tot_qty
        '
        Me.tot_qty.ColumnName = "ps_cd"
        Me.tot_qty.Location = New System.Drawing.Point(693, 182)
        Me.tot_qty.Name = "tot_qty"
        Me.tot_qty.Size = New System.Drawing.Size(201, 21)
        Me.tot_qty.TabIndex = 99
        Me.tot_qty.TableName = "ps_cd"
        Me.tot_qty.Title = "생산수량"
        Me.tot_qty.TitleWidth = 70
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1237, 323)
        Me.XtraTabControl1.TabIndex = 55
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2, Me.XtraTabPage3, Me.XtraTabPage4, Me.XtraTabPage5, Me.XtraTabPage6})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.SplitContainer3)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage1.Text = "투입 품목"
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.g_body1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.XtraTabControl12)
        Me.SplitContainer3.Size = New System.Drawing.Size(1230, 293)
        Me.SplitContainer3.SplitterDistance = 617
        Me.SplitContainer3.TabIndex = 145
        '
        'g_body1
        '
        Me.g_body1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body1.Location = New System.Drawing.Point(0, 0)
        Me.g_body1.Name = "g_body1"
        Me.g_body1.ReadOnly = False
        Me.g_body1.RecordNavigator = False
        Me.g_body1.RowHeight = -1
        Me.g_body1.Size = New System.Drawing.Size(617, 293)
        Me.g_body1.TabIndex = 1
        '
        'XtraTabControl12
        '
        Me.XtraTabControl12.AccessibleName = ""
        Me.XtraTabControl12.Location = New System.Drawing.Point(3, 0)
        Me.XtraTabControl12.Name = "XtraTabControl12"
        Me.XtraTabControl12.SelectedTabPage = Me.XtraTabPage10
        Me.XtraTabControl12.Size = New System.Drawing.Size(601, 277)
        Me.XtraTabControl12.TabIndex = 144
        Me.XtraTabControl12.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage10, Me.XtraTabPage11, Me.XtraTabPage12})
        '
        'XtraTabPage10
        '
        Me.XtraTabPage10.Controls.Add(Me.GroupBox2)
        Me.XtraTabPage10.Controls.Add(Me.GroupBox4)
        Me.XtraTabPage10.Controls.Add(Me.GroupBox3)
        Me.XtraTabPage10.Controls.Add(Me.GroupBox1)
        Me.XtraTabPage10.Name = "XtraTabPage10"
        Me.XtraTabPage10.Size = New System.Drawing.Size(594, 247)
        Me.XtraTabPage10.Text = "1도"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.SAVE_IMG2)
        Me.GroupBox2.Controls.Add(Me.RESET2)
        Me.GroupBox2.Controls.Add(Me.PictureBox39)
        Me.GroupBox2.Controls.Add(Me.PictureBox32)
        Me.GroupBox2.Controls.Add(Me.PictureBox29)
        Me.GroupBox2.Controls.Add(Me.PictureBox31)
        Me.GroupBox2.Controls.Add(Me.PictureBox38)
        Me.GroupBox2.Controls.Add(Me.PictureBox34)
        Me.GroupBox2.Controls.Add(Me.PictureBox33)
        Me.GroupBox2.Controls.Add(Me.PictureBox37)
        Me.GroupBox2.Controls.Add(Me.PictureBox22)
        Me.GroupBox2.Controls.Add(Me.PictureBox36)
        Me.GroupBox2.Controls.Add(Me.PictureBox23)
        Me.GroupBox2.Controls.Add(Me.PictureBox35)
        Me.GroupBox2.Controls.Add(Me.PictureBox21)
        Me.GroupBox2.Controls.Add(Me.PictureBox24)
        Me.GroupBox2.Controls.Add(Me.PictureBox25)
        Me.GroupBox2.Controls.Add(Me.PictureBox26)
        Me.GroupBox2.Controls.Add(Me.PictureBox27)
        Me.GroupBox2.Controls.Add(Me.PictureBox28)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox2.Location = New System.Drawing.Point(152, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "20.색상번짐"
        '
        'SAVE_IMG2
        '
        Me.SAVE_IMG2.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG2.Name = "SAVE_IMG2"
        Me.SAVE_IMG2.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG2.TabIndex = 78
        Me.SAVE_IMG2.Text = "저 장"
        '
        'RESET2
        '
        Me.RESET2.Location = New System.Drawing.Point(12, 196)
        Me.RESET2.Name = "RESET2"
        Me.RESET2.Size = New System.Drawing.Size(49, 25)
        Me.RESET2.TabIndex = 77
        Me.RESET2.Text = "초기화"
        '
        'PictureBox39
        '
        Me.PictureBox39.Image = CType(resources.GetObject("PictureBox39.Image"), System.Drawing.Image)
        Me.PictureBox39.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox39.Name = "PictureBox39"
        Me.PictureBox39.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox39.TabIndex = 76
        Me.PictureBox39.TabStop = False
        Me.PictureBox39.Visible = False
        '
        'PictureBox32
        '
        Me.PictureBox32.Image = CType(resources.GetObject("PictureBox32.Image"), System.Drawing.Image)
        Me.PictureBox32.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox32.TabIndex = 18
        Me.PictureBox32.TabStop = False
        Me.PictureBox32.Visible = False
        '
        'PictureBox29
        '
        Me.PictureBox29.Image = CType(resources.GetObject("PictureBox29.Image"), System.Drawing.Image)
        Me.PictureBox29.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox29.TabIndex = 20
        Me.PictureBox29.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.Image = CType(resources.GetObject("PictureBox31.Image"), System.Drawing.Image)
        Me.PictureBox31.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox31.TabIndex = 17
        Me.PictureBox31.TabStop = False
        Me.PictureBox31.Visible = False
        '
        'PictureBox38
        '
        Me.PictureBox38.Image = CType(resources.GetObject("PictureBox38.Image"), System.Drawing.Image)
        Me.PictureBox38.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox38.Name = "PictureBox38"
        Me.PictureBox38.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox38.TabIndex = 24
        Me.PictureBox38.TabStop = False
        Me.PictureBox38.Visible = False
        '
        'PictureBox34
        '
        Me.PictureBox34.Image = CType(resources.GetObject("PictureBox34.Image"), System.Drawing.Image)
        Me.PictureBox34.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox34.TabIndex = 19
        Me.PictureBox34.TabStop = False
        Me.PictureBox34.Visible = False
        '
        'PictureBox33
        '
        Me.PictureBox33.Image = CType(resources.GetObject("PictureBox33.Image"), System.Drawing.Image)
        Me.PictureBox33.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox33.TabIndex = 20
        Me.PictureBox33.TabStop = False
        Me.PictureBox33.Visible = False
        '
        'PictureBox37
        '
        Me.PictureBox37.Image = CType(resources.GetObject("PictureBox37.Image"), System.Drawing.Image)
        Me.PictureBox37.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox37.Name = "PictureBox37"
        Me.PictureBox37.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox37.TabIndex = 23
        Me.PictureBox37.TabStop = False
        Me.PictureBox37.Visible = False
        '
        'PictureBox22
        '
        Me.PictureBox22.Image = CType(resources.GetObject("PictureBox22.Image"), System.Drawing.Image)
        Me.PictureBox22.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox22.TabIndex = 15
        Me.PictureBox22.TabStop = False
        '
        'PictureBox36
        '
        Me.PictureBox36.Image = CType(resources.GetObject("PictureBox36.Image"), System.Drawing.Image)
        Me.PictureBox36.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox36.Name = "PictureBox36"
        Me.PictureBox36.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox36.TabIndex = 22
        Me.PictureBox36.TabStop = False
        Me.PictureBox36.Visible = False
        '
        'PictureBox23
        '
        Me.PictureBox23.Image = CType(resources.GetObject("PictureBox23.Image"), System.Drawing.Image)
        Me.PictureBox23.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox23.TabIndex = 14
        Me.PictureBox23.TabStop = False
        '
        'PictureBox35
        '
        Me.PictureBox35.Image = CType(resources.GetObject("PictureBox35.Image"), System.Drawing.Image)
        Me.PictureBox35.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox35.Name = "PictureBox35"
        Me.PictureBox35.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox35.TabIndex = 21
        Me.PictureBox35.TabStop = False
        Me.PictureBox35.Visible = False
        '
        'PictureBox21
        '
        Me.PictureBox21.Image = CType(resources.GetObject("PictureBox21.Image"), System.Drawing.Image)
        Me.PictureBox21.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox21.TabIndex = 13
        Me.PictureBox21.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.Image = CType(resources.GetObject("PictureBox24.Image"), System.Drawing.Image)
        Me.PictureBox24.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox24.TabIndex = 16
        Me.PictureBox24.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.Image = CType(resources.GetObject("PictureBox25.Image"), System.Drawing.Image)
        Me.PictureBox25.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox25.TabIndex = 17
        Me.PictureBox25.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.Image = CType(resources.GetObject("PictureBox26.Image"), System.Drawing.Image)
        Me.PictureBox26.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox26.TabIndex = 18
        Me.PictureBox26.TabStop = False
        '
        'PictureBox27
        '
        Me.PictureBox27.Image = CType(resources.GetObject("PictureBox27.Image"), System.Drawing.Image)
        Me.PictureBox27.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox27.TabIndex = 19
        Me.PictureBox27.TabStop = False
        '
        'PictureBox28
        '
        Me.PictureBox28.Image = CType(resources.GetObject("PictureBox28.Image"), System.Drawing.Image)
        Me.PictureBox28.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox28.TabIndex = 21
        Me.PictureBox28.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.SAVE_IMG4)
        Me.GroupBox4.Controls.Add(Me.RESET4)
        Me.GroupBox4.Controls.Add(Me.PictureBox79)
        Me.GroupBox4.Controls.Add(Me.PictureBox78)
        Me.GroupBox4.Controls.Add(Me.PictureBox77)
        Me.GroupBox4.Controls.Add(Me.PictureBox76)
        Me.GroupBox4.Controls.Add(Me.PictureBox75)
        Me.GroupBox4.Controls.Add(Me.PictureBox74)
        Me.GroupBox4.Controls.Add(Me.PictureBox73)
        Me.GroupBox4.Controls.Add(Me.PictureBox72)
        Me.GroupBox4.Controls.Add(Me.PictureBox71)
        Me.GroupBox4.Controls.Add(Me.PictureBox68)
        Me.GroupBox4.Controls.Add(Me.PictureBox69)
        Me.GroupBox4.Controls.Add(Me.PictureBox67)
        Me.GroupBox4.Controls.Add(Me.PictureBox66)
        Me.GroupBox4.Controls.Add(Me.PictureBox65)
        Me.GroupBox4.Controls.Add(Me.PictureBox64)
        Me.GroupBox4.Controls.Add(Me.PictureBox62)
        Me.GroupBox4.Controls.Add(Me.PictureBox63)
        Me.GroupBox4.Controls.Add(Me.PictureBox61)
        Me.GroupBox4.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox4.Location = New System.Drawing.Point(442, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "28.인쇄불량"
        '
        'SAVE_IMG4
        '
        Me.SAVE_IMG4.Location = New System.Drawing.Point(83, 196)
        Me.SAVE_IMG4.Name = "SAVE_IMG4"
        Me.SAVE_IMG4.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG4.TabIndex = 80
        Me.SAVE_IMG4.Text = "저 장"
        '
        'RESET4
        '
        Me.RESET4.Location = New System.Drawing.Point(13, 196)
        Me.RESET4.Name = "RESET4"
        Me.RESET4.Size = New System.Drawing.Size(49, 25)
        Me.RESET4.TabIndex = 79
        Me.RESET4.Text = "초기화"
        '
        'PictureBox79
        '
        Me.PictureBox79.Image = CType(resources.GetObject("PictureBox79.Image"), System.Drawing.Image)
        Me.PictureBox79.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox79.Name = "PictureBox79"
        Me.PictureBox79.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox79.TabIndex = 48
        Me.PictureBox79.TabStop = False
        Me.PictureBox79.Visible = False
        '
        'PictureBox78
        '
        Me.PictureBox78.Image = CType(resources.GetObject("PictureBox78.Image"), System.Drawing.Image)
        Me.PictureBox78.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox78.Name = "PictureBox78"
        Me.PictureBox78.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox78.TabIndex = 47
        Me.PictureBox78.TabStop = False
        Me.PictureBox78.Visible = False
        '
        'PictureBox77
        '
        Me.PictureBox77.Image = CType(resources.GetObject("PictureBox77.Image"), System.Drawing.Image)
        Me.PictureBox77.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox77.Name = "PictureBox77"
        Me.PictureBox77.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox77.TabIndex = 46
        Me.PictureBox77.TabStop = False
        Me.PictureBox77.Visible = False
        '
        'PictureBox76
        '
        Me.PictureBox76.Image = CType(resources.GetObject("PictureBox76.Image"), System.Drawing.Image)
        Me.PictureBox76.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox76.TabIndex = 45
        Me.PictureBox76.TabStop = False
        Me.PictureBox76.Visible = False
        '
        'PictureBox75
        '
        Me.PictureBox75.Image = CType(resources.GetObject("PictureBox75.Image"), System.Drawing.Image)
        Me.PictureBox75.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox75.Name = "PictureBox75"
        Me.PictureBox75.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox75.TabIndex = 44
        Me.PictureBox75.TabStop = False
        Me.PictureBox75.Visible = False
        '
        'PictureBox74
        '
        Me.PictureBox74.Image = CType(resources.GetObject("PictureBox74.Image"), System.Drawing.Image)
        Me.PictureBox74.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox74.TabIndex = 43
        Me.PictureBox74.TabStop = False
        Me.PictureBox74.Visible = False
        '
        'PictureBox73
        '
        Me.PictureBox73.Image = CType(resources.GetObject("PictureBox73.Image"), System.Drawing.Image)
        Me.PictureBox73.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox73.Name = "PictureBox73"
        Me.PictureBox73.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox73.TabIndex = 42
        Me.PictureBox73.TabStop = False
        Me.PictureBox73.Visible = False
        '
        'PictureBox72
        '
        Me.PictureBox72.Image = CType(resources.GetObject("PictureBox72.Image"), System.Drawing.Image)
        Me.PictureBox72.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox72.TabIndex = 41
        Me.PictureBox72.TabStop = False
        Me.PictureBox72.Visible = False
        '
        'PictureBox71
        '
        Me.PictureBox71.Image = CType(resources.GetObject("PictureBox71.Image"), System.Drawing.Image)
        Me.PictureBox71.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox71.Name = "PictureBox71"
        Me.PictureBox71.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox71.TabIndex = 40
        Me.PictureBox71.TabStop = False
        Me.PictureBox71.Visible = False
        '
        'PictureBox68
        '
        Me.PictureBox68.Image = CType(resources.GetObject("PictureBox68.Image"), System.Drawing.Image)
        Me.PictureBox68.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox68.Name = "PictureBox68"
        Me.PictureBox68.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox68.TabIndex = 30
        Me.PictureBox68.TabStop = False
        '
        'PictureBox69
        '
        Me.PictureBox69.Image = CType(resources.GetObject("PictureBox69.Image"), System.Drawing.Image)
        Me.PictureBox69.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox69.Name = "PictureBox69"
        Me.PictureBox69.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox69.TabIndex = 29
        Me.PictureBox69.TabStop = False
        '
        'PictureBox67
        '
        Me.PictureBox67.Image = CType(resources.GetObject("PictureBox67.Image"), System.Drawing.Image)
        Me.PictureBox67.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox67.Name = "PictureBox67"
        Me.PictureBox67.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox67.TabIndex = 28
        Me.PictureBox67.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.Image = CType(resources.GetObject("PictureBox66.Image"), System.Drawing.Image)
        Me.PictureBox66.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox66.TabIndex = 27
        Me.PictureBox66.TabStop = False
        '
        'PictureBox65
        '
        Me.PictureBox65.Image = CType(resources.GetObject("PictureBox65.Image"), System.Drawing.Image)
        Me.PictureBox65.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox65.Name = "PictureBox65"
        Me.PictureBox65.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox65.TabIndex = 26
        Me.PictureBox65.TabStop = False
        '
        'PictureBox64
        '
        Me.PictureBox64.Image = CType(resources.GetObject("PictureBox64.Image"), System.Drawing.Image)
        Me.PictureBox64.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox64.Name = "PictureBox64"
        Me.PictureBox64.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox64.TabIndex = 25
        Me.PictureBox64.TabStop = False
        '
        'PictureBox62
        '
        Me.PictureBox62.Image = CType(resources.GetObject("PictureBox62.Image"), System.Drawing.Image)
        Me.PictureBox62.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox62.Name = "PictureBox62"
        Me.PictureBox62.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox62.TabIndex = 24
        Me.PictureBox62.TabStop = False
        '
        'PictureBox63
        '
        Me.PictureBox63.Image = CType(resources.GetObject("PictureBox63.Image"), System.Drawing.Image)
        Me.PictureBox63.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox63.Name = "PictureBox63"
        Me.PictureBox63.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox63.TabIndex = 23
        Me.PictureBox63.TabStop = False
        '
        'PictureBox61
        '
        Me.PictureBox61.Image = CType(resources.GetObject("PictureBox61.Image"), System.Drawing.Image)
        Me.PictureBox61.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox61.Name = "PictureBox61"
        Me.PictureBox61.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox61.TabIndex = 22
        Me.PictureBox61.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.SAVE_IMG3)
        Me.GroupBox3.Controls.Add(Me.RESET3)
        Me.GroupBox3.Controls.Add(Me.PictureBox59)
        Me.GroupBox3.Controls.Add(Me.PictureBox58)
        Me.GroupBox3.Controls.Add(Me.PictureBox57)
        Me.GroupBox3.Controls.Add(Me.PictureBox56)
        Me.GroupBox3.Controls.Add(Me.PictureBox55)
        Me.GroupBox3.Controls.Add(Me.PictureBox54)
        Me.GroupBox3.Controls.Add(Me.PictureBox53)
        Me.GroupBox3.Controls.Add(Me.PictureBox52)
        Me.GroupBox3.Controls.Add(Me.PictureBox51)
        Me.GroupBox3.Controls.Add(Me.PictureBox48)
        Me.GroupBox3.Controls.Add(Me.PictureBox49)
        Me.GroupBox3.Controls.Add(Me.PictureBox47)
        Me.GroupBox3.Controls.Add(Me.PictureBox46)
        Me.GroupBox3.Controls.Add(Me.PictureBox45)
        Me.GroupBox3.Controls.Add(Me.PictureBox44)
        Me.GroupBox3.Controls.Add(Me.PictureBox42)
        Me.GroupBox3.Controls.Add(Me.PictureBox43)
        Me.GroupBox3.Controls.Add(Me.PictureBox41)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox3.Location = New System.Drawing.Point(297, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "21.알+번짐"
        '
        'SAVE_IMG3
        '
        Me.SAVE_IMG3.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG3.Name = "SAVE_IMG3"
        Me.SAVE_IMG3.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG3.TabIndex = 79
        Me.SAVE_IMG3.Text = "저 장"
        '
        'RESET3
        '
        Me.RESET3.Location = New System.Drawing.Point(12, 196)
        Me.RESET3.Name = "RESET3"
        Me.RESET3.Size = New System.Drawing.Size(49, 25)
        Me.RESET3.TabIndex = 78
        Me.RESET3.Text = "초기화"
        '
        'PictureBox59
        '
        Me.PictureBox59.Image = CType(resources.GetObject("PictureBox59.Image"), System.Drawing.Image)
        Me.PictureBox59.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox59.Name = "PictureBox59"
        Me.PictureBox59.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox59.TabIndex = 39
        Me.PictureBox59.TabStop = False
        Me.PictureBox59.Visible = False
        '
        'PictureBox58
        '
        Me.PictureBox58.Image = CType(resources.GetObject("PictureBox58.Image"), System.Drawing.Image)
        Me.PictureBox58.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox58.Name = "PictureBox58"
        Me.PictureBox58.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox58.TabIndex = 38
        Me.PictureBox58.TabStop = False
        Me.PictureBox58.Visible = False
        '
        'PictureBox57
        '
        Me.PictureBox57.Image = CType(resources.GetObject("PictureBox57.Image"), System.Drawing.Image)
        Me.PictureBox57.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox57.Name = "PictureBox57"
        Me.PictureBox57.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox57.TabIndex = 37
        Me.PictureBox57.TabStop = False
        Me.PictureBox57.Visible = False
        '
        'PictureBox56
        '
        Me.PictureBox56.Image = CType(resources.GetObject("PictureBox56.Image"), System.Drawing.Image)
        Me.PictureBox56.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox56.Name = "PictureBox56"
        Me.PictureBox56.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox56.TabIndex = 36
        Me.PictureBox56.TabStop = False
        Me.PictureBox56.Visible = False
        '
        'PictureBox55
        '
        Me.PictureBox55.Image = CType(resources.GetObject("PictureBox55.Image"), System.Drawing.Image)
        Me.PictureBox55.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox55.Name = "PictureBox55"
        Me.PictureBox55.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox55.TabIndex = 35
        Me.PictureBox55.TabStop = False
        Me.PictureBox55.Visible = False
        '
        'PictureBox54
        '
        Me.PictureBox54.Image = CType(resources.GetObject("PictureBox54.Image"), System.Drawing.Image)
        Me.PictureBox54.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox54.Name = "PictureBox54"
        Me.PictureBox54.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox54.TabIndex = 34
        Me.PictureBox54.TabStop = False
        Me.PictureBox54.Visible = False
        '
        'PictureBox53
        '
        Me.PictureBox53.Image = CType(resources.GetObject("PictureBox53.Image"), System.Drawing.Image)
        Me.PictureBox53.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox53.Name = "PictureBox53"
        Me.PictureBox53.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox53.TabIndex = 33
        Me.PictureBox53.TabStop = False
        Me.PictureBox53.Visible = False
        '
        'PictureBox52
        '
        Me.PictureBox52.Image = CType(resources.GetObject("PictureBox52.Image"), System.Drawing.Image)
        Me.PictureBox52.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox52.Name = "PictureBox52"
        Me.PictureBox52.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox52.TabIndex = 32
        Me.PictureBox52.TabStop = False
        Me.PictureBox52.Visible = False
        '
        'PictureBox51
        '
        Me.PictureBox51.Image = CType(resources.GetObject("PictureBox51.Image"), System.Drawing.Image)
        Me.PictureBox51.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox51.Name = "PictureBox51"
        Me.PictureBox51.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox51.TabIndex = 31
        Me.PictureBox51.TabStop = False
        Me.PictureBox51.Visible = False
        '
        'PictureBox48
        '
        Me.PictureBox48.Image = CType(resources.GetObject("PictureBox48.Image"), System.Drawing.Image)
        Me.PictureBox48.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox48.Name = "PictureBox48"
        Me.PictureBox48.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox48.TabIndex = 30
        Me.PictureBox48.TabStop = False
        '
        'PictureBox49
        '
        Me.PictureBox49.Image = CType(resources.GetObject("PictureBox49.Image"), System.Drawing.Image)
        Me.PictureBox49.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox49.Name = "PictureBox49"
        Me.PictureBox49.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox49.TabIndex = 29
        Me.PictureBox49.TabStop = False
        '
        'PictureBox47
        '
        Me.PictureBox47.Image = CType(resources.GetObject("PictureBox47.Image"), System.Drawing.Image)
        Me.PictureBox47.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox47.Name = "PictureBox47"
        Me.PictureBox47.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox47.TabIndex = 28
        Me.PictureBox47.TabStop = False
        '
        'PictureBox46
        '
        Me.PictureBox46.Image = CType(resources.GetObject("PictureBox46.Image"), System.Drawing.Image)
        Me.PictureBox46.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox46.Name = "PictureBox46"
        Me.PictureBox46.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox46.TabIndex = 27
        Me.PictureBox46.TabStop = False
        '
        'PictureBox45
        '
        Me.PictureBox45.Image = CType(resources.GetObject("PictureBox45.Image"), System.Drawing.Image)
        Me.PictureBox45.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox45.Name = "PictureBox45"
        Me.PictureBox45.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox45.TabIndex = 26
        Me.PictureBox45.TabStop = False
        '
        'PictureBox44
        '
        Me.PictureBox44.Image = CType(resources.GetObject("PictureBox44.Image"), System.Drawing.Image)
        Me.PictureBox44.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox44.Name = "PictureBox44"
        Me.PictureBox44.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox44.TabIndex = 25
        Me.PictureBox44.TabStop = False
        '
        'PictureBox42
        '
        Me.PictureBox42.Image = CType(resources.GetObject("PictureBox42.Image"), System.Drawing.Image)
        Me.PictureBox42.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox42.Name = "PictureBox42"
        Me.PictureBox42.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox42.TabIndex = 24
        Me.PictureBox42.TabStop = False
        '
        'PictureBox43
        '
        Me.PictureBox43.Image = CType(resources.GetObject("PictureBox43.Image"), System.Drawing.Image)
        Me.PictureBox43.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox43.Name = "PictureBox43"
        Me.PictureBox43.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox43.TabIndex = 23
        Me.PictureBox43.TabStop = False
        '
        'PictureBox41
        '
        Me.PictureBox41.Image = CType(resources.GetObject("PictureBox41.Image"), System.Drawing.Image)
        Me.PictureBox41.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox41.Name = "PictureBox41"
        Me.PictureBox41.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox41.TabIndex = 22
        Me.PictureBox41.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SAVE_IMG)
        Me.GroupBox1.Controls.Add(Me.PictureBox12)
        Me.GroupBox1.Controls.Add(Me.PictureBox19)
        Me.GroupBox1.Controls.Add(Me.PictureBox18)
        Me.GroupBox1.Controls.Add(Me.PictureBox17)
        Me.GroupBox1.Controls.Add(Me.PictureBox16)
        Me.GroupBox1.Controls.Add(Me.PictureBox15)
        Me.GroupBox1.Controls.Add(Me.PictureBox14)
        Me.GroupBox1.Controls.Add(Me.RESET)
        Me.GroupBox1.Controls.Add(Me.PictureBox13)
        Me.GroupBox1.Controls.Add(Me.PictureBox11)
        Me.GroupBox1.Controls.Add(Me.PictureBox9)
        Me.GroupBox1.Controls.Add(Me.PictureBox8)
        Me.GroupBox1.Controls.Add(Me.PictureBox7)
        Me.GroupBox1.Controls.Add(Me.PictureBox6)
        Me.GroupBox1.Controls.Add(Me.PictureBox5)
        Me.GroupBox1.Controls.Add(Me.PictureBox4)
        Me.GroupBox1.Controls.Add(Me.PictureBox2)
        Me.GroupBox1.Controls.Add(Me.PictureBox3)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "19.알떨어짐"
        '
        'SAVE_IMG
        '
        Me.SAVE_IMG.Location = New System.Drawing.Point(88, 196)
        Me.SAVE_IMG.Name = "SAVE_IMG"
        Me.SAVE_IMG.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG.TabIndex = 75
        Me.SAVE_IMG.Text = "저 장"
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = CType(resources.GetObject("PictureBox12.Image"), System.Drawing.Image)
        Me.PictureBox12.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox12.TabIndex = 11
        Me.PictureBox12.TabStop = False
        Me.PictureBox12.Visible = False
        '
        'PictureBox19
        '
        Me.PictureBox19.Image = CType(resources.GetObject("PictureBox19.Image"), System.Drawing.Image)
        Me.PictureBox19.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox19.TabIndex = 16
        Me.PictureBox19.TabStop = False
        Me.PictureBox19.Visible = False
        '
        'PictureBox18
        '
        Me.PictureBox18.Image = CType(resources.GetObject("PictureBox18.Image"), System.Drawing.Image)
        Me.PictureBox18.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox18.TabIndex = 15
        Me.PictureBox18.TabStop = False
        Me.PictureBox18.Visible = False
        '
        'PictureBox17
        '
        Me.PictureBox17.Image = CType(resources.GetObject("PictureBox17.Image"), System.Drawing.Image)
        Me.PictureBox17.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox17.TabIndex = 14
        Me.PictureBox17.TabStop = False
        Me.PictureBox17.Visible = False
        '
        'PictureBox16
        '
        Me.PictureBox16.Image = CType(resources.GetObject("PictureBox16.Image"), System.Drawing.Image)
        Me.PictureBox16.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox16.TabIndex = 13
        Me.PictureBox16.TabStop = False
        Me.PictureBox16.Visible = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), System.Drawing.Image)
        Me.PictureBox15.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox15.TabIndex = 12
        Me.PictureBox15.TabStop = False
        Me.PictureBox15.Visible = False
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Image)
        Me.PictureBox14.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox14.TabIndex = 11
        Me.PictureBox14.TabStop = False
        Me.PictureBox14.Visible = False
        '
        'RESET
        '
        Me.RESET.Location = New System.Drawing.Point(13, 196)
        Me.RESET.Name = "RESET"
        Me.RESET.Size = New System.Drawing.Size(49, 25)
        Me.RESET.TabIndex = 74
        Me.RESET.Text = "초기화"
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), System.Drawing.Image)
        Me.PictureBox13.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox13.TabIndex = 12
        Me.PictureBox13.TabStop = False
        Me.PictureBox13.Visible = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox11.TabIndex = 10
        Me.PictureBox11.TabStop = False
        Me.PictureBox11.Visible = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox9.TabIndex = 9
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox8.TabIndex = 8
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox7.TabIndex = 7
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox6.TabIndex = 6
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox5.TabIndex = 5
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox4.TabIndex = 4
        Me.PictureBox4.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'XtraTabPage11
        '
        Me.XtraTabPage11.Controls.Add(Me.GroupBox5)
        Me.XtraTabPage11.Controls.Add(Me.GroupBox6)
        Me.XtraTabPage11.Controls.Add(Me.GroupBox7)
        Me.XtraTabPage11.Controls.Add(Me.GroupBox8)
        Me.XtraTabPage11.Name = "XtraTabPage11"
        Me.XtraTabPage11.Size = New System.Drawing.Size(594, 247)
        Me.XtraTabPage11.Text = "2도"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.SAVE_IMG6)
        Me.GroupBox5.Controls.Add(Me.RESET6)
        Me.GroupBox5.Controls.Add(Me.PictureBox119)
        Me.GroupBox5.Controls.Add(Me.PictureBox112)
        Me.GroupBox5.Controls.Add(Me.PictureBox109)
        Me.GroupBox5.Controls.Add(Me.PictureBox111)
        Me.GroupBox5.Controls.Add(Me.PictureBox118)
        Me.GroupBox5.Controls.Add(Me.PictureBox114)
        Me.GroupBox5.Controls.Add(Me.PictureBox113)
        Me.GroupBox5.Controls.Add(Me.PictureBox117)
        Me.GroupBox5.Controls.Add(Me.PictureBox102)
        Me.GroupBox5.Controls.Add(Me.PictureBox116)
        Me.GroupBox5.Controls.Add(Me.PictureBox103)
        Me.GroupBox5.Controls.Add(Me.PictureBox115)
        Me.GroupBox5.Controls.Add(Me.PictureBox101)
        Me.GroupBox5.Controls.Add(Me.PictureBox104)
        Me.GroupBox5.Controls.Add(Me.PictureBox105)
        Me.GroupBox5.Controls.Add(Me.PictureBox106)
        Me.GroupBox5.Controls.Add(Me.PictureBox107)
        Me.GroupBox5.Controls.Add(Me.PictureBox108)
        Me.GroupBox5.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox5.Location = New System.Drawing.Point(152, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "20.색상번짐"
        '
        'SAVE_IMG6
        '
        Me.SAVE_IMG6.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG6.Name = "SAVE_IMG6"
        Me.SAVE_IMG6.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG6.TabIndex = 78
        Me.SAVE_IMG6.Text = "저 장"
        '
        'RESET6
        '
        Me.RESET6.Location = New System.Drawing.Point(12, 196)
        Me.RESET6.Name = "RESET6"
        Me.RESET6.Size = New System.Drawing.Size(49, 25)
        Me.RESET6.TabIndex = 77
        Me.RESET6.Text = "초기화"
        '
        'PictureBox119
        '
        Me.PictureBox119.Image = CType(resources.GetObject("PictureBox119.Image"), System.Drawing.Image)
        Me.PictureBox119.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox119.Name = "PictureBox119"
        Me.PictureBox119.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox119.TabIndex = 76
        Me.PictureBox119.TabStop = False
        Me.PictureBox119.Visible = False
        '
        'PictureBox112
        '
        Me.PictureBox112.Image = CType(resources.GetObject("PictureBox112.Image"), System.Drawing.Image)
        Me.PictureBox112.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox112.Name = "PictureBox112"
        Me.PictureBox112.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox112.TabIndex = 18
        Me.PictureBox112.TabStop = False
        Me.PictureBox112.Visible = False
        '
        'PictureBox109
        '
        Me.PictureBox109.Image = CType(resources.GetObject("PictureBox109.Image"), System.Drawing.Image)
        Me.PictureBox109.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox109.Name = "PictureBox109"
        Me.PictureBox109.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox109.TabIndex = 20
        Me.PictureBox109.TabStop = False
        '
        'PictureBox111
        '
        Me.PictureBox111.Image = CType(resources.GetObject("PictureBox111.Image"), System.Drawing.Image)
        Me.PictureBox111.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox111.Name = "PictureBox111"
        Me.PictureBox111.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox111.TabIndex = 17
        Me.PictureBox111.TabStop = False
        Me.PictureBox111.Visible = False
        '
        'PictureBox118
        '
        Me.PictureBox118.Image = CType(resources.GetObject("PictureBox118.Image"), System.Drawing.Image)
        Me.PictureBox118.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox118.Name = "PictureBox118"
        Me.PictureBox118.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox118.TabIndex = 24
        Me.PictureBox118.TabStop = False
        Me.PictureBox118.Visible = False
        '
        'PictureBox114
        '
        Me.PictureBox114.Image = CType(resources.GetObject("PictureBox114.Image"), System.Drawing.Image)
        Me.PictureBox114.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox114.Name = "PictureBox114"
        Me.PictureBox114.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox114.TabIndex = 19
        Me.PictureBox114.TabStop = False
        Me.PictureBox114.Visible = False
        '
        'PictureBox113
        '
        Me.PictureBox113.Image = CType(resources.GetObject("PictureBox113.Image"), System.Drawing.Image)
        Me.PictureBox113.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox113.Name = "PictureBox113"
        Me.PictureBox113.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox113.TabIndex = 20
        Me.PictureBox113.TabStop = False
        Me.PictureBox113.Visible = False
        '
        'PictureBox117
        '
        Me.PictureBox117.Image = CType(resources.GetObject("PictureBox117.Image"), System.Drawing.Image)
        Me.PictureBox117.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox117.Name = "PictureBox117"
        Me.PictureBox117.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox117.TabIndex = 23
        Me.PictureBox117.TabStop = False
        Me.PictureBox117.Visible = False
        '
        'PictureBox102
        '
        Me.PictureBox102.Image = CType(resources.GetObject("PictureBox102.Image"), System.Drawing.Image)
        Me.PictureBox102.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox102.TabIndex = 15
        Me.PictureBox102.TabStop = False
        '
        'PictureBox116
        '
        Me.PictureBox116.Image = CType(resources.GetObject("PictureBox116.Image"), System.Drawing.Image)
        Me.PictureBox116.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox116.Name = "PictureBox116"
        Me.PictureBox116.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox116.TabIndex = 22
        Me.PictureBox116.TabStop = False
        Me.PictureBox116.Visible = False
        '
        'PictureBox103
        '
        Me.PictureBox103.Image = CType(resources.GetObject("PictureBox103.Image"), System.Drawing.Image)
        Me.PictureBox103.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox103.Name = "PictureBox103"
        Me.PictureBox103.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox103.TabIndex = 14
        Me.PictureBox103.TabStop = False
        '
        'PictureBox115
        '
        Me.PictureBox115.Image = CType(resources.GetObject("PictureBox115.Image"), System.Drawing.Image)
        Me.PictureBox115.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox115.Name = "PictureBox115"
        Me.PictureBox115.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox115.TabIndex = 21
        Me.PictureBox115.TabStop = False
        Me.PictureBox115.Visible = False
        '
        'PictureBox101
        '
        Me.PictureBox101.Image = CType(resources.GetObject("PictureBox101.Image"), System.Drawing.Image)
        Me.PictureBox101.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox101.Name = "PictureBox101"
        Me.PictureBox101.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox101.TabIndex = 13
        Me.PictureBox101.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.Image = CType(resources.GetObject("PictureBox104.Image"), System.Drawing.Image)
        Me.PictureBox104.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox104.TabIndex = 16
        Me.PictureBox104.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.Image = CType(resources.GetObject("PictureBox105.Image"), System.Drawing.Image)
        Me.PictureBox105.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox105.TabIndex = 17
        Me.PictureBox105.TabStop = False
        '
        'PictureBox106
        '
        Me.PictureBox106.Image = CType(resources.GetObject("PictureBox106.Image"), System.Drawing.Image)
        Me.PictureBox106.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox106.Name = "PictureBox106"
        Me.PictureBox106.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox106.TabIndex = 18
        Me.PictureBox106.TabStop = False
        '
        'PictureBox107
        '
        Me.PictureBox107.Image = CType(resources.GetObject("PictureBox107.Image"), System.Drawing.Image)
        Me.PictureBox107.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox107.Name = "PictureBox107"
        Me.PictureBox107.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox107.TabIndex = 19
        Me.PictureBox107.TabStop = False
        '
        'PictureBox108
        '
        Me.PictureBox108.Image = CType(resources.GetObject("PictureBox108.Image"), System.Drawing.Image)
        Me.PictureBox108.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox108.Name = "PictureBox108"
        Me.PictureBox108.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox108.TabIndex = 21
        Me.PictureBox108.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.SAVE_IMG8)
        Me.GroupBox6.Controls.Add(Me.RESET8)
        Me.GroupBox6.Controls.Add(Me.PictureBox159)
        Me.GroupBox6.Controls.Add(Me.PictureBox158)
        Me.GroupBox6.Controls.Add(Me.PictureBox157)
        Me.GroupBox6.Controls.Add(Me.PictureBox156)
        Me.GroupBox6.Controls.Add(Me.PictureBox155)
        Me.GroupBox6.Controls.Add(Me.PictureBox154)
        Me.GroupBox6.Controls.Add(Me.PictureBox153)
        Me.GroupBox6.Controls.Add(Me.PictureBox152)
        Me.GroupBox6.Controls.Add(Me.PictureBox151)
        Me.GroupBox6.Controls.Add(Me.PictureBox148)
        Me.GroupBox6.Controls.Add(Me.PictureBox149)
        Me.GroupBox6.Controls.Add(Me.PictureBox147)
        Me.GroupBox6.Controls.Add(Me.PictureBox146)
        Me.GroupBox6.Controls.Add(Me.PictureBox145)
        Me.GroupBox6.Controls.Add(Me.PictureBox144)
        Me.GroupBox6.Controls.Add(Me.PictureBox142)
        Me.GroupBox6.Controls.Add(Me.PictureBox143)
        Me.GroupBox6.Controls.Add(Me.PictureBox141)
        Me.GroupBox6.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox6.Location = New System.Drawing.Point(442, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox6.TabIndex = 8
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "28.인쇄불량"
        '
        'SAVE_IMG8
        '
        Me.SAVE_IMG8.Location = New System.Drawing.Point(83, 196)
        Me.SAVE_IMG8.Name = "SAVE_IMG8"
        Me.SAVE_IMG8.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG8.TabIndex = 80
        Me.SAVE_IMG8.Text = "저 장"
        '
        'RESET8
        '
        Me.RESET8.Location = New System.Drawing.Point(13, 196)
        Me.RESET8.Name = "RESET8"
        Me.RESET8.Size = New System.Drawing.Size(49, 25)
        Me.RESET8.TabIndex = 79
        Me.RESET8.Text = "초기화"
        '
        'PictureBox159
        '
        Me.PictureBox159.Image = CType(resources.GetObject("PictureBox159.Image"), System.Drawing.Image)
        Me.PictureBox159.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox159.Name = "PictureBox159"
        Me.PictureBox159.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox159.TabIndex = 48
        Me.PictureBox159.TabStop = False
        Me.PictureBox159.Visible = False
        '
        'PictureBox158
        '
        Me.PictureBox158.Image = CType(resources.GetObject("PictureBox158.Image"), System.Drawing.Image)
        Me.PictureBox158.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox158.Name = "PictureBox158"
        Me.PictureBox158.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox158.TabIndex = 47
        Me.PictureBox158.TabStop = False
        Me.PictureBox158.Visible = False
        '
        'PictureBox157
        '
        Me.PictureBox157.Image = CType(resources.GetObject("PictureBox157.Image"), System.Drawing.Image)
        Me.PictureBox157.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox157.Name = "PictureBox157"
        Me.PictureBox157.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox157.TabIndex = 46
        Me.PictureBox157.TabStop = False
        Me.PictureBox157.Visible = False
        '
        'PictureBox156
        '
        Me.PictureBox156.Image = CType(resources.GetObject("PictureBox156.Image"), System.Drawing.Image)
        Me.PictureBox156.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox156.Name = "PictureBox156"
        Me.PictureBox156.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox156.TabIndex = 45
        Me.PictureBox156.TabStop = False
        Me.PictureBox156.Visible = False
        '
        'PictureBox155
        '
        Me.PictureBox155.Image = CType(resources.GetObject("PictureBox155.Image"), System.Drawing.Image)
        Me.PictureBox155.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox155.Name = "PictureBox155"
        Me.PictureBox155.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox155.TabIndex = 44
        Me.PictureBox155.TabStop = False
        Me.PictureBox155.Visible = False
        '
        'PictureBox154
        '
        Me.PictureBox154.Image = CType(resources.GetObject("PictureBox154.Image"), System.Drawing.Image)
        Me.PictureBox154.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox154.Name = "PictureBox154"
        Me.PictureBox154.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox154.TabIndex = 43
        Me.PictureBox154.TabStop = False
        Me.PictureBox154.Visible = False
        '
        'PictureBox153
        '
        Me.PictureBox153.Image = CType(resources.GetObject("PictureBox153.Image"), System.Drawing.Image)
        Me.PictureBox153.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox153.Name = "PictureBox153"
        Me.PictureBox153.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox153.TabIndex = 42
        Me.PictureBox153.TabStop = False
        Me.PictureBox153.Visible = False
        '
        'PictureBox152
        '
        Me.PictureBox152.Image = CType(resources.GetObject("PictureBox152.Image"), System.Drawing.Image)
        Me.PictureBox152.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox152.Name = "PictureBox152"
        Me.PictureBox152.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox152.TabIndex = 41
        Me.PictureBox152.TabStop = False
        Me.PictureBox152.Visible = False
        '
        'PictureBox151
        '
        Me.PictureBox151.Image = CType(resources.GetObject("PictureBox151.Image"), System.Drawing.Image)
        Me.PictureBox151.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox151.Name = "PictureBox151"
        Me.PictureBox151.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox151.TabIndex = 40
        Me.PictureBox151.TabStop = False
        Me.PictureBox151.Visible = False
        '
        'PictureBox148
        '
        Me.PictureBox148.Image = CType(resources.GetObject("PictureBox148.Image"), System.Drawing.Image)
        Me.PictureBox148.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox148.Name = "PictureBox148"
        Me.PictureBox148.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox148.TabIndex = 30
        Me.PictureBox148.TabStop = False
        '
        'PictureBox149
        '
        Me.PictureBox149.Image = CType(resources.GetObject("PictureBox149.Image"), System.Drawing.Image)
        Me.PictureBox149.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox149.Name = "PictureBox149"
        Me.PictureBox149.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox149.TabIndex = 29
        Me.PictureBox149.TabStop = False
        '
        'PictureBox147
        '
        Me.PictureBox147.Image = CType(resources.GetObject("PictureBox147.Image"), System.Drawing.Image)
        Me.PictureBox147.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox147.Name = "PictureBox147"
        Me.PictureBox147.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox147.TabIndex = 28
        Me.PictureBox147.TabStop = False
        '
        'PictureBox146
        '
        Me.PictureBox146.Image = CType(resources.GetObject("PictureBox146.Image"), System.Drawing.Image)
        Me.PictureBox146.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox146.Name = "PictureBox146"
        Me.PictureBox146.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox146.TabIndex = 27
        Me.PictureBox146.TabStop = False
        '
        'PictureBox145
        '
        Me.PictureBox145.Image = CType(resources.GetObject("PictureBox145.Image"), System.Drawing.Image)
        Me.PictureBox145.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox145.Name = "PictureBox145"
        Me.PictureBox145.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox145.TabIndex = 26
        Me.PictureBox145.TabStop = False
        '
        'PictureBox144
        '
        Me.PictureBox144.Image = CType(resources.GetObject("PictureBox144.Image"), System.Drawing.Image)
        Me.PictureBox144.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox144.Name = "PictureBox144"
        Me.PictureBox144.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox144.TabIndex = 25
        Me.PictureBox144.TabStop = False
        '
        'PictureBox142
        '
        Me.PictureBox142.Image = CType(resources.GetObject("PictureBox142.Image"), System.Drawing.Image)
        Me.PictureBox142.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox142.Name = "PictureBox142"
        Me.PictureBox142.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox142.TabIndex = 24
        Me.PictureBox142.TabStop = False
        '
        'PictureBox143
        '
        Me.PictureBox143.Image = CType(resources.GetObject("PictureBox143.Image"), System.Drawing.Image)
        Me.PictureBox143.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox143.Name = "PictureBox143"
        Me.PictureBox143.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox143.TabIndex = 23
        Me.PictureBox143.TabStop = False
        '
        'PictureBox141
        '
        Me.PictureBox141.Image = CType(resources.GetObject("PictureBox141.Image"), System.Drawing.Image)
        Me.PictureBox141.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox141.Name = "PictureBox141"
        Me.PictureBox141.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox141.TabIndex = 22
        Me.PictureBox141.TabStop = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.SAVE_IMG7)
        Me.GroupBox7.Controls.Add(Me.RESET7)
        Me.GroupBox7.Controls.Add(Me.PictureBox139)
        Me.GroupBox7.Controls.Add(Me.PictureBox138)
        Me.GroupBox7.Controls.Add(Me.PictureBox137)
        Me.GroupBox7.Controls.Add(Me.PictureBox136)
        Me.GroupBox7.Controls.Add(Me.PictureBox135)
        Me.GroupBox7.Controls.Add(Me.PictureBox134)
        Me.GroupBox7.Controls.Add(Me.PictureBox133)
        Me.GroupBox7.Controls.Add(Me.PictureBox132)
        Me.GroupBox7.Controls.Add(Me.PictureBox131)
        Me.GroupBox7.Controls.Add(Me.PictureBox128)
        Me.GroupBox7.Controls.Add(Me.PictureBox129)
        Me.GroupBox7.Controls.Add(Me.PictureBox127)
        Me.GroupBox7.Controls.Add(Me.PictureBox126)
        Me.GroupBox7.Controls.Add(Me.PictureBox125)
        Me.GroupBox7.Controls.Add(Me.PictureBox124)
        Me.GroupBox7.Controls.Add(Me.PictureBox122)
        Me.GroupBox7.Controls.Add(Me.PictureBox123)
        Me.GroupBox7.Controls.Add(Me.PictureBox121)
        Me.GroupBox7.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox7.Location = New System.Drawing.Point(297, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "21.알+번짐"
        '
        'SAVE_IMG7
        '
        Me.SAVE_IMG7.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG7.Name = "SAVE_IMG7"
        Me.SAVE_IMG7.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG7.TabIndex = 79
        Me.SAVE_IMG7.Text = "저 장"
        '
        'RESET7
        '
        Me.RESET7.Location = New System.Drawing.Point(12, 196)
        Me.RESET7.Name = "RESET7"
        Me.RESET7.Size = New System.Drawing.Size(49, 25)
        Me.RESET7.TabIndex = 78
        Me.RESET7.Text = "초기화"
        '
        'PictureBox139
        '
        Me.PictureBox139.Image = CType(resources.GetObject("PictureBox139.Image"), System.Drawing.Image)
        Me.PictureBox139.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox139.Name = "PictureBox139"
        Me.PictureBox139.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox139.TabIndex = 39
        Me.PictureBox139.TabStop = False
        Me.PictureBox139.Visible = False
        '
        'PictureBox138
        '
        Me.PictureBox138.Image = CType(resources.GetObject("PictureBox138.Image"), System.Drawing.Image)
        Me.PictureBox138.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox138.Name = "PictureBox138"
        Me.PictureBox138.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox138.TabIndex = 38
        Me.PictureBox138.TabStop = False
        Me.PictureBox138.Visible = False
        '
        'PictureBox137
        '
        Me.PictureBox137.Image = CType(resources.GetObject("PictureBox137.Image"), System.Drawing.Image)
        Me.PictureBox137.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox137.Name = "PictureBox137"
        Me.PictureBox137.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox137.TabIndex = 37
        Me.PictureBox137.TabStop = False
        Me.PictureBox137.Visible = False
        '
        'PictureBox136
        '
        Me.PictureBox136.Image = CType(resources.GetObject("PictureBox136.Image"), System.Drawing.Image)
        Me.PictureBox136.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox136.Name = "PictureBox136"
        Me.PictureBox136.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox136.TabIndex = 36
        Me.PictureBox136.TabStop = False
        Me.PictureBox136.Visible = False
        '
        'PictureBox135
        '
        Me.PictureBox135.Image = CType(resources.GetObject("PictureBox135.Image"), System.Drawing.Image)
        Me.PictureBox135.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox135.Name = "PictureBox135"
        Me.PictureBox135.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox135.TabIndex = 35
        Me.PictureBox135.TabStop = False
        Me.PictureBox135.Visible = False
        '
        'PictureBox134
        '
        Me.PictureBox134.Image = CType(resources.GetObject("PictureBox134.Image"), System.Drawing.Image)
        Me.PictureBox134.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox134.Name = "PictureBox134"
        Me.PictureBox134.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox134.TabIndex = 34
        Me.PictureBox134.TabStop = False
        Me.PictureBox134.Visible = False
        '
        'PictureBox133
        '
        Me.PictureBox133.Image = CType(resources.GetObject("PictureBox133.Image"), System.Drawing.Image)
        Me.PictureBox133.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox133.Name = "PictureBox133"
        Me.PictureBox133.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox133.TabIndex = 33
        Me.PictureBox133.TabStop = False
        Me.PictureBox133.Visible = False
        '
        'PictureBox132
        '
        Me.PictureBox132.Image = CType(resources.GetObject("PictureBox132.Image"), System.Drawing.Image)
        Me.PictureBox132.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox132.Name = "PictureBox132"
        Me.PictureBox132.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox132.TabIndex = 32
        Me.PictureBox132.TabStop = False
        Me.PictureBox132.Visible = False
        '
        'PictureBox131
        '
        Me.PictureBox131.Image = CType(resources.GetObject("PictureBox131.Image"), System.Drawing.Image)
        Me.PictureBox131.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox131.Name = "PictureBox131"
        Me.PictureBox131.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox131.TabIndex = 31
        Me.PictureBox131.TabStop = False
        Me.PictureBox131.Visible = False
        '
        'PictureBox128
        '
        Me.PictureBox128.Image = CType(resources.GetObject("PictureBox128.Image"), System.Drawing.Image)
        Me.PictureBox128.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox128.Name = "PictureBox128"
        Me.PictureBox128.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox128.TabIndex = 30
        Me.PictureBox128.TabStop = False
        '
        'PictureBox129
        '
        Me.PictureBox129.Image = CType(resources.GetObject("PictureBox129.Image"), System.Drawing.Image)
        Me.PictureBox129.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox129.Name = "PictureBox129"
        Me.PictureBox129.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox129.TabIndex = 29
        Me.PictureBox129.TabStop = False
        '
        'PictureBox127
        '
        Me.PictureBox127.Image = CType(resources.GetObject("PictureBox127.Image"), System.Drawing.Image)
        Me.PictureBox127.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox127.Name = "PictureBox127"
        Me.PictureBox127.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox127.TabIndex = 28
        Me.PictureBox127.TabStop = False
        '
        'PictureBox126
        '
        Me.PictureBox126.Image = CType(resources.GetObject("PictureBox126.Image"), System.Drawing.Image)
        Me.PictureBox126.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox126.Name = "PictureBox126"
        Me.PictureBox126.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox126.TabIndex = 27
        Me.PictureBox126.TabStop = False
        '
        'PictureBox125
        '
        Me.PictureBox125.Image = CType(resources.GetObject("PictureBox125.Image"), System.Drawing.Image)
        Me.PictureBox125.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox125.Name = "PictureBox125"
        Me.PictureBox125.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox125.TabIndex = 26
        Me.PictureBox125.TabStop = False
        '
        'PictureBox124
        '
        Me.PictureBox124.Image = CType(resources.GetObject("PictureBox124.Image"), System.Drawing.Image)
        Me.PictureBox124.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox124.Name = "PictureBox124"
        Me.PictureBox124.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox124.TabIndex = 25
        Me.PictureBox124.TabStop = False
        '
        'PictureBox122
        '
        Me.PictureBox122.Image = CType(resources.GetObject("PictureBox122.Image"), System.Drawing.Image)
        Me.PictureBox122.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox122.Name = "PictureBox122"
        Me.PictureBox122.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox122.TabIndex = 24
        Me.PictureBox122.TabStop = False
        '
        'PictureBox123
        '
        Me.PictureBox123.Image = CType(resources.GetObject("PictureBox123.Image"), System.Drawing.Image)
        Me.PictureBox123.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox123.Name = "PictureBox123"
        Me.PictureBox123.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox123.TabIndex = 23
        Me.PictureBox123.TabStop = False
        '
        'PictureBox121
        '
        Me.PictureBox121.Image = CType(resources.GetObject("PictureBox121.Image"), System.Drawing.Image)
        Me.PictureBox121.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox121.Name = "PictureBox121"
        Me.PictureBox121.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox121.TabIndex = 22
        Me.PictureBox121.TabStop = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.SAVE_IMG5)
        Me.GroupBox8.Controls.Add(Me.PictureBox92)
        Me.GroupBox8.Controls.Add(Me.PictureBox99)
        Me.GroupBox8.Controls.Add(Me.PictureBox98)
        Me.GroupBox8.Controls.Add(Me.PictureBox97)
        Me.GroupBox8.Controls.Add(Me.PictureBox96)
        Me.GroupBox8.Controls.Add(Me.PictureBox95)
        Me.GroupBox8.Controls.Add(Me.PictureBox94)
        Me.GroupBox8.Controls.Add(Me.RESET5)
        Me.GroupBox8.Controls.Add(Me.PictureBox93)
        Me.GroupBox8.Controls.Add(Me.PictureBox91)
        Me.GroupBox8.Controls.Add(Me.PictureBox89)
        Me.GroupBox8.Controls.Add(Me.PictureBox88)
        Me.GroupBox8.Controls.Add(Me.PictureBox87)
        Me.GroupBox8.Controls.Add(Me.PictureBox86)
        Me.GroupBox8.Controls.Add(Me.PictureBox85)
        Me.GroupBox8.Controls.Add(Me.PictureBox84)
        Me.GroupBox8.Controls.Add(Me.PictureBox82)
        Me.GroupBox8.Controls.Add(Me.PictureBox83)
        Me.GroupBox8.Controls.Add(Me.PictureBox81)
        Me.GroupBox8.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox8.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox8.TabIndex = 5
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "19.알떨어짐"
        '
        'SAVE_IMG5
        '
        Me.SAVE_IMG5.Location = New System.Drawing.Point(88, 196)
        Me.SAVE_IMG5.Name = "SAVE_IMG5"
        Me.SAVE_IMG5.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG5.TabIndex = 75
        Me.SAVE_IMG5.Text = "저 장"
        '
        'PictureBox92
        '
        Me.PictureBox92.Image = CType(resources.GetObject("PictureBox92.Image"), System.Drawing.Image)
        Me.PictureBox92.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox92.Name = "PictureBox92"
        Me.PictureBox92.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox92.TabIndex = 11
        Me.PictureBox92.TabStop = False
        Me.PictureBox92.Visible = False
        '
        'PictureBox99
        '
        Me.PictureBox99.Image = CType(resources.GetObject("PictureBox99.Image"), System.Drawing.Image)
        Me.PictureBox99.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox99.TabIndex = 16
        Me.PictureBox99.TabStop = False
        Me.PictureBox99.Visible = False
        '
        'PictureBox98
        '
        Me.PictureBox98.Image = CType(resources.GetObject("PictureBox98.Image"), System.Drawing.Image)
        Me.PictureBox98.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox98.Name = "PictureBox98"
        Me.PictureBox98.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox98.TabIndex = 15
        Me.PictureBox98.TabStop = False
        Me.PictureBox98.Visible = False
        '
        'PictureBox97
        '
        Me.PictureBox97.Image = CType(resources.GetObject("PictureBox97.Image"), System.Drawing.Image)
        Me.PictureBox97.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox97.Name = "PictureBox97"
        Me.PictureBox97.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox97.TabIndex = 14
        Me.PictureBox97.TabStop = False
        Me.PictureBox97.Visible = False
        '
        'PictureBox96
        '
        Me.PictureBox96.Image = CType(resources.GetObject("PictureBox96.Image"), System.Drawing.Image)
        Me.PictureBox96.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox96.TabIndex = 13
        Me.PictureBox96.TabStop = False
        Me.PictureBox96.Visible = False
        '
        'PictureBox95
        '
        Me.PictureBox95.Image = CType(resources.GetObject("PictureBox95.Image"), System.Drawing.Image)
        Me.PictureBox95.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox95.Name = "PictureBox95"
        Me.PictureBox95.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox95.TabIndex = 12
        Me.PictureBox95.TabStop = False
        Me.PictureBox95.Visible = False
        '
        'PictureBox94
        '
        Me.PictureBox94.Image = CType(resources.GetObject("PictureBox94.Image"), System.Drawing.Image)
        Me.PictureBox94.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox94.TabIndex = 11
        Me.PictureBox94.TabStop = False
        Me.PictureBox94.Visible = False
        '
        'RESET5
        '
        Me.RESET5.Location = New System.Drawing.Point(13, 196)
        Me.RESET5.Name = "RESET5"
        Me.RESET5.Size = New System.Drawing.Size(49, 25)
        Me.RESET5.TabIndex = 74
        Me.RESET5.Text = "초기화"
        '
        'PictureBox93
        '
        Me.PictureBox93.Image = CType(resources.GetObject("PictureBox93.Image"), System.Drawing.Image)
        Me.PictureBox93.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox93.Name = "PictureBox93"
        Me.PictureBox93.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox93.TabIndex = 12
        Me.PictureBox93.TabStop = False
        Me.PictureBox93.Visible = False
        '
        'PictureBox91
        '
        Me.PictureBox91.Image = CType(resources.GetObject("PictureBox91.Image"), System.Drawing.Image)
        Me.PictureBox91.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox91.Name = "PictureBox91"
        Me.PictureBox91.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox91.TabIndex = 10
        Me.PictureBox91.TabStop = False
        Me.PictureBox91.Visible = False
        '
        'PictureBox89
        '
        Me.PictureBox89.Image = CType(resources.GetObject("PictureBox89.Image"), System.Drawing.Image)
        Me.PictureBox89.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox89.Name = "PictureBox89"
        Me.PictureBox89.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox89.TabIndex = 9
        Me.PictureBox89.TabStop = False
        '
        'PictureBox88
        '
        Me.PictureBox88.Image = CType(resources.GetObject("PictureBox88.Image"), System.Drawing.Image)
        Me.PictureBox88.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox88.Name = "PictureBox88"
        Me.PictureBox88.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox88.TabIndex = 8
        Me.PictureBox88.TabStop = False
        '
        'PictureBox87
        '
        Me.PictureBox87.Image = CType(resources.GetObject("PictureBox87.Image"), System.Drawing.Image)
        Me.PictureBox87.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox87.Name = "PictureBox87"
        Me.PictureBox87.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox87.TabIndex = 7
        Me.PictureBox87.TabStop = False
        '
        'PictureBox86
        '
        Me.PictureBox86.Image = CType(resources.GetObject("PictureBox86.Image"), System.Drawing.Image)
        Me.PictureBox86.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox86.Name = "PictureBox86"
        Me.PictureBox86.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox86.TabIndex = 6
        Me.PictureBox86.TabStop = False
        '
        'PictureBox85
        '
        Me.PictureBox85.Image = CType(resources.GetObject("PictureBox85.Image"), System.Drawing.Image)
        Me.PictureBox85.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox85.Name = "PictureBox85"
        Me.PictureBox85.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox85.TabIndex = 5
        Me.PictureBox85.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.Image = CType(resources.GetObject("PictureBox84.Image"), System.Drawing.Image)
        Me.PictureBox84.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox84.TabIndex = 4
        Me.PictureBox84.TabStop = False
        '
        'PictureBox82
        '
        Me.PictureBox82.Image = CType(resources.GetObject("PictureBox82.Image"), System.Drawing.Image)
        Me.PictureBox82.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox82.Name = "PictureBox82"
        Me.PictureBox82.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox82.TabIndex = 3
        Me.PictureBox82.TabStop = False
        '
        'PictureBox83
        '
        Me.PictureBox83.Image = CType(resources.GetObject("PictureBox83.Image"), System.Drawing.Image)
        Me.PictureBox83.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox83.Name = "PictureBox83"
        Me.PictureBox83.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox83.TabIndex = 2
        Me.PictureBox83.TabStop = False
        '
        'PictureBox81
        '
        Me.PictureBox81.Image = CType(resources.GetObject("PictureBox81.Image"), System.Drawing.Image)
        Me.PictureBox81.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox81.Name = "PictureBox81"
        Me.PictureBox81.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox81.TabIndex = 0
        Me.PictureBox81.TabStop = False
        '
        'XtraTabPage12
        '
        Me.XtraTabPage12.Controls.Add(Me.GroupBox9)
        Me.XtraTabPage12.Controls.Add(Me.GroupBox10)
        Me.XtraTabPage12.Controls.Add(Me.GroupBox11)
        Me.XtraTabPage12.Controls.Add(Me.GroupBox12)
        Me.XtraTabPage12.Name = "XtraTabPage12"
        Me.XtraTabPage12.Size = New System.Drawing.Size(594, 247)
        Me.XtraTabPage12.Text = "3도"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.SAVE_IMG10)
        Me.GroupBox9.Controls.Add(Me.RESET10)
        Me.GroupBox9.Controls.Add(Me.PictureBox199)
        Me.GroupBox9.Controls.Add(Me.PictureBox192)
        Me.GroupBox9.Controls.Add(Me.PictureBox189)
        Me.GroupBox9.Controls.Add(Me.PictureBox191)
        Me.GroupBox9.Controls.Add(Me.PictureBox198)
        Me.GroupBox9.Controls.Add(Me.PictureBox194)
        Me.GroupBox9.Controls.Add(Me.PictureBox193)
        Me.GroupBox9.Controls.Add(Me.PictureBox197)
        Me.GroupBox9.Controls.Add(Me.PictureBox182)
        Me.GroupBox9.Controls.Add(Me.PictureBox196)
        Me.GroupBox9.Controls.Add(Me.PictureBox183)
        Me.GroupBox9.Controls.Add(Me.PictureBox195)
        Me.GroupBox9.Controls.Add(Me.PictureBox181)
        Me.GroupBox9.Controls.Add(Me.PictureBox184)
        Me.GroupBox9.Controls.Add(Me.PictureBox185)
        Me.GroupBox9.Controls.Add(Me.PictureBox186)
        Me.GroupBox9.Controls.Add(Me.PictureBox187)
        Me.GroupBox9.Controls.Add(Me.PictureBox188)
        Me.GroupBox9.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox9.Location = New System.Drawing.Point(152, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox9.TabIndex = 10
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "20.색상번짐"
        '
        'SAVE_IMG10
        '
        Me.SAVE_IMG10.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG10.Name = "SAVE_IMG10"
        Me.SAVE_IMG10.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG10.TabIndex = 78
        Me.SAVE_IMG10.Text = "저 장"
        '
        'RESET10
        '
        Me.RESET10.Location = New System.Drawing.Point(12, 196)
        Me.RESET10.Name = "RESET10"
        Me.RESET10.Size = New System.Drawing.Size(49, 25)
        Me.RESET10.TabIndex = 77
        Me.RESET10.Text = "초기화"
        '
        'PictureBox199
        '
        Me.PictureBox199.Image = CType(resources.GetObject("PictureBox199.Image"), System.Drawing.Image)
        Me.PictureBox199.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox199.Name = "PictureBox199"
        Me.PictureBox199.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox199.TabIndex = 76
        Me.PictureBox199.TabStop = False
        Me.PictureBox199.Visible = False
        '
        'PictureBox192
        '
        Me.PictureBox192.Image = CType(resources.GetObject("PictureBox192.Image"), System.Drawing.Image)
        Me.PictureBox192.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox192.Name = "PictureBox192"
        Me.PictureBox192.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox192.TabIndex = 18
        Me.PictureBox192.TabStop = False
        Me.PictureBox192.Visible = False
        '
        'PictureBox189
        '
        Me.PictureBox189.Image = CType(resources.GetObject("PictureBox189.Image"), System.Drawing.Image)
        Me.PictureBox189.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox189.Name = "PictureBox189"
        Me.PictureBox189.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox189.TabIndex = 20
        Me.PictureBox189.TabStop = False
        '
        'PictureBox191
        '
        Me.PictureBox191.Image = CType(resources.GetObject("PictureBox191.Image"), System.Drawing.Image)
        Me.PictureBox191.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox191.Name = "PictureBox191"
        Me.PictureBox191.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox191.TabIndex = 17
        Me.PictureBox191.TabStop = False
        Me.PictureBox191.Visible = False
        '
        'PictureBox198
        '
        Me.PictureBox198.Image = CType(resources.GetObject("PictureBox198.Image"), System.Drawing.Image)
        Me.PictureBox198.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox198.Name = "PictureBox198"
        Me.PictureBox198.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox198.TabIndex = 24
        Me.PictureBox198.TabStop = False
        Me.PictureBox198.Visible = False
        '
        'PictureBox194
        '
        Me.PictureBox194.Image = CType(resources.GetObject("PictureBox194.Image"), System.Drawing.Image)
        Me.PictureBox194.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox194.Name = "PictureBox194"
        Me.PictureBox194.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox194.TabIndex = 19
        Me.PictureBox194.TabStop = False
        Me.PictureBox194.Visible = False
        '
        'PictureBox193
        '
        Me.PictureBox193.Image = CType(resources.GetObject("PictureBox193.Image"), System.Drawing.Image)
        Me.PictureBox193.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox193.Name = "PictureBox193"
        Me.PictureBox193.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox193.TabIndex = 20
        Me.PictureBox193.TabStop = False
        Me.PictureBox193.Visible = False
        '
        'PictureBox197
        '
        Me.PictureBox197.Image = CType(resources.GetObject("PictureBox197.Image"), System.Drawing.Image)
        Me.PictureBox197.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox197.Name = "PictureBox197"
        Me.PictureBox197.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox197.TabIndex = 23
        Me.PictureBox197.TabStop = False
        Me.PictureBox197.Visible = False
        '
        'PictureBox182
        '
        Me.PictureBox182.Image = CType(resources.GetObject("PictureBox182.Image"), System.Drawing.Image)
        Me.PictureBox182.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox182.Name = "PictureBox182"
        Me.PictureBox182.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox182.TabIndex = 15
        Me.PictureBox182.TabStop = False
        '
        'PictureBox196
        '
        Me.PictureBox196.Image = CType(resources.GetObject("PictureBox196.Image"), System.Drawing.Image)
        Me.PictureBox196.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox196.Name = "PictureBox196"
        Me.PictureBox196.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox196.TabIndex = 22
        Me.PictureBox196.TabStop = False
        Me.PictureBox196.Visible = False
        '
        'PictureBox183
        '
        Me.PictureBox183.Image = CType(resources.GetObject("PictureBox183.Image"), System.Drawing.Image)
        Me.PictureBox183.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox183.Name = "PictureBox183"
        Me.PictureBox183.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox183.TabIndex = 14
        Me.PictureBox183.TabStop = False
        '
        'PictureBox195
        '
        Me.PictureBox195.Image = CType(resources.GetObject("PictureBox195.Image"), System.Drawing.Image)
        Me.PictureBox195.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox195.Name = "PictureBox195"
        Me.PictureBox195.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox195.TabIndex = 21
        Me.PictureBox195.TabStop = False
        Me.PictureBox195.Visible = False
        '
        'PictureBox181
        '
        Me.PictureBox181.Image = CType(resources.GetObject("PictureBox181.Image"), System.Drawing.Image)
        Me.PictureBox181.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox181.Name = "PictureBox181"
        Me.PictureBox181.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox181.TabIndex = 13
        Me.PictureBox181.TabStop = False
        '
        'PictureBox184
        '
        Me.PictureBox184.Image = CType(resources.GetObject("PictureBox184.Image"), System.Drawing.Image)
        Me.PictureBox184.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox184.Name = "PictureBox184"
        Me.PictureBox184.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox184.TabIndex = 16
        Me.PictureBox184.TabStop = False
        '
        'PictureBox185
        '
        Me.PictureBox185.Image = CType(resources.GetObject("PictureBox185.Image"), System.Drawing.Image)
        Me.PictureBox185.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox185.Name = "PictureBox185"
        Me.PictureBox185.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox185.TabIndex = 17
        Me.PictureBox185.TabStop = False
        '
        'PictureBox186
        '
        Me.PictureBox186.Image = CType(resources.GetObject("PictureBox186.Image"), System.Drawing.Image)
        Me.PictureBox186.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox186.Name = "PictureBox186"
        Me.PictureBox186.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox186.TabIndex = 18
        Me.PictureBox186.TabStop = False
        '
        'PictureBox187
        '
        Me.PictureBox187.Image = CType(resources.GetObject("PictureBox187.Image"), System.Drawing.Image)
        Me.PictureBox187.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox187.Name = "PictureBox187"
        Me.PictureBox187.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox187.TabIndex = 19
        Me.PictureBox187.TabStop = False
        '
        'PictureBox188
        '
        Me.PictureBox188.Image = CType(resources.GetObject("PictureBox188.Image"), System.Drawing.Image)
        Me.PictureBox188.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox188.Name = "PictureBox188"
        Me.PictureBox188.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox188.TabIndex = 21
        Me.PictureBox188.TabStop = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.SAVE_IMG12)
        Me.GroupBox10.Controls.Add(Me.RESET12)
        Me.GroupBox10.Controls.Add(Me.PictureBox239)
        Me.GroupBox10.Controls.Add(Me.PictureBox238)
        Me.GroupBox10.Controls.Add(Me.PictureBox237)
        Me.GroupBox10.Controls.Add(Me.PictureBox236)
        Me.GroupBox10.Controls.Add(Me.PictureBox235)
        Me.GroupBox10.Controls.Add(Me.PictureBox234)
        Me.GroupBox10.Controls.Add(Me.PictureBox233)
        Me.GroupBox10.Controls.Add(Me.PictureBox232)
        Me.GroupBox10.Controls.Add(Me.PictureBox231)
        Me.GroupBox10.Controls.Add(Me.PictureBox228)
        Me.GroupBox10.Controls.Add(Me.PictureBox229)
        Me.GroupBox10.Controls.Add(Me.PictureBox227)
        Me.GroupBox10.Controls.Add(Me.PictureBox226)
        Me.GroupBox10.Controls.Add(Me.PictureBox225)
        Me.GroupBox10.Controls.Add(Me.PictureBox224)
        Me.GroupBox10.Controls.Add(Me.PictureBox222)
        Me.GroupBox10.Controls.Add(Me.PictureBox223)
        Me.GroupBox10.Controls.Add(Me.PictureBox221)
        Me.GroupBox10.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox10.Location = New System.Drawing.Point(442, 6)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox10.TabIndex = 12
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "28.인쇄불량"
        '
        'SAVE_IMG12
        '
        Me.SAVE_IMG12.Location = New System.Drawing.Point(83, 196)
        Me.SAVE_IMG12.Name = "SAVE_IMG12"
        Me.SAVE_IMG12.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG12.TabIndex = 80
        Me.SAVE_IMG12.Text = "저 장"
        '
        'RESET12
        '
        Me.RESET12.Location = New System.Drawing.Point(13, 196)
        Me.RESET12.Name = "RESET12"
        Me.RESET12.Size = New System.Drawing.Size(49, 25)
        Me.RESET12.TabIndex = 79
        Me.RESET12.Text = "초기화"
        '
        'PictureBox239
        '
        Me.PictureBox239.Image = CType(resources.GetObject("PictureBox239.Image"), System.Drawing.Image)
        Me.PictureBox239.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox239.Name = "PictureBox239"
        Me.PictureBox239.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox239.TabIndex = 48
        Me.PictureBox239.TabStop = False
        Me.PictureBox239.Visible = False
        '
        'PictureBox238
        '
        Me.PictureBox238.Image = CType(resources.GetObject("PictureBox238.Image"), System.Drawing.Image)
        Me.PictureBox238.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox238.Name = "PictureBox238"
        Me.PictureBox238.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox238.TabIndex = 47
        Me.PictureBox238.TabStop = False
        Me.PictureBox238.Visible = False
        '
        'PictureBox237
        '
        Me.PictureBox237.Image = CType(resources.GetObject("PictureBox237.Image"), System.Drawing.Image)
        Me.PictureBox237.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox237.Name = "PictureBox237"
        Me.PictureBox237.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox237.TabIndex = 46
        Me.PictureBox237.TabStop = False
        Me.PictureBox237.Visible = False
        '
        'PictureBox236
        '
        Me.PictureBox236.Image = CType(resources.GetObject("PictureBox236.Image"), System.Drawing.Image)
        Me.PictureBox236.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox236.Name = "PictureBox236"
        Me.PictureBox236.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox236.TabIndex = 45
        Me.PictureBox236.TabStop = False
        Me.PictureBox236.Visible = False
        '
        'PictureBox235
        '
        Me.PictureBox235.Image = CType(resources.GetObject("PictureBox235.Image"), System.Drawing.Image)
        Me.PictureBox235.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox235.Name = "PictureBox235"
        Me.PictureBox235.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox235.TabIndex = 44
        Me.PictureBox235.TabStop = False
        Me.PictureBox235.Visible = False
        '
        'PictureBox234
        '
        Me.PictureBox234.Image = CType(resources.GetObject("PictureBox234.Image"), System.Drawing.Image)
        Me.PictureBox234.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox234.Name = "PictureBox234"
        Me.PictureBox234.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox234.TabIndex = 43
        Me.PictureBox234.TabStop = False
        Me.PictureBox234.Visible = False
        '
        'PictureBox233
        '
        Me.PictureBox233.Image = CType(resources.GetObject("PictureBox233.Image"), System.Drawing.Image)
        Me.PictureBox233.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox233.Name = "PictureBox233"
        Me.PictureBox233.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox233.TabIndex = 42
        Me.PictureBox233.TabStop = False
        Me.PictureBox233.Visible = False
        '
        'PictureBox232
        '
        Me.PictureBox232.Image = CType(resources.GetObject("PictureBox232.Image"), System.Drawing.Image)
        Me.PictureBox232.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox232.Name = "PictureBox232"
        Me.PictureBox232.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox232.TabIndex = 41
        Me.PictureBox232.TabStop = False
        Me.PictureBox232.Visible = False
        '
        'PictureBox231
        '
        Me.PictureBox231.Image = CType(resources.GetObject("PictureBox231.Image"), System.Drawing.Image)
        Me.PictureBox231.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox231.Name = "PictureBox231"
        Me.PictureBox231.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox231.TabIndex = 40
        Me.PictureBox231.TabStop = False
        Me.PictureBox231.Visible = False
        '
        'PictureBox228
        '
        Me.PictureBox228.Image = CType(resources.GetObject("PictureBox228.Image"), System.Drawing.Image)
        Me.PictureBox228.Location = New System.Drawing.Point(52, 137)
        Me.PictureBox228.Name = "PictureBox228"
        Me.PictureBox228.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox228.TabIndex = 30
        Me.PictureBox228.TabStop = False
        '
        'PictureBox229
        '
        Me.PictureBox229.Image = CType(resources.GetObject("PictureBox229.Image"), System.Drawing.Image)
        Me.PictureBox229.Location = New System.Drawing.Point(92, 137)
        Me.PictureBox229.Name = "PictureBox229"
        Me.PictureBox229.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox229.TabIndex = 29
        Me.PictureBox229.TabStop = False
        '
        'PictureBox227
        '
        Me.PictureBox227.Image = CType(resources.GetObject("PictureBox227.Image"), System.Drawing.Image)
        Me.PictureBox227.Location = New System.Drawing.Point(12, 137)
        Me.PictureBox227.Name = "PictureBox227"
        Me.PictureBox227.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox227.TabIndex = 28
        Me.PictureBox227.TabStop = False
        '
        'PictureBox226
        '
        Me.PictureBox226.Image = CType(resources.GetObject("PictureBox226.Image"), System.Drawing.Image)
        Me.PictureBox226.Location = New System.Drawing.Point(92, 94)
        Me.PictureBox226.Name = "PictureBox226"
        Me.PictureBox226.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox226.TabIndex = 27
        Me.PictureBox226.TabStop = False
        '
        'PictureBox225
        '
        Me.PictureBox225.Image = CType(resources.GetObject("PictureBox225.Image"), System.Drawing.Image)
        Me.PictureBox225.Location = New System.Drawing.Point(52, 94)
        Me.PictureBox225.Name = "PictureBox225"
        Me.PictureBox225.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox225.TabIndex = 26
        Me.PictureBox225.TabStop = False
        '
        'PictureBox224
        '
        Me.PictureBox224.Image = CType(resources.GetObject("PictureBox224.Image"), System.Drawing.Image)
        Me.PictureBox224.Location = New System.Drawing.Point(12, 94)
        Me.PictureBox224.Name = "PictureBox224"
        Me.PictureBox224.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox224.TabIndex = 25
        Me.PictureBox224.TabStop = False
        '
        'PictureBox222
        '
        Me.PictureBox222.Image = CType(resources.GetObject("PictureBox222.Image"), System.Drawing.Image)
        Me.PictureBox222.Location = New System.Drawing.Point(52, 51)
        Me.PictureBox222.Name = "PictureBox222"
        Me.PictureBox222.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox222.TabIndex = 24
        Me.PictureBox222.TabStop = False
        '
        'PictureBox223
        '
        Me.PictureBox223.Image = CType(resources.GetObject("PictureBox223.Image"), System.Drawing.Image)
        Me.PictureBox223.Location = New System.Drawing.Point(92, 51)
        Me.PictureBox223.Name = "PictureBox223"
        Me.PictureBox223.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox223.TabIndex = 23
        Me.PictureBox223.TabStop = False
        '
        'PictureBox221
        '
        Me.PictureBox221.Image = CType(resources.GetObject("PictureBox221.Image"), System.Drawing.Image)
        Me.PictureBox221.Location = New System.Drawing.Point(12, 51)
        Me.PictureBox221.Name = "PictureBox221"
        Me.PictureBox221.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox221.TabIndex = 22
        Me.PictureBox221.TabStop = False
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.SAVE_IMG11)
        Me.GroupBox11.Controls.Add(Me.RESET11)
        Me.GroupBox11.Controls.Add(Me.PictureBox219)
        Me.GroupBox11.Controls.Add(Me.PictureBox218)
        Me.GroupBox11.Controls.Add(Me.PictureBox217)
        Me.GroupBox11.Controls.Add(Me.PictureBox216)
        Me.GroupBox11.Controls.Add(Me.PictureBox215)
        Me.GroupBox11.Controls.Add(Me.PictureBox214)
        Me.GroupBox11.Controls.Add(Me.PictureBox213)
        Me.GroupBox11.Controls.Add(Me.PictureBox212)
        Me.GroupBox11.Controls.Add(Me.PictureBox211)
        Me.GroupBox11.Controls.Add(Me.PictureBox208)
        Me.GroupBox11.Controls.Add(Me.PictureBox209)
        Me.GroupBox11.Controls.Add(Me.PictureBox207)
        Me.GroupBox11.Controls.Add(Me.PictureBox206)
        Me.GroupBox11.Controls.Add(Me.PictureBox205)
        Me.GroupBox11.Controls.Add(Me.PictureBox204)
        Me.GroupBox11.Controls.Add(Me.PictureBox202)
        Me.GroupBox11.Controls.Add(Me.PictureBox203)
        Me.GroupBox11.Controls.Add(Me.PictureBox201)
        Me.GroupBox11.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox11.Location = New System.Drawing.Point(297, 6)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox11.TabIndex = 11
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "21.알+번짐"
        '
        'SAVE_IMG11
        '
        Me.SAVE_IMG11.Location = New System.Drawing.Point(82, 196)
        Me.SAVE_IMG11.Name = "SAVE_IMG11"
        Me.SAVE_IMG11.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG11.TabIndex = 79
        Me.SAVE_IMG11.Text = "저 장"
        '
        'RESET11
        '
        Me.RESET11.Location = New System.Drawing.Point(12, 196)
        Me.RESET11.Name = "RESET11"
        Me.RESET11.Size = New System.Drawing.Size(49, 25)
        Me.RESET11.TabIndex = 78
        Me.RESET11.Text = "초기화"
        '
        'PictureBox219
        '
        Me.PictureBox219.Image = CType(resources.GetObject("PictureBox219.Image"), System.Drawing.Image)
        Me.PictureBox219.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox219.Name = "PictureBox219"
        Me.PictureBox219.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox219.TabIndex = 39
        Me.PictureBox219.TabStop = False
        Me.PictureBox219.Visible = False
        '
        'PictureBox218
        '
        Me.PictureBox218.Image = CType(resources.GetObject("PictureBox218.Image"), System.Drawing.Image)
        Me.PictureBox218.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox218.Name = "PictureBox218"
        Me.PictureBox218.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox218.TabIndex = 38
        Me.PictureBox218.TabStop = False
        Me.PictureBox218.Visible = False
        '
        'PictureBox217
        '
        Me.PictureBox217.Image = CType(resources.GetObject("PictureBox217.Image"), System.Drawing.Image)
        Me.PictureBox217.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox217.Name = "PictureBox217"
        Me.PictureBox217.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox217.TabIndex = 37
        Me.PictureBox217.TabStop = False
        Me.PictureBox217.Visible = False
        '
        'PictureBox216
        '
        Me.PictureBox216.Image = CType(resources.GetObject("PictureBox216.Image"), System.Drawing.Image)
        Me.PictureBox216.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox216.Name = "PictureBox216"
        Me.PictureBox216.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox216.TabIndex = 36
        Me.PictureBox216.TabStop = False
        Me.PictureBox216.Visible = False
        '
        'PictureBox215
        '
        Me.PictureBox215.Image = CType(resources.GetObject("PictureBox215.Image"), System.Drawing.Image)
        Me.PictureBox215.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox215.Name = "PictureBox215"
        Me.PictureBox215.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox215.TabIndex = 35
        Me.PictureBox215.TabStop = False
        Me.PictureBox215.Visible = False
        '
        'PictureBox214
        '
        Me.PictureBox214.Image = CType(resources.GetObject("PictureBox214.Image"), System.Drawing.Image)
        Me.PictureBox214.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox214.Name = "PictureBox214"
        Me.PictureBox214.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox214.TabIndex = 34
        Me.PictureBox214.TabStop = False
        Me.PictureBox214.Visible = False
        '
        'PictureBox213
        '
        Me.PictureBox213.Image = CType(resources.GetObject("PictureBox213.Image"), System.Drawing.Image)
        Me.PictureBox213.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox213.Name = "PictureBox213"
        Me.PictureBox213.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox213.TabIndex = 33
        Me.PictureBox213.TabStop = False
        Me.PictureBox213.Visible = False
        '
        'PictureBox212
        '
        Me.PictureBox212.Image = CType(resources.GetObject("PictureBox212.Image"), System.Drawing.Image)
        Me.PictureBox212.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox212.Name = "PictureBox212"
        Me.PictureBox212.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox212.TabIndex = 32
        Me.PictureBox212.TabStop = False
        Me.PictureBox212.Visible = False
        '
        'PictureBox211
        '
        Me.PictureBox211.Image = CType(resources.GetObject("PictureBox211.Image"), System.Drawing.Image)
        Me.PictureBox211.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox211.Name = "PictureBox211"
        Me.PictureBox211.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox211.TabIndex = 31
        Me.PictureBox211.TabStop = False
        Me.PictureBox211.Visible = False
        '
        'PictureBox208
        '
        Me.PictureBox208.Image = CType(resources.GetObject("PictureBox208.Image"), System.Drawing.Image)
        Me.PictureBox208.Location = New System.Drawing.Point(51, 137)
        Me.PictureBox208.Name = "PictureBox208"
        Me.PictureBox208.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox208.TabIndex = 30
        Me.PictureBox208.TabStop = False
        '
        'PictureBox209
        '
        Me.PictureBox209.Image = CType(resources.GetObject("PictureBox209.Image"), System.Drawing.Image)
        Me.PictureBox209.Location = New System.Drawing.Point(91, 137)
        Me.PictureBox209.Name = "PictureBox209"
        Me.PictureBox209.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox209.TabIndex = 29
        Me.PictureBox209.TabStop = False
        '
        'PictureBox207
        '
        Me.PictureBox207.Image = CType(resources.GetObject("PictureBox207.Image"), System.Drawing.Image)
        Me.PictureBox207.Location = New System.Drawing.Point(11, 137)
        Me.PictureBox207.Name = "PictureBox207"
        Me.PictureBox207.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox207.TabIndex = 28
        Me.PictureBox207.TabStop = False
        '
        'PictureBox206
        '
        Me.PictureBox206.Image = CType(resources.GetObject("PictureBox206.Image"), System.Drawing.Image)
        Me.PictureBox206.Location = New System.Drawing.Point(91, 94)
        Me.PictureBox206.Name = "PictureBox206"
        Me.PictureBox206.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox206.TabIndex = 27
        Me.PictureBox206.TabStop = False
        '
        'PictureBox205
        '
        Me.PictureBox205.Image = CType(resources.GetObject("PictureBox205.Image"), System.Drawing.Image)
        Me.PictureBox205.Location = New System.Drawing.Point(51, 94)
        Me.PictureBox205.Name = "PictureBox205"
        Me.PictureBox205.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox205.TabIndex = 26
        Me.PictureBox205.TabStop = False
        '
        'PictureBox204
        '
        Me.PictureBox204.Image = CType(resources.GetObject("PictureBox204.Image"), System.Drawing.Image)
        Me.PictureBox204.Location = New System.Drawing.Point(11, 94)
        Me.PictureBox204.Name = "PictureBox204"
        Me.PictureBox204.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox204.TabIndex = 25
        Me.PictureBox204.TabStop = False
        '
        'PictureBox202
        '
        Me.PictureBox202.Image = CType(resources.GetObject("PictureBox202.Image"), System.Drawing.Image)
        Me.PictureBox202.Location = New System.Drawing.Point(51, 51)
        Me.PictureBox202.Name = "PictureBox202"
        Me.PictureBox202.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox202.TabIndex = 24
        Me.PictureBox202.TabStop = False
        '
        'PictureBox203
        '
        Me.PictureBox203.Image = CType(resources.GetObject("PictureBox203.Image"), System.Drawing.Image)
        Me.PictureBox203.Location = New System.Drawing.Point(91, 51)
        Me.PictureBox203.Name = "PictureBox203"
        Me.PictureBox203.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox203.TabIndex = 23
        Me.PictureBox203.TabStop = False
        '
        'PictureBox201
        '
        Me.PictureBox201.Image = CType(resources.GetObject("PictureBox201.Image"), System.Drawing.Image)
        Me.PictureBox201.Location = New System.Drawing.Point(11, 51)
        Me.PictureBox201.Name = "PictureBox201"
        Me.PictureBox201.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox201.TabIndex = 22
        Me.PictureBox201.TabStop = False
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.SAVE_IMG9)
        Me.GroupBox12.Controls.Add(Me.PictureBox172)
        Me.GroupBox12.Controls.Add(Me.PictureBox179)
        Me.GroupBox12.Controls.Add(Me.PictureBox178)
        Me.GroupBox12.Controls.Add(Me.PictureBox177)
        Me.GroupBox12.Controls.Add(Me.PictureBox176)
        Me.GroupBox12.Controls.Add(Me.PictureBox175)
        Me.GroupBox12.Controls.Add(Me.PictureBox174)
        Me.GroupBox12.Controls.Add(Me.RESET9)
        Me.GroupBox12.Controls.Add(Me.PictureBox173)
        Me.GroupBox12.Controls.Add(Me.PictureBox171)
        Me.GroupBox12.Controls.Add(Me.PictureBox169)
        Me.GroupBox12.Controls.Add(Me.PictureBox168)
        Me.GroupBox12.Controls.Add(Me.PictureBox167)
        Me.GroupBox12.Controls.Add(Me.PictureBox166)
        Me.GroupBox12.Controls.Add(Me.PictureBox165)
        Me.GroupBox12.Controls.Add(Me.PictureBox164)
        Me.GroupBox12.Controls.Add(Me.PictureBox162)
        Me.GroupBox12.Controls.Add(Me.PictureBox163)
        Me.GroupBox12.Controls.Add(Me.PictureBox161)
        Me.GroupBox12.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.GroupBox12.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(143, 238)
        Me.GroupBox12.TabIndex = 9
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "19.알떨어짐"
        '
        'SAVE_IMG9
        '
        Me.SAVE_IMG9.Location = New System.Drawing.Point(88, 196)
        Me.SAVE_IMG9.Name = "SAVE_IMG9"
        Me.SAVE_IMG9.Size = New System.Drawing.Size(49, 25)
        Me.SAVE_IMG9.TabIndex = 75
        Me.SAVE_IMG9.Text = "저 장"
        '
        'PictureBox172
        '
        Me.PictureBox172.Image = CType(resources.GetObject("PictureBox172.Image"), System.Drawing.Image)
        Me.PictureBox172.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox172.Name = "PictureBox172"
        Me.PictureBox172.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox172.TabIndex = 11
        Me.PictureBox172.TabStop = False
        Me.PictureBox172.Visible = False
        '
        'PictureBox179
        '
        Me.PictureBox179.Image = CType(resources.GetObject("PictureBox179.Image"), System.Drawing.Image)
        Me.PictureBox179.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox179.Name = "PictureBox179"
        Me.PictureBox179.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox179.TabIndex = 16
        Me.PictureBox179.TabStop = False
        Me.PictureBox179.Visible = False
        '
        'PictureBox178
        '
        Me.PictureBox178.Image = CType(resources.GetObject("PictureBox178.Image"), System.Drawing.Image)
        Me.PictureBox178.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox178.Name = "PictureBox178"
        Me.PictureBox178.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox178.TabIndex = 15
        Me.PictureBox178.TabStop = False
        Me.PictureBox178.Visible = False
        '
        'PictureBox177
        '
        Me.PictureBox177.Image = CType(resources.GetObject("PictureBox177.Image"), System.Drawing.Image)
        Me.PictureBox177.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox177.Name = "PictureBox177"
        Me.PictureBox177.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox177.TabIndex = 14
        Me.PictureBox177.TabStop = False
        Me.PictureBox177.Visible = False
        '
        'PictureBox176
        '
        Me.PictureBox176.Image = CType(resources.GetObject("PictureBox176.Image"), System.Drawing.Image)
        Me.PictureBox176.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox176.Name = "PictureBox176"
        Me.PictureBox176.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox176.TabIndex = 13
        Me.PictureBox176.TabStop = False
        Me.PictureBox176.Visible = False
        '
        'PictureBox175
        '
        Me.PictureBox175.Image = CType(resources.GetObject("PictureBox175.Image"), System.Drawing.Image)
        Me.PictureBox175.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox175.Name = "PictureBox175"
        Me.PictureBox175.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox175.TabIndex = 12
        Me.PictureBox175.TabStop = False
        Me.PictureBox175.Visible = False
        '
        'PictureBox174
        '
        Me.PictureBox174.Image = CType(resources.GetObject("PictureBox174.Image"), System.Drawing.Image)
        Me.PictureBox174.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox174.Name = "PictureBox174"
        Me.PictureBox174.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox174.TabIndex = 11
        Me.PictureBox174.TabStop = False
        Me.PictureBox174.Visible = False
        '
        'RESET9
        '
        Me.RESET9.Location = New System.Drawing.Point(13, 196)
        Me.RESET9.Name = "RESET9"
        Me.RESET9.Size = New System.Drawing.Size(49, 25)
        Me.RESET9.TabIndex = 74
        Me.RESET9.Text = "초기화"
        '
        'PictureBox173
        '
        Me.PictureBox173.Image = CType(resources.GetObject("PictureBox173.Image"), System.Drawing.Image)
        Me.PictureBox173.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox173.Name = "PictureBox173"
        Me.PictureBox173.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox173.TabIndex = 12
        Me.PictureBox173.TabStop = False
        Me.PictureBox173.Visible = False
        '
        'PictureBox171
        '
        Me.PictureBox171.Image = CType(resources.GetObject("PictureBox171.Image"), System.Drawing.Image)
        Me.PictureBox171.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox171.Name = "PictureBox171"
        Me.PictureBox171.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox171.TabIndex = 10
        Me.PictureBox171.TabStop = False
        Me.PictureBox171.Visible = False
        '
        'PictureBox169
        '
        Me.PictureBox169.Image = CType(resources.GetObject("PictureBox169.Image"), System.Drawing.Image)
        Me.PictureBox169.Location = New System.Drawing.Point(92, 135)
        Me.PictureBox169.Name = "PictureBox169"
        Me.PictureBox169.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox169.TabIndex = 9
        Me.PictureBox169.TabStop = False
        '
        'PictureBox168
        '
        Me.PictureBox168.Image = CType(resources.GetObject("PictureBox168.Image"), System.Drawing.Image)
        Me.PictureBox168.Location = New System.Drawing.Point(52, 135)
        Me.PictureBox168.Name = "PictureBox168"
        Me.PictureBox168.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox168.TabIndex = 8
        Me.PictureBox168.TabStop = False
        '
        'PictureBox167
        '
        Me.PictureBox167.Image = CType(resources.GetObject("PictureBox167.Image"), System.Drawing.Image)
        Me.PictureBox167.Location = New System.Drawing.Point(13, 135)
        Me.PictureBox167.Name = "PictureBox167"
        Me.PictureBox167.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox167.TabIndex = 7
        Me.PictureBox167.TabStop = False
        '
        'PictureBox166
        '
        Me.PictureBox166.Image = CType(resources.GetObject("PictureBox166.Image"), System.Drawing.Image)
        Me.PictureBox166.Location = New System.Drawing.Point(92, 92)
        Me.PictureBox166.Name = "PictureBox166"
        Me.PictureBox166.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox166.TabIndex = 6
        Me.PictureBox166.TabStop = False
        '
        'PictureBox165
        '
        Me.PictureBox165.Image = CType(resources.GetObject("PictureBox165.Image"), System.Drawing.Image)
        Me.PictureBox165.Location = New System.Drawing.Point(52, 92)
        Me.PictureBox165.Name = "PictureBox165"
        Me.PictureBox165.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox165.TabIndex = 5
        Me.PictureBox165.TabStop = False
        '
        'PictureBox164
        '
        Me.PictureBox164.Image = CType(resources.GetObject("PictureBox164.Image"), System.Drawing.Image)
        Me.PictureBox164.Location = New System.Drawing.Point(13, 92)
        Me.PictureBox164.Name = "PictureBox164"
        Me.PictureBox164.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox164.TabIndex = 4
        Me.PictureBox164.TabStop = False
        '
        'PictureBox162
        '
        Me.PictureBox162.Image = CType(resources.GetObject("PictureBox162.Image"), System.Drawing.Image)
        Me.PictureBox162.Location = New System.Drawing.Point(52, 49)
        Me.PictureBox162.Name = "PictureBox162"
        Me.PictureBox162.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox162.TabIndex = 3
        Me.PictureBox162.TabStop = False
        '
        'PictureBox163
        '
        Me.PictureBox163.Image = CType(resources.GetObject("PictureBox163.Image"), System.Drawing.Image)
        Me.PictureBox163.Location = New System.Drawing.Point(92, 49)
        Me.PictureBox163.Name = "PictureBox163"
        Me.PictureBox163.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox163.TabIndex = 2
        Me.PictureBox163.TabStop = False
        '
        'PictureBox161
        '
        Me.PictureBox161.Image = CType(resources.GetObject("PictureBox161.Image"), System.Drawing.Image)
        Me.PictureBox161.Location = New System.Drawing.Point(13, 49)
        Me.PictureBox161.Name = "PictureBox161"
        Me.PictureBox161.Size = New System.Drawing.Size(40, 43)
        Me.PictureBox161.TabIndex = 0
        Me.PictureBox161.TabStop = False
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g_body)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage2.Text = "불량 등록"
        '
        'g_body
        '
        Me.g_body.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body.Location = New System.Drawing.Point(0, 0)
        Me.g_body.Name = "g_body"
        Me.g_body.ReadOnly = False
        Me.g_body.RecordNavigator = False
        Me.g_body.RowHeight = -1
        Me.g_body.Size = New System.Drawing.Size(1230, 293)
        Me.g_body.TabIndex = 0
        '
        'XtraTabPage3
        '
        Me.XtraTabPage3.Controls.Add(Me.g_body2)
        Me.XtraTabPage3.Name = "XtraTabPage3"
        Me.XtraTabPage3.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage3.Text = "유실 등록"
        '
        'g_body2
        '
        Me.g_body2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body2.Location = New System.Drawing.Point(0, 0)
        Me.g_body2.Name = "g_body2"
        Me.g_body2.ReadOnly = False
        Me.g_body2.RecordNavigator = False
        Me.g_body2.RowHeight = -1
        Me.g_body2.Size = New System.Drawing.Size(1230, 293)
        Me.g_body2.TabIndex = 0
        '
        'XtraTabPage4
        '
        Me.XtraTabPage4.Controls.Add(Me.g_body3)
        Me.XtraTabPage4.Name = "XtraTabPage4"
        Me.XtraTabPage4.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage4.Text = "금형 등록"
        '
        'g_body3
        '
        Me.g_body3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body3.Location = New System.Drawing.Point(0, 0)
        Me.g_body3.Name = "g_body3"
        Me.g_body3.ReadOnly = False
        Me.g_body3.RecordNavigator = False
        Me.g_body3.RowHeight = -1
        Me.g_body3.Size = New System.Drawing.Size(1230, 293)
        Me.g_body3.TabIndex = 0
        '
        'XtraTabPage5
        '
        Me.XtraTabPage5.Controls.Add(Me.g_body4)
        Me.XtraTabPage5.Name = "XtraTabPage5"
        Me.XtraTabPage5.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage5.Text = "작업자 등록"
        '
        'g_body4
        '
        Me.g_body4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body4.Location = New System.Drawing.Point(0, 0)
        Me.g_body4.Name = "g_body4"
        Me.g_body4.ReadOnly = False
        Me.g_body4.RecordNavigator = False
        Me.g_body4.RowHeight = -1
        Me.g_body4.Size = New System.Drawing.Size(1230, 293)
        Me.g_body4.TabIndex = 0
        '
        'XtraTabPage6
        '
        Me.XtraTabPage6.Controls.Add(Me.g_body5)
        Me.XtraTabPage6.Name = "XtraTabPage6"
        Me.XtraTabPage6.Size = New System.Drawing.Size(1230, 293)
        Me.XtraTabPage6.Text = "검사 결과"
        '
        'g_body5
        '
        Me.g_body5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body5.Location = New System.Drawing.Point(0, 0)
        Me.g_body5.Name = "g_body5"
        Me.g_body5.ReadOnly = False
        Me.g_body5.RecordNavigator = False
        Me.g_body5.RowHeight = -1
        Me.g_body5.Size = New System.Drawing.Size(1230, 293)
        Me.g_body5.TabIndex = 0
        '
        'stop_yn
        '
        Me.stop_yn.ColumnName = "BB_PS_CD"
        Me.stop_yn.Location = New System.Drawing.Point(1063, 151)
        Me.stop_yn.Name = "stop_yn"
        Me.stop_yn.Size = New System.Drawing.Size(113, 21)
        Me.stop_yn.TabIndex = 148
        Me.stop_yn.TableName = "BB_PS_CD"
        Me.stop_yn.Title = "중지여부"
        Me.stop_yn.TitleWidth = 70
        Me.stop_yn.Visible = False
        '
        'WI_PR1122
        '
        Me.Controls.Add(Me.spc_1)
        Me.Name = "WI_PR1122"
        Me.Size = New System.Drawing.Size(1615, 611)
        Me.Controls.SetChildIndex(Me.spc_1, 0)
        Me.spc_1.Panel1.ResumeLayout(False)
        Me.spc_1.Panel2.ResumeLayout(False)
        Me.spc_1.ResumeLayout(False)
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab1.ResumeLayout(False)
        Me.tp1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.tp2.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl2.ResumeLayout(False)
        Me.XtraTabPage8.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.XtraTabControl12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl12.ResumeLayout(False)
        Me.XtraTabPage10.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.PictureBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox61, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.PictureBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox41, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage11.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox119, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox109, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox111, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox118, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox117, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox101, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox107, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox108, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.PictureBox159, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox158, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox157, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox156, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox155, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox154, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox153, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox152, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox151, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox148, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox149, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox147, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox146, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox145, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox144, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox142, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox143, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox141, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.PictureBox139, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox138, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox137, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox136, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox135, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox134, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox133, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox132, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox131, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox128, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox129, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox127, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox126, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox125, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox124, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox122, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox123, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox121, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox81, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage12.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.PictureBox199, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox192, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox189, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox191, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox198, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox194, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox193, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox197, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox182, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox196, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox183, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox195, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox181, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox184, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox185, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox186, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox187, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox188, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.PictureBox239, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox238, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox237, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox236, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox235, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox234, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox233, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox232, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox231, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox228, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox229, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox227, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox226, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox225, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox224, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox222, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox223, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox221, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox11.ResumeLayout(False)
        CType(Me.PictureBox219, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox218, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox217, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox216, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox215, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox214, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox213, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox212, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox211, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox208, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox209, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox207, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox206, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox205, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox204, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox202, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox203, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox201, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox12.ResumeLayout(False)
        CType(Me.PictureBox172, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox179, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox178, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox177, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox176, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox175, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox174, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox173, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox171, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox169, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox168, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox167, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox166, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox165, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox164, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox162, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox163, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox161, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabPage2.ResumeLayout(False)
        Me.XtraTabPage3.ResumeLayout(False)
        Me.XtraTabPage4.ResumeLayout(False)
        Me.XtraTabPage5.ResumeLayout(False)
        Me.XtraTabPage6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spc_1 As System.Windows.Forms.SplitContainer
    Friend WithEvents tab1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tp1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents btn_cancel As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_find As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents find_visible As System.Windows.Forms.CheckBox
    Friend WithEvents find_to As Frame7.eDate
    Friend WithEvents find_from As Frame7.eDate
    Friend WithEvents find_gd_nm As Frame7.eText
    Friend WithEvents find_stts As Frame7.eCombo
    Friend WithEvents g_list As Frame7.eGrid
    Friend WithEvents tp2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents find_job_no2 As Frame7.eText
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents btn_cancel2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_find2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents find_visible2 As System.Windows.Forms.CheckBox
    Friend WithEvents find_to2 As Frame7.eDate
    Friend WithEvents find_from2 As Frame7.eDate
    Friend WithEvents find_gd_nm2 As Frame7.eText
    Friend WithEvents g_list2 As Frame7.eGrid
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents stts As Frame7.eCombo
    Friend WithEvents sa_cd As Frame7.eCombo
    Friend WithEvents mate_no As Frame7.eText
    Friend WithEvents gong_cd As Frame7.eCombo
    Friend WithEvents pr_no As Frame7.eText
    Friend WithEvents unit_cd As Frame7.eCombo
    Friend WithEvents new_gdcd As Frame7.eText
    Friend WithEvents new_gdnm As Frame7.eText
    Friend WithEvents pr_dt As Frame7.eDate
    Friend WithEvents job_no As Frame7.eText
    Friend WithEvents twh_cd As Frame7.eCombo
    Friend WithEvents new_spec As Frame7.eText
    Friend WithEvents from_dt As Frame7.eDate
    Friend WithEvents fwh_cd As Frame7.eCombo
    Friend WithEvents from_time As Frame7.eText
    Friend WithEvents pr_jobno As Frame7.eText
    Friend WithEvents job_seq As Frame7.eText
    Friend WithEvents to_time As Frame7.eText
    Friend WithEvents mc_cd As Frame7.eCombo
    Friend WithEvents lot_no As Frame7.eText
    Friend WithEvents ps_nm As Frame7.eText
    Friend WithEvents ps_cd As Frame7.eText
    Friend WithEvents gd_cd As Frame7.eText
    Friend WithEvents to_dt As Frame7.eDate
    Friend WithEvents spec As Frame7.eText
    Friend WithEvents gd_nm As Frame7.eText
    Friend WithEvents wa_cd As Frame7.eCombo
    Friend WithEvents pr_qty As Frame7.eText
    Friend WithEvents tot_qty As Frame7.eText
    Friend WithEvents job_qty As Frame7.eText
    Friend WithEvents ng_qty As Frame7.eText
    Friend WithEvents ja_cd As Frame7.eText
    Friend WithEvents mate_qty As Frame7.eText
    Friend WithEvents spec30 As Frame7.eText
    Friend WithEvents pop_qty As Frame7.eText
    Friend WithEvents sample_qty As Frame7.eText
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body As Frame7.eGrid
    Friend WithEvents XtraTabPage3 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body2 As Frame7.eGrid
    Friend WithEvents XtraTabPage4 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body3 As Frame7.eGrid
    Friend WithEvents XtraTabPage5 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body4 As Frame7.eGrid
    Friend WithEvents XtraTabPage6 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body5 As Frame7.eGrid
    Friend WithEvents cr_sp As Frame7.eText
    Friend WithEvents mold_cd As Frame7.eText
    Friend WithEvents find_mc_cd As Frame7.eCombo
    Friend WithEvents find_mc_cd2 As Frame7.eCombo
    Friend WithEvents find_lot_no As Frame7.eText
    Friend WithEvents btn_save As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_new As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents POP_SP As Frame7.eText
    Friend WithEvents XtraTabControl2 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage8 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents remark As Frame7.eMemo
    Friend WithEvents XtraTabControl12 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage12 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage10 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage11 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents RESET As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SAVE_IMG As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox39 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox32 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox28 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox29 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox31 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox27 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox38 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox26 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox33 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox25 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox37 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox24 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox22 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox36 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox23 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox35 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox68 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox69 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox67 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox66 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox65 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox64 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox62 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox63 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox61 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox59 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox58 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox57 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox56 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox55 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox54 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox53 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox52 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox51 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox48 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox49 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox47 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox46 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox45 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox44 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox42 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox43 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox41 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox71 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox79 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox78 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox77 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox76 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox75 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox74 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox73 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox72 As System.Windows.Forms.PictureBox
    Friend WithEvents SAVE_IMG2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SAVE_IMG4 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET4 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SAVE_IMG3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents g_body1 As Frame7.eGrid
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox119 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox112 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox109 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox111 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox118 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox114 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox113 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox117 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox102 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox116 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox103 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox115 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox101 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox104 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox105 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox106 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox107 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox108 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG8 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET8 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox159 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox158 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox157 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox156 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox155 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox154 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox153 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox152 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox151 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox148 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox149 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox147 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox146 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox145 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox144 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox142 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox143 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox141 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG7 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET7 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox139 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox138 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox137 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox136 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox135 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox134 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox133 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox132 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox131 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox128 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox129 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox127 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox126 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox125 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox124 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox122 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox123 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox121 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG5 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox92 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox99 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox98 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox97 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox96 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox95 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox94 As System.Windows.Forms.PictureBox
    Friend WithEvents RESET5 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox93 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox91 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox89 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox88 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox87 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox86 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox85 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox84 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox82 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox83 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox81 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG10 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET10 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox199 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox192 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox189 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox191 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox198 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox194 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox193 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox197 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox182 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox196 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox183 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox195 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox181 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox184 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox185 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox186 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox187 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox188 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG12 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET12 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox239 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox238 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox237 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox236 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox235 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox234 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox233 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox232 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox231 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox228 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox229 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox227 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox226 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox225 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox224 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox222 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox223 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox221 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG11 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RESET11 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox219 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox218 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox217 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox216 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox215 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox214 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox213 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox212 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox211 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox208 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox209 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox207 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox206 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox205 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox204 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox202 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox203 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox201 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents SAVE_IMG9 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox172 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox179 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox178 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox177 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox176 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox175 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox174 As System.Windows.Forms.PictureBox
    Friend WithEvents RESET9 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PictureBox173 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox171 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox169 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox168 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox167 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox166 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox165 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox164 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox162 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox163 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox161 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_lot_print As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents BB_PS_NM As Frame7.eText
    Friend WithEvents BB_PS_CD As Frame7.eText
    Friend WithEvents stop_yn As Frame7.eText

End Class
