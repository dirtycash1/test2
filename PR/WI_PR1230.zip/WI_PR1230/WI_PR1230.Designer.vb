﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WI_PR1230
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.spc_1 = New System.Windows.Forms.SplitContainer()
        Me.tab1 = New DevExpress.XtraTab.XtraTabControl()
        Me.tp1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_cancel = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_find = New DevExpress.XtraEditors.SimpleButton()
        Me.find_visible = New System.Windows.Forms.CheckBox()
        Me.find_to = New Frame7.eDate()
        Me.find_from = New Frame7.eDate()
        Me.find_gd_nm = New Frame7.eText()
        Me.find_stts = New Frame7.eCombo()
        Me.g_list = New Frame7.eGrid()
        Me.tp2 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.find_job_no2 = New Frame7.eText()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btn_cancel2 = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_find2 = New DevExpress.XtraEditors.SimpleButton()
        Me.find_visible2 = New System.Windows.Forms.CheckBox()
        Me.find_to2 = New Frame7.eDate()
        Me.find_from2 = New Frame7.eDate()
        Me.find_gd_nm2 = New Frame7.eText()
        Me.g_list2 = New Frame7.eGrid()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.print_qty = New Frame7.eText()
        Me.db_print_qty = New Frame7.eText()
        Me.new_gdenm = New Frame7.eText()
        Me.gd_enm = New Frame7.eText()
        Me.stts = New Frame7.eCombo()
        Me.sa_cd = New Frame7.eCombo()
        Me.Y_Day = New Frame7.eText()
        Me.gong_cd = New Frame7.eCombo()
        Me.pr_no = New Frame7.eText()
        Me.unit_cd = New Frame7.eCombo()
        Me.MIC_print = New DevExpress.XtraEditors.SimpleButton()
        Me.mate_no = New Frame7.eText()
        Me.pr_dt = New Frame7.eDate()
        Me.from_dt = New Frame7.eDate()
        Me.twh_cd = New Frame7.eCombo()
        Me.new_gdcd = New Frame7.eText()
        Me.fwh_cd = New Frame7.eCombo()
        Me.new_spec = New Frame7.eText()
        Me.new_gdnm = New Frame7.eText()
        Me.job_no = New Frame7.eText()
        Me.from_time = New Frame7.eText()
        Me.job_seq = New Frame7.eText()
        Me.to_time = New Frame7.eText()
        Me.lot_no = New Frame7.eText()
        Me.gd_cd = New Frame7.eText()
        Me.pr_jobno = New Frame7.eText()
        Me.to_dt = New Frame7.eDate()
        Me.spec = New Frame7.eText()
        Me.ps_nm = New Frame7.eText()
        Me.mc_cd = New Frame7.eCombo()
        Me.ps_cd = New Frame7.eText()
        Me.gd_nm = New Frame7.eText()
        Me.FAC_CD = New Frame7.eCombo()
        Me.pr_qty = New Frame7.eText()
        Me.wa_cd = New Frame7.eCombo()
        Me.job_qty = New Frame7.eText()
        Me.ng_qty = New Frame7.eText()
        Me.tot_qty = New Frame7.eText()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.g_body = New Frame7.eGrid()
        Me.spc_1.Panel1.SuspendLayout()
        Me.spc_1.Panel2.SuspendLayout()
        Me.spc_1.SuspendLayout()
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab1.SuspendLayout()
        Me.tp1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.tp2.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.SuspendLayout()
        '
        'spc_1
        '
        Me.spc_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spc_1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.spc_1.Location = New System.Drawing.Point(0, 0)
        Me.spc_1.Name = "spc_1"
        '
        'spc_1.Panel1
        '
        Me.spc_1.Panel1.Controls.Add(Me.tab1)
        '
        'spc_1.Panel2
        '
        Me.spc_1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.spc_1.Size = New System.Drawing.Size(1383, 611)
        Me.spc_1.SplitterDistance = 374
        Me.spc_1.TabIndex = 10
        '
        'tab1
        '
        Me.tab1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tab1.Location = New System.Drawing.Point(0, 0)
        Me.tab1.Name = "tab1"
        Me.tab1.SelectedTabPage = Me.tp1
        Me.tab1.Size = New System.Drawing.Size(374, 611)
        Me.tab1.TabIndex = 50
        Me.tab1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tp1, Me.tp2})
        '
        'tp1
        '
        Me.tp1.Controls.Add(Me.SplitContainer1)
        Me.tp1.Name = "tp1"
        Me.tp1.Size = New System.Drawing.Size(367, 581)
        Me.tp1.Text = "검색 조건"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.g_list)
        Me.SplitContainer1.Size = New System.Drawing.Size(367, 581)
        Me.SplitContainer1.SplitterDistance = 189
        Me.SplitContainer1.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Panel1)
        Me.Panel2.Controls.Add(Me.find_to)
        Me.Panel2.Controls.Add(Me.find_from)
        Me.Panel2.Controls.Add(Me.find_gd_nm)
        Me.Panel2.Controls.Add(Me.find_stts)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(367, 189)
        Me.Panel2.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.btn_cancel)
        Me.Panel1.Controls.Add(Me.btn_find)
        Me.Panel1.Controls.Add(Me.find_visible)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 148)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(367, 41)
        Me.Panel1.TabIndex = 2
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(98, 6)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(72, 27)
        Me.btn_cancel.TabIndex = 72
        Me.btn_cancel.Text = "취   소"
        '
        'btn_find
        '
        Me.btn_find.Location = New System.Drawing.Point(10, 6)
        Me.btn_find.Name = "btn_find"
        Me.btn_find.Size = New System.Drawing.Size(72, 27)
        Me.btn_find.TabIndex = 71
        Me.btn_find.Text = "검   색"
        '
        'find_visible
        '
        Me.find_visible.AutoSize = True
        Me.find_visible.Checked = True
        Me.find_visible.CheckState = System.Windows.Forms.CheckState.Checked
        Me.find_visible.Dock = System.Windows.Forms.DockStyle.Right
        Me.find_visible.Location = New System.Drawing.Point(273, 0)
        Me.find_visible.Name = "find_visible"
        Me.find_visible.Size = New System.Drawing.Size(92, 39)
        Me.find_visible.TabIndex = 48
        Me.find_visible.Text = "선택 후 숨김"
        Me.find_visible.UseVisualStyleBackColor = True
        '
        'find_to
        '
        Me.find_to.Location = New System.Drawing.Point(187, 30)
        Me.find_to.Name = "find_to"
        Me.find_to.Size = New System.Drawing.Size(111, 21)
        Me.find_to.TabIndex = 51
        Me.find_to.Title = "~"
        Me.find_to.TitleWidth = 10
        '
        'find_from
        '
        Me.find_from.Location = New System.Drawing.Point(25, 30)
        Me.find_from.Name = "find_from"
        Me.find_from.Size = New System.Drawing.Size(159, 21)
        Me.find_from.TabIndex = 50
        Me.find_from.Title = "기간"
        Me.find_from.TitleWidth = 60
        '
        'find_gd_nm
        '
        Me.find_gd_nm.ColumnName = "find_paymenterm_cd"
        Me.find_gd_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.find_gd_nm.Location = New System.Drawing.Point(25, 58)
        Me.find_gd_nm.Name = "find_gd_nm"
        Me.find_gd_nm.Size = New System.Drawing.Size(273, 21)
        Me.find_gd_nm.TabIndex = 48
        Me.find_gd_nm.TableName = "find_paymenterm_cd"
        Me.find_gd_nm.Title = "제품명"
        Me.find_gd_nm.TitleWidth = 60
        '
        'find_stts
        '
        Me.find_stts.Location = New System.Drawing.Point(25, 85)
        Me.find_stts.Name = "find_stts"
        Me.find_stts.Size = New System.Drawing.Size(159, 21)
        Me.find_stts.TabIndex = 49
        Me.find_stts.Title = "상태"
        Me.find_stts.TitleWidth = 60
        '
        'g_list
        '
        Me.g_list.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_list.Location = New System.Drawing.Point(0, 0)
        Me.g_list.Name = "g_list"
        Me.g_list.ReadOnly = False
        Me.g_list.RowHeight = -1
        Me.g_list.Size = New System.Drawing.Size(367, 388)
        Me.g_list.TabIndex = 0
        '
        'tp2
        '
        Me.tp2.Controls.Add(Me.SplitContainer4)
        Me.tp2.Name = "tp2"
        Me.tp2.Size = New System.Drawing.Size(367, 581)
        Me.tp2.Text = "등록할 자료"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.Panel3)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.g_list2)
        Me.SplitContainer4.Size = New System.Drawing.Size(367, 581)
        Me.SplitContainer4.SplitterDistance = 189
        Me.SplitContainer4.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.find_job_no2)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.find_to2)
        Me.Panel3.Controls.Add(Me.find_from2)
        Me.Panel3.Controls.Add(Me.find_gd_nm2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(367, 189)
        Me.Panel3.TabIndex = 0
        '
        'find_job_no2
        '
        Me.find_job_no2.ColumnName = "find_paymenterm_cd"
        Me.find_job_no2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.find_job_no2.Location = New System.Drawing.Point(20, 85)
        Me.find_job_no2.Name = "find_job_no2"
        Me.find_job_no2.Size = New System.Drawing.Size(296, 21)
        Me.find_job_no2.TabIndex = 52
        Me.find_job_no2.TableName = "find_paymenterm_cd"
        Me.find_job_no2.Title = "생산지시번호"
        Me.find_job_no2.TitleWidth = 83
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.btn_cancel2)
        Me.Panel4.Controls.Add(Me.btn_find2)
        Me.Panel4.Controls.Add(Me.find_visible2)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 148)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(367, 41)
        Me.Panel4.TabIndex = 2
        '
        'btn_cancel2
        '
        Me.btn_cancel2.Location = New System.Drawing.Point(98, 6)
        Me.btn_cancel2.Name = "btn_cancel2"
        Me.btn_cancel2.Size = New System.Drawing.Size(72, 27)
        Me.btn_cancel2.TabIndex = 72
        Me.btn_cancel2.Text = "취   소"
        '
        'btn_find2
        '
        Me.btn_find2.Location = New System.Drawing.Point(10, 6)
        Me.btn_find2.Name = "btn_find2"
        Me.btn_find2.Size = New System.Drawing.Size(72, 27)
        Me.btn_find2.TabIndex = 71
        Me.btn_find2.Text = "검   색"
        '
        'find_visible2
        '
        Me.find_visible2.AutoSize = True
        Me.find_visible2.Checked = True
        Me.find_visible2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.find_visible2.Dock = System.Windows.Forms.DockStyle.Right
        Me.find_visible2.Location = New System.Drawing.Point(273, 0)
        Me.find_visible2.Name = "find_visible2"
        Me.find_visible2.Size = New System.Drawing.Size(92, 39)
        Me.find_visible2.TabIndex = 48
        Me.find_visible2.Text = "선택 후 숨김"
        Me.find_visible2.UseVisualStyleBackColor = True
        '
        'find_to2
        '
        Me.find_to2.Location = New System.Drawing.Point(205, 30)
        Me.find_to2.Name = "find_to2"
        Me.find_to2.Size = New System.Drawing.Size(111, 21)
        Me.find_to2.TabIndex = 51
        Me.find_to2.Title = "~"
        Me.find_to2.TitleWidth = 10
        '
        'find_from2
        '
        Me.find_from2.Location = New System.Drawing.Point(43, 30)
        Me.find_from2.Name = "find_from2"
        Me.find_from2.Size = New System.Drawing.Size(159, 21)
        Me.find_from2.TabIndex = 50
        Me.find_from2.Title = "기간"
        Me.find_from2.TitleWidth = 60
        '
        'find_gd_nm2
        '
        Me.find_gd_nm2.ColumnName = "find_paymenterm_cd"
        Me.find_gd_nm2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.find_gd_nm2.Location = New System.Drawing.Point(43, 58)
        Me.find_gd_nm2.Name = "find_gd_nm2"
        Me.find_gd_nm2.Size = New System.Drawing.Size(273, 21)
        Me.find_gd_nm2.TabIndex = 48
        Me.find_gd_nm2.TableName = "find_paymenterm_cd"
        Me.find_gd_nm2.Title = "품명"
        Me.find_gd_nm2.TitleWidth = 60
        '
        'g_list2
        '
        Me.g_list2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_list2.Location = New System.Drawing.Point(0, 0)
        Me.g_list2.Name = "g_list2"
        Me.g_list2.ReadOnly = False
        Me.g_list2.RowHeight = -1
        Me.g_list2.Size = New System.Drawing.Size(367, 388)
        Me.g_list2.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer2.Size = New System.Drawing.Size(1005, 611)
        Me.SplitContainer2.SplitterDistance = 227
        Me.SplitContainer2.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.new_gdenm)
        Me.EPanel1.Controls.Add(Me.gd_enm)
        Me.EPanel1.Controls.Add(Me.print_qty)
        Me.EPanel1.Controls.Add(Me.db_print_qty)
        Me.EPanel1.Controls.Add(Me.stts)
        Me.EPanel1.Controls.Add(Me.sa_cd)
        Me.EPanel1.Controls.Add(Me.gong_cd)
        Me.EPanel1.Controls.Add(Me.pr_no)
        Me.EPanel1.Controls.Add(Me.Y_Day)
        Me.EPanel1.Controls.Add(Me.unit_cd)
        Me.EPanel1.Controls.Add(Me.MIC_print)
        Me.EPanel1.Controls.Add(Me.mate_no)
        Me.EPanel1.Controls.Add(Me.pr_dt)
        Me.EPanel1.Controls.Add(Me.from_dt)
        Me.EPanel1.Controls.Add(Me.twh_cd)
        Me.EPanel1.Controls.Add(Me.new_gdcd)
        Me.EPanel1.Controls.Add(Me.fwh_cd)
        Me.EPanel1.Controls.Add(Me.new_spec)
        Me.EPanel1.Controls.Add(Me.new_gdnm)
        Me.EPanel1.Controls.Add(Me.job_no)
        Me.EPanel1.Controls.Add(Me.from_time)
        Me.EPanel1.Controls.Add(Me.job_seq)
        Me.EPanel1.Controls.Add(Me.to_time)
        Me.EPanel1.Controls.Add(Me.lot_no)
        Me.EPanel1.Controls.Add(Me.gd_cd)
        Me.EPanel1.Controls.Add(Me.pr_jobno)
        Me.EPanel1.Controls.Add(Me.to_dt)
        Me.EPanel1.Controls.Add(Me.spec)
        Me.EPanel1.Controls.Add(Me.ps_nm)
        Me.EPanel1.Controls.Add(Me.mc_cd)
        Me.EPanel1.Controls.Add(Me.ps_cd)
        Me.EPanel1.Controls.Add(Me.gd_nm)
        Me.EPanel1.Controls.Add(Me.pr_qty)
        Me.EPanel1.Controls.Add(Me.wa_cd)
        Me.EPanel1.Controls.Add(Me.FAC_CD)
        Me.EPanel1.Controls.Add(Me.job_qty)
        Me.EPanel1.Controls.Add(Me.ng_qty)
        Me.EPanel1.Controls.Add(Me.tot_qty)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1005, 227)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     EPanel1"
        '
        'print_qty
        '
        Me.print_qty.ColumnName = "ps_cd"
        Me.print_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.print_qty.Location = New System.Drawing.Point(900, 49)
        Me.print_qty.Name = "print_qty"
        Me.print_qty.Size = New System.Drawing.Size(196, 21)
        Me.print_qty.TabIndex = 128
        Me.print_qty.TableName = "ps_cd"
        Me.print_qty.Title = "출력 매수"
        Me.print_qty.TitleWidth = 70
        Me.print_qty.Visible = False
        '
        'db_print_qty
        '
        Me.db_print_qty.ColumnName = "ps_cd"
        Me.db_print_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.db_print_qty.Location = New System.Drawing.Point(900, 25)
        Me.db_print_qty.Name = "db_print_qty"
        Me.db_print_qty.Size = New System.Drawing.Size(196, 21)
        Me.db_print_qty.TabIndex = 127
        Me.db_print_qty.TableName = "ps_cd"
        Me.db_print_qty.Title = "총 매수"
        Me.db_print_qty.TitleWidth = 70
        Me.db_print_qty.Visible = False
        '
        'new_gdenm
        '
        Me.new_gdenm.ColumnName = "ps_cd"
        Me.new_gdenm.Enabled = False
        Me.new_gdenm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.new_gdenm.Location = New System.Drawing.Point(918, 107)
        Me.new_gdenm.Name = "new_gdenm"
        Me.new_gdenm.Size = New System.Drawing.Size(297, 21)
        Me.new_gdenm.TabIndex = 126
        Me.new_gdenm.TableName = "ps_cd"
        Me.new_gdenm.Title = "품명(영문)"
        Me.new_gdenm.TitleWidth = 98
        Me.new_gdenm.Visible = False
        '
        'gd_enm
        '
        Me.gd_enm.ColumnName = "ps_cd"
        Me.gd_enm.Enabled = False
        Me.gd_enm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.gd_enm.Location = New System.Drawing.Point(918, 134)
        Me.gd_enm.Name = "gd_enm"
        Me.gd_enm.Size = New System.Drawing.Size(297, 21)
        Me.gd_enm.TabIndex = 125
        Me.gd_enm.TableName = "ps_cd"
        Me.gd_enm.Title = "품명(영문)"
        Me.gd_enm.TitleWidth = 98
        Me.gd_enm.Visible = False
        '
        'stts
        '
        Me.stts.Location = New System.Drawing.Point(932, 193)
        Me.stts.Name = "stts"
        Me.stts.Size = New System.Drawing.Size(201, 21)
        Me.stts.TabIndex = 122
        Me.stts.Title = "상태"
        Me.stts.TitleWidth = 70
        Me.stts.Visible = False
        '
        'sa_cd
        '
        Me.sa_cd.Location = New System.Drawing.Point(693, 53)
        Me.sa_cd.Name = "sa_cd"
        Me.sa_cd.Size = New System.Drawing.Size(201, 21)
        Me.sa_cd.TabIndex = 121
        Me.sa_cd.Title = "사업장"
        Me.sa_cd.TitleWidth = 70
        '
        'Y_Day
        '
        Me.Y_Day.ColumnName = "ps_cd"
        Me.Y_Day.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.Y_Day.Location = New System.Drawing.Point(443, 197)
        Me.Y_Day.Name = "Y_Day"
        Me.Y_Day.Size = New System.Drawing.Size(196, 21)
        Me.Y_Day.TabIndex = 124
        Me.Y_Day.TableName = "ps_cd"
        Me.Y_Day.Title = "유효기간"
        Me.Y_Day.TitleWidth = 70
        '
        'gong_cd
        '
        Me.gong_cd.Location = New System.Drawing.Point(29, 53)
        Me.gong_cd.Name = "gong_cd"
        Me.gong_cd.Size = New System.Drawing.Size(296, 21)
        Me.gong_cd.TabIndex = 119
        Me.gong_cd.Title = "공정"
        Me.gong_cd.TitleWidth = 98
        '
        'pr_no
        '
        Me.pr_no.ColumnName = "job_no"
        Me.pr_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pr_no.Location = New System.Drawing.Point(29, 29)
        Me.pr_no.Name = "pr_no"
        Me.pr_no.Size = New System.Drawing.Size(233, 21)
        Me.pr_no.TabIndex = 89
        Me.pr_no.TableName = "job_no"
        Me.pr_no.Title = "생산실적번호"
        Me.pr_no.TitleWidth = 98
        '
        'unit_cd
        '
        Me.unit_cd.Location = New System.Drawing.Point(29, 126)
        Me.unit_cd.Name = "unit_cd"
        Me.unit_cd.Size = New System.Drawing.Size(233, 21)
        Me.unit_cd.TabIndex = 109
        Me.unit_cd.Title = "단위"
        Me.unit_cd.TitleWidth = 98
        '
        'MIC_print
        '
        Me.MIC_print.Location = New System.Drawing.Point(342, 174)
        Me.MIC_print.Name = "MIC_print"
        Me.MIC_print.Size = New System.Drawing.Size(95, 45)
        Me.MIC_print.TabIndex = 123
        Me.MIC_print.Text = "라벨출력"
        '
        'mate_no
        '
        Me.mate_no.ColumnName = "job_no"
        Me.mate_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.mate_no.Location = New System.Drawing.Point(918, 29)
        Me.mate_no.Name = "mate_no"
        Me.mate_no.Size = New System.Drawing.Size(201, 21)
        Me.mate_no.TabIndex = 120
        Me.mate_no.TableName = "job_no"
        Me.mate_no.Title = "멸균NO."
        Me.mate_no.TitleWidth = 70
        Me.mate_no.Visible = False
        '
        'pr_dt
        '
        Me.pr_dt.ColumnName = "plan_dt"
        Me.pr_dt.Location = New System.Drawing.Point(693, 29)
        Me.pr_dt.Name = "pr_dt"
        Me.pr_dt.Size = New System.Drawing.Size(201, 21)
        Me.pr_dt.TabIndex = 92
        Me.pr_dt.TableName = "plan_dt"
        Me.pr_dt.Title = "생산일자"
        Me.pr_dt.TitleWidth = 70
        '
        'from_dt
        '
        Me.from_dt.ColumnName = "plan_dt"
        Me.from_dt.Location = New System.Drawing.Point(28, 174)
        Me.from_dt.Name = "from_dt"
        Me.from_dt.Size = New System.Drawing.Size(233, 21)
        Me.from_dt.TabIndex = 103
        Me.from_dt.TableName = "plan_dt"
        Me.from_dt.Title = "생산시작일시"
        Me.from_dt.TitleWidth = 98
        '
        'twh_cd
        '
        Me.twh_cd.Location = New System.Drawing.Point(918, 256)
        Me.twh_cd.Name = "twh_cd"
        Me.twh_cd.Size = New System.Drawing.Size(201, 21)
        Me.twh_cd.TabIndex = 116
        Me.twh_cd.Title = "출고창고"
        Me.twh_cd.TitleWidth = 70
        '
        'new_gdcd
        '
        Me.new_gdcd.ColumnName = "ps_cd"
        Me.new_gdcd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.new_gdcd.Location = New System.Drawing.Point(342, 77)
        Me.new_gdcd.Name = "new_gdcd"
        Me.new_gdcd.Size = New System.Drawing.Size(297, 21)
        Me.new_gdcd.TabIndex = 111
        Me.new_gdcd.TableName = "ps_cd"
        Me.new_gdcd.Title = "실적입고품목"
        Me.new_gdcd.TitleWidth = 98
        '
        'fwh_cd
        '
        Me.fwh_cd.Location = New System.Drawing.Point(918, 234)
        Me.fwh_cd.Name = "fwh_cd"
        Me.fwh_cd.Size = New System.Drawing.Size(201, 21)
        Me.fwh_cd.TabIndex = 115
        Me.fwh_cd.Title = "입고창고"
        Me.fwh_cd.TitleWidth = 70
        '
        'new_spec
        '
        Me.new_spec.ColumnName = "ps_cd"
        Me.new_spec.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.new_spec.Location = New System.Drawing.Point(342, 102)
        Me.new_spec.Name = "new_spec"
        Me.new_spec.Size = New System.Drawing.Size(297, 21)
        Me.new_spec.TabIndex = 113
        Me.new_spec.TableName = "ps_cd"
        Me.new_spec.Title = "규격"
        Me.new_spec.TitleWidth = 98
        '
        'new_gdnm
        '
        Me.new_gdnm.ColumnName = "ps_cd"
        Me.new_gdnm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.new_gdnm.Location = New System.Drawing.Point(918, 161)
        Me.new_gdnm.Name = "new_gdnm"
        Me.new_gdnm.Size = New System.Drawing.Size(297, 21)
        Me.new_gdnm.TabIndex = 112
        Me.new_gdnm.TableName = "ps_cd"
        Me.new_gdnm.Title = "품명"
        Me.new_gdnm.TitleWidth = 98
        Me.new_gdnm.Visible = False
        '
        'job_no
        '
        Me.job_no.ColumnName = "job_no"
        Me.job_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.job_no.Location = New System.Drawing.Point(918, 53)
        Me.job_no.Name = "job_no"
        Me.job_no.Size = New System.Drawing.Size(254, 21)
        Me.job_no.TabIndex = 88
        Me.job_no.TableName = "job_no"
        Me.job_no.Title = "생산지시번호"
        Me.job_no.TitleWidth = 98
        Me.job_no.Visible = False
        '
        'from_time
        '
        Me.from_time.ColumnName = "ps_cd"
        Me.from_time.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.from_time.Location = New System.Drawing.Point(269, 174)
        Me.from_time.Name = "from_time"
        Me.from_time.Size = New System.Drawing.Size(57, 21)
        Me.from_time.TabIndex = 105
        Me.from_time.TableName = "ps_cd"
        Me.from_time.Title = "약품번호"
        Me.from_time.TitleWidth = 0
        '
        'job_seq
        '
        Me.job_seq.ColumnName = "job_no"
        Me.job_seq.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.job_seq.Location = New System.Drawing.Point(918, 80)
        Me.job_seq.Name = "job_seq"
        Me.job_seq.Size = New System.Drawing.Size(37, 21)
        Me.job_seq.TabIndex = 110
        Me.job_seq.TableName = "job_no"
        Me.job_seq.Title = "생산지시번호"
        Me.job_seq.TitleWidth = 0
        Me.job_seq.Visible = False
        '
        'to_time
        '
        Me.to_time.ColumnName = "ps_cd"
        Me.to_time.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.to_time.Location = New System.Drawing.Point(269, 198)
        Me.to_time.Name = "to_time"
        Me.to_time.Size = New System.Drawing.Size(57, 21)
        Me.to_time.TabIndex = 106
        Me.to_time.TableName = "ps_cd"
        Me.to_time.Title = "약품번호"
        Me.to_time.TitleWidth = 0
        '
        'lot_no
        '
        Me.lot_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.lot_no.Location = New System.Drawing.Point(29, 150)
        Me.lot_no.Name = "lot_no"
        Me.lot_no.Size = New System.Drawing.Size(297, 21)
        Me.lot_no.TabIndex = 102
        Me.lot_no.Title = "LOT NO."
        Me.lot_no.TitleWidth = 98
        '
        'gd_cd
        '
        Me.gd_cd.ColumnName = "ps_cd"
        Me.gd_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.gd_cd.Location = New System.Drawing.Point(29, 77)
        Me.gd_cd.Name = "gd_cd"
        Me.gd_cd.Size = New System.Drawing.Size(297, 21)
        Me.gd_cd.TabIndex = 94
        Me.gd_cd.TableName = "ps_cd"
        Me.gd_cd.Title = "품목"
        Me.gd_cd.TitleWidth = 98
        '
        'pr_jobno
        '
        Me.pr_jobno.ColumnName = "job_no"
        Me.pr_jobno.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pr_jobno.Location = New System.Drawing.Point(342, 53)
        Me.pr_jobno.Name = "pr_jobno"
        Me.pr_jobno.Size = New System.Drawing.Size(297, 21)
        Me.pr_jobno.TabIndex = 114
        Me.pr_jobno.TableName = "job_no"
        Me.pr_jobno.Title = "생산지시번호"
        Me.pr_jobno.TitleWidth = 98
        '
        'to_dt
        '
        Me.to_dt.ColumnName = "plan_dt"
        Me.to_dt.Location = New System.Drawing.Point(28, 198)
        Me.to_dt.Name = "to_dt"
        Me.to_dt.Size = New System.Drawing.Size(233, 21)
        Me.to_dt.TabIndex = 104
        Me.to_dt.TableName = "plan_dt"
        Me.to_dt.Title = "생산완료일시"
        Me.to_dt.TitleWidth = 98
        '
        'spec
        '
        Me.spec.ColumnName = "ps_cd"
        Me.spec.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.spec.Location = New System.Drawing.Point(29, 102)
        Me.spec.Name = "spec"
        Me.spec.Size = New System.Drawing.Size(297, 21)
        Me.spec.TabIndex = 96
        Me.spec.TableName = "ps_cd"
        Me.spec.Title = "규격"
        Me.spec.TitleWidth = 98
        '
        'ps_nm
        '
        Me.ps_nm.ColumnName = "pl_nm"
        Me.ps_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ps_nm.Location = New System.Drawing.Point(524, 29)
        Me.ps_nm.Name = "ps_nm"
        Me.ps_nm.Size = New System.Drawing.Size(115, 21)
        Me.ps_nm.TabIndex = 91
        Me.ps_nm.TableName = "pl_nm"
        Me.ps_nm.Title = "부서"
        Me.ps_nm.TitleWidth = 0
        '
        'mc_cd
        '
        Me.mc_cd.Location = New System.Drawing.Point(342, 150)
        Me.mc_cd.Name = "mc_cd"
        Me.mc_cd.Size = New System.Drawing.Size(297, 21)
        Me.mc_cd.TabIndex = 107
        Me.mc_cd.Title = "기계"
        Me.mc_cd.TitleWidth = 98
        '
        'ps_cd
        '
        Me.ps_cd.ColumnName = "ps_cd"
        Me.ps_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ps_cd.Location = New System.Drawing.Point(342, 29)
        Me.ps_cd.Name = "ps_cd"
        Me.ps_cd.Size = New System.Drawing.Size(176, 21)
        Me.ps_cd.TabIndex = 90
        Me.ps_cd.TableName = "ps_cd"
        Me.ps_cd.Title = "작성자"
        Me.ps_cd.TitleWidth = 98
        '
        'gd_nm
        '
        Me.gd_nm.ColumnName = "ps_cd"
        Me.gd_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.gd_nm.Location = New System.Drawing.Point(918, 180)
        Me.gd_nm.Name = "gd_nm"
        Me.gd_nm.Size = New System.Drawing.Size(297, 21)
        Me.gd_nm.TabIndex = 95
        Me.gd_nm.TableName = "ps_cd"
        Me.gd_nm.Title = "품명"
        Me.gd_nm.TitleWidth = 98
        Me.gd_nm.Visible = False
        '
        'FAC_CD
        '
        Me.FAC_CD.Location = New System.Drawing.Point(443, 173)
        Me.FAC_CD.Name = "FAC_CD"
        Me.FAC_CD.Size = New System.Drawing.Size(196, 21)
        Me.FAC_CD.TabIndex = 107
        Me.FAC_CD.Title = "공장"
        Me.FAC_CD.TitleWidth = 70
        '
        'pr_qty
        '
        Me.pr_qty.ColumnName = "ps_cd"
        Me.pr_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pr_qty.Location = New System.Drawing.Point(692, 126)
        Me.pr_qty.Name = "pr_qty"
        Me.pr_qty.Size = New System.Drawing.Size(201, 21)
        Me.pr_qty.TabIndex = 100
        Me.pr_qty.TableName = "ps_cd"
        Me.pr_qty.Title = "양품"
        Me.pr_qty.TitleWidth = 70
        '
        'wa_cd
        '
        Me.wa_cd.Location = New System.Drawing.Point(342, 126)
        Me.wa_cd.Name = "wa_cd"
        Me.wa_cd.Size = New System.Drawing.Size(297, 21)
        Me.wa_cd.TabIndex = 93
        Me.wa_cd.Title = "작업장"
        Me.wa_cd.TitleWidth = 98
        '
        'job_qty
        '
        Me.job_qty.ColumnName = "ps_cd"
        Me.job_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.job_qty.Location = New System.Drawing.Point(692, 78)
        Me.job_qty.Name = "job_qty"
        Me.job_qty.Size = New System.Drawing.Size(201, 21)
        Me.job_qty.TabIndex = 98
        Me.job_qty.TableName = "ps_cd"
        Me.job_qty.Title = "지시수량"
        Me.job_qty.TitleWidth = 70
        '
        'ng_qty
        '
        Me.ng_qty.ColumnName = "ps_cd"
        Me.ng_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ng_qty.Location = New System.Drawing.Point(918, 207)
        Me.ng_qty.Name = "ng_qty"
        Me.ng_qty.Size = New System.Drawing.Size(201, 21)
        Me.ng_qty.TabIndex = 101
        Me.ng_qty.TableName = "ps_cd"
        Me.ng_qty.Title = "불량"
        Me.ng_qty.TitleWidth = 70
        Me.ng_qty.Visible = False
        '
        'tot_qty
        '
        Me.tot_qty.ColumnName = "ps_cd"
        Me.tot_qty.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.tot_qty.Location = New System.Drawing.Point(692, 102)
        Me.tot_qty.Name = "tot_qty"
        Me.tot_qty.Size = New System.Drawing.Size(201, 21)
        Me.tot_qty.TabIndex = 99
        Me.tot_qty.TableName = "ps_cd"
        Me.tot_qty.Title = "생산수량"
        Me.tot_qty.TitleWidth = 70
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(1005, 380)
        Me.XtraTabControl1.TabIndex = 51
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.g_body)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(998, 350)
        Me.XtraTabPage1.Text = "투입 품목"
        '
        'g_body
        '
        Me.g_body.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body.Location = New System.Drawing.Point(0, 0)
        Me.g_body.Name = "g_body"
        Me.g_body.ReadOnly = False
        Me.g_body.RowHeight = -1
        Me.g_body.Size = New System.Drawing.Size(998, 350)
        Me.g_body.TabIndex = 0
        '
        'WI_PR1230
        '
        Me.Controls.Add(Me.spc_1)
        Me.Name = "WI_PR1230"
        Me.Size = New System.Drawing.Size(1383, 611)
        Me.Controls.SetChildIndex(Me.spc_1, 0)
        Me.spc_1.Panel1.ResumeLayout(False)
        Me.spc_1.Panel2.ResumeLayout(False)
        Me.spc_1.ResumeLayout(False)
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab1.ResumeLayout(False)
        Me.tp1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.tp2.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spc_1 As System.Windows.Forms.SplitContainer
    Friend WithEvents tab1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tp1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btn_cancel As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_find As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents find_visible As System.Windows.Forms.CheckBox
    Friend WithEvents find_to As Frame7.eDate
    Friend WithEvents find_from As Frame7.eDate
    Friend WithEvents find_gd_nm As Frame7.eText
    Friend WithEvents find_stts As Frame7.eCombo
    Friend WithEvents g_list As Frame7.eGrid
    Friend WithEvents tp2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents find_job_no2 As Frame7.eText
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents btn_cancel2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_find2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents find_visible2 As System.Windows.Forms.CheckBox
    Friend WithEvents find_to2 As Frame7.eDate
    Friend WithEvents find_from2 As Frame7.eDate
    Friend WithEvents find_gd_nm2 As Frame7.eText
    Friend WithEvents g_list2 As Frame7.eGrid
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents sa_cd As Frame7.eCombo
    Friend WithEvents mate_no As Frame7.eText
    Friend WithEvents gong_cd As Frame7.eCombo
    Friend WithEvents pr_no As Frame7.eText
    Friend WithEvents unit_cd As Frame7.eCombo
    Friend WithEvents new_gdcd As Frame7.eText
    Friend WithEvents new_gdnm As Frame7.eText
    Friend WithEvents pr_dt As Frame7.eDate
    Friend WithEvents job_no As Frame7.eText
    Friend WithEvents twh_cd As Frame7.eCombo
    Friend WithEvents new_spec As Frame7.eText
    Friend WithEvents from_dt As Frame7.eDate
    Friend WithEvents fwh_cd As Frame7.eCombo
    Friend WithEvents from_time As Frame7.eText
    Friend WithEvents pr_jobno As Frame7.eText
    Friend WithEvents job_seq As Frame7.eText
    Friend WithEvents to_time As Frame7.eText
    Friend WithEvents mc_cd As Frame7.eCombo
    Friend WithEvents lot_no As Frame7.eText
    Friend WithEvents ps_nm As Frame7.eText
    Friend WithEvents ps_cd As Frame7.eText
    Friend WithEvents gd_cd As Frame7.eText
    Friend WithEvents to_dt As Frame7.eDate
    Friend WithEvents spec As Frame7.eText
    Friend WithEvents gd_nm As Frame7.eText
    Friend WithEvents wa_cd As Frame7.eCombo
    Friend WithEvents pr_qty As Frame7.eText
    Friend WithEvents tot_qty As Frame7.eText
    Friend WithEvents job_qty As Frame7.eText
    Friend WithEvents ng_qty As Frame7.eText
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g_body As Frame7.eGrid
    Friend WithEvents stts As Frame7.eCombo
    Friend WithEvents MIC_print As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents FAC_CD As Frame7.eCombo
    Friend WithEvents Y_Day As Frame7.eText
    Friend WithEvents new_gdenm As Frame7.eText
    Friend WithEvents gd_enm As Frame7.eText
    Friend WithEvents print_qty As Frame7.eText
    Friend WithEvents db_print_qty As Frame7.eText

End Class
