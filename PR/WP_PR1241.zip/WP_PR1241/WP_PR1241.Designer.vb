﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WP_PR1241
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim XyDiagram1 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series1 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel1 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions1 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView1 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim Series2 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel2 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions2 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView2 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim PointSeriesLabel3 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim LineSeriesView3 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim ChartTitle1 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram2 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series3 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel4 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions3 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView4 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim Series4 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel5 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions4 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView5 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim PointSeriesLabel6 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim LineSeriesView6 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim ChartTitle2 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Dim XyDiagram3 As DevExpress.XtraCharts.XYDiagram = New DevExpress.XtraCharts.XYDiagram()
        Dim Series5 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel7 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions5 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView7 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim Series6 As DevExpress.XtraCharts.Series = New DevExpress.XtraCharts.Series()
        Dim PointSeriesLabel8 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim PointOptions6 As DevExpress.XtraCharts.PointOptions = New DevExpress.XtraCharts.PointOptions()
        Dim LineSeriesView8 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim PointSeriesLabel9 As DevExpress.XtraCharts.PointSeriesLabel = New DevExpress.XtraCharts.PointSeriesLabel()
        Dim LineSeriesView9 As DevExpress.XtraCharts.LineSeriesView = New DevExpress.XtraCharts.LineSeriesView()
        Dim ChartTitle3 As DevExpress.XtraCharts.ChartTitle = New DevExpress.XtraCharts.ChartTitle()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.find_nm_cd = New Frame7.eText()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.find_nm_nm = New Frame7.eText()
        Me.Fdt = New Frame7.eDate()
        Me.mc_cd = New Frame7.eCheckCombo()
        Me.inspec30 = New Frame7.eText()
        Me.outspec30 = New Frame7.eText()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer14 = New System.Windows.Forms.SplitContainer()
        Me.EPanel12 = New Frame7.ePanel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.chart2_2 = New DevExpress.XtraCharts.ChartControl()
        Me.EPanel13 = New Frame7.ePanel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.g20 = New Frame7.eGrid()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.chart2_3 = New DevExpress.XtraCharts.ChartControl()
        Me.chart2_4 = New DevExpress.XtraCharts.ChartControl()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SplitContainer14.Panel1.SuspendLayout()
        Me.SplitContainer14.Panel2.SuspendLayout()
        Me.SplitContainer14.SuspendLayout()
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel12.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.chart2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel13.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.chart2_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chart2_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(PointSeriesLabel9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(LineSeriesView9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.XtraTabControl1)
        Me.SplitContainer1.Size = New System.Drawing.Size(1182, 611)
        Me.SplitContainer1.SplitterDistance = 58
        Me.SplitContainer1.TabIndex = 1
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.find_nm_cd)
        Me.EPanel1.Controls.Add(Me.Label1)
        Me.EPanel1.Controls.Add(Me.find_nm_nm)
        Me.EPanel1.Controls.Add(Me.Fdt)
        Me.EPanel1.Controls.Add(Me.mc_cd)
        Me.EPanel1.Controls.Add(Me.inspec30)
        Me.EPanel1.Controls.Add(Me.outspec30)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(1182, 58)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     조회조건"
        '
        'find_nm_cd
        '
        Me.find_nm_cd.ColumnName = "job_no"
        Me.find_nm_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.find_nm_cd.Location = New System.Drawing.Point(273, 26)
        Me.find_nm_cd.Name = "find_nm_cd"
        Me.find_nm_cd.Size = New System.Drawing.Size(195, 21)
        Me.find_nm_cd.TabIndex = 112
        Me.find_nm_cd.TableName = "job_no"
        Me.find_nm_cd.Title = "제품명"
        Me.find_nm_cd.TitleWidth = 80
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 14)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        Me.Label1.Visible = False
        '
        'find_nm_nm
        '
        Me.find_nm_nm.ColumnName = "job_no"
        Me.find_nm_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.find_nm_nm.Location = New System.Drawing.Point(474, 26)
        Me.find_nm_nm.Name = "find_nm_nm"
        Me.find_nm_nm.Size = New System.Drawing.Size(193, 21)
        Me.find_nm_nm.TabIndex = 113
        Me.find_nm_nm.TableName = "job_no"
        Me.find_nm_nm.Title = "CHECK_SHEET NO."
        Me.find_nm_nm.TitleWidth = 0
        '
        'Fdt
        '
        Me.Fdt.Location = New System.Drawing.Point(8, 26)
        Me.Fdt.Name = "Fdt"
        Me.Fdt.Size = New System.Drawing.Size(240, 21)
        Me.Fdt.TabIndex = 2
        Me.Fdt.Title = "기준일자"
        '
        'mc_cd
        '
        Me.mc_cd.Location = New System.Drawing.Point(1007, 28)
        Me.mc_cd.Name = "mc_cd"
        Me.mc_cd.Size = New System.Drawing.Size(249, 21)
        Me.mc_cd.TabIndex = 12
        Me.mc_cd.Title = "제품군"
        '
        'inspec30
        '
        Me.inspec30.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.inspec30.Location = New System.Drawing.Point(695, 26)
        Me.inspec30.Name = "inspec30"
        Me.inspec30.Size = New System.Drawing.Size(170, 21)
        Me.inspec30.TabIndex = 9
        Me.inspec30.TitleWidth = 80
        '
        'outspec30
        '
        Me.outspec30.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.outspec30.Location = New System.Drawing.Point(792, 26)
        Me.outspec30.Name = "outspec30"
        Me.outspec30.Size = New System.Drawing.Size(170, 21)
        Me.outspec30.TabIndex = 10
        Me.outspec30.TitleWidth = 80
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage2
        Me.XtraTabControl1.Size = New System.Drawing.Size(1182, 549)
        Me.XtraTabControl1.TabIndex = 1
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage2})
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.SplitContainer14)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(1175, 519)
        Me.XtraTabPage2.Text = "사출샘플검사차트"
        '
        'SplitContainer14
        '
        Me.SplitContainer14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer14.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer14.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer14.Name = "SplitContainer14"
        Me.SplitContainer14.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer14.Panel1
        '
        Me.SplitContainer14.Panel1.Controls.Add(Me.EPanel12)
        '
        'SplitContainer14.Panel2
        '
        Me.SplitContainer14.Panel2.Controls.Add(Me.EPanel13)
        Me.SplitContainer14.Size = New System.Drawing.Size(1175, 519)
        Me.SplitContainer14.SplitterDistance = 367
        Me.SplitContainer14.TabIndex = 2
        '
        'EPanel12
        '
        Me.EPanel12.Controls.Add(Me.Panel11)
        Me.EPanel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel12.Location = New System.Drawing.Point(0, 0)
        Me.EPanel12.Name = "EPanel12"
        Me.EPanel12.Size = New System.Drawing.Size(1175, 367)
        Me.EPanel12.TabIndex = 1
        Me.EPanel12.Text = "     실적추이"
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.SplitContainer2)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(2, 23)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(1171, 342)
        Me.Panel11.TabIndex = 2
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.chart2_2)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(1171, 342)
        Me.SplitContainer2.SplitterDistance = 140
        Me.SplitContainer2.TabIndex = 0
        '
        'chart2_2
        '
        Me.chart2_2.AppearanceName = "Chameleon"
        XyDiagram1.AxisX.Label.Angle = -45
        XyDiagram1.AxisX.Label.Antialiasing = True
        XyDiagram1.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisX.Range.SideMarginsEnabled = True
        XyDiagram1.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram1.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram1.AxisY.NumericOptions.Precision = 1
        XyDiagram1.AxisY.Range.Auto = False
        XyDiagram1.AxisY.Range.MaxValueSerializable = "9"
        XyDiagram1.AxisY.Range.MinValueSerializable = "8"
        XyDiagram1.AxisY.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram1.AxisY.Range.SideMarginsEnabled = True
        XyDiagram1.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram1.EnableAxisXScrolling = True
        XyDiagram1.EnableAxisYScrolling = True
        Me.chart2_2.Diagram = XyDiagram1
        Me.chart2_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart2_2.EmptyChartText.Font = New System.Drawing.Font("맑은 고딕", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.chart2_2.EmptyChartText.Text = "조회할 데이터가 없습니다."
        Me.chart2_2.EmptyChartText.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_2.Location = New System.Drawing.Point(0, 0)
        Me.chart2_2.Name = "chart2_2"
        PointSeriesLabel1.LineVisible = True
        Series1.Label = PointSeriesLabel1
        Series1.Name = "Series 1"
        PointOptions1.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions1.ValueNumericOptions.Precision = 0
        Series1.PointOptions = PointOptions1
        Series1.View = LineSeriesView1
        PointSeriesLabel2.LineVisible = True
        Series2.Label = PointSeriesLabel2
        Series2.Name = "Series 2"
        PointOptions2.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions2.ValueNumericOptions.Precision = 0
        Series2.PointOptions = PointOptions2
        LineSeriesView2.LineMarkerOptions.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView2.LineMarkerOptions.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView2.LineMarkerOptions.FillStyle.FillMode = DevExpress.XtraCharts.FillMode.Solid
        LineSeriesView2.LineMarkerOptions.Kind = DevExpress.XtraCharts.MarkerKind.Hexagon
        LineSeriesView2.LineMarkerOptions.Size = 13
        Series2.View = LineSeriesView2
        Me.chart2_2.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series1, Series2}
        PointSeriesLabel3.LineVisible = True
        Me.chart2_2.SeriesTemplate.Label = PointSeriesLabel3
        Me.chart2_2.SeriesTemplate.View = LineSeriesView3
        Me.chart2_2.Size = New System.Drawing.Size(1171, 140)
        Me.chart2_2.TabIndex = 5
        ChartTitle1.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle1.Text = "B.C 현황"
        ChartTitle1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_2.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle1})
        '
        'EPanel13
        '
        Me.EPanel13.Controls.Add(Me.Panel12)
        Me.EPanel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel13.Location = New System.Drawing.Point(0, 0)
        Me.EPanel13.Name = "EPanel13"
        Me.EPanel13.Size = New System.Drawing.Size(1175, 148)
        Me.EPanel13.TabIndex = 0
        Me.EPanel13.Text = "     사출샘플검사현황"
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.g20)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel12.Location = New System.Drawing.Point(2, 23)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1171, 123)
        Me.Panel12.TabIndex = 2
        '
        'g20
        '
        Me.g20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g20.Location = New System.Drawing.Point(0, 0)
        Me.g20.Name = "g20"
        Me.g20.ReadOnly = False
        Me.g20.RecordNavigator = False
        Me.g20.RowHeight = -1
        Me.g20.Size = New System.Drawing.Size(1171, 123)
        Me.g20.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.chart2_3)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.chart2_4)
        Me.SplitContainer3.Size = New System.Drawing.Size(1171, 198)
        Me.SplitContainer3.SplitterDistance = 106
        Me.SplitContainer3.TabIndex = 0
        '
        'chart2_3
        '
        XyDiagram2.AxisX.Label.Angle = -45
        XyDiagram2.AxisX.Label.Antialiasing = True
        XyDiagram2.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram2.AxisX.Range.SideMarginsEnabled = True
        XyDiagram2.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram2.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram2.AxisY.NumericOptions.Precision = 1
        XyDiagram2.AxisY.Range.Auto = False
        XyDiagram2.AxisY.Range.MaxValueSerializable = "15"
        XyDiagram2.AxisY.Range.MinValueSerializable = "14"
        XyDiagram2.AxisY.Range.ScrollingRange.SideMarginsEnabled = False
        XyDiagram2.AxisY.Range.SideMarginsEnabled = True
        XyDiagram2.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram2.EnableAxisXScrolling = True
        XyDiagram2.EnableAxisYScrolling = True
        Me.chart2_3.Diagram = XyDiagram2
        Me.chart2_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart2_3.EmptyChartText.Font = New System.Drawing.Font("맑은 고딕", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.chart2_3.EmptyChartText.Text = "조회할 데이터가 없습니다."
        Me.chart2_3.EmptyChartText.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_3.Location = New System.Drawing.Point(0, 0)
        Me.chart2_3.Name = "chart2_3"
        Me.chart2_3.PaletteName = "Metro"
        PointSeriesLabel4.LineVisible = True
        Series3.Label = PointSeriesLabel4
        Series3.Name = "Series 1"
        PointOptions3.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions3.ValueNumericOptions.Precision = 0
        Series3.PointOptions = PointOptions3
        Series3.View = LineSeriesView4
        PointSeriesLabel5.LineVisible = True
        Series4.Label = PointSeriesLabel5
        Series4.Name = "Series 2"
        PointOptions4.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions4.ValueNumericOptions.Precision = 0
        Series4.PointOptions = PointOptions4
        LineSeriesView5.LineMarkerOptions.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView5.LineMarkerOptions.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView5.LineMarkerOptions.FillStyle.FillMode = DevExpress.XtraCharts.FillMode.Solid
        LineSeriesView5.LineMarkerOptions.Kind = DevExpress.XtraCharts.MarkerKind.Hexagon
        LineSeriesView5.LineMarkerOptions.Size = 13
        Series4.View = LineSeriesView5
        Me.chart2_3.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series3, Series4}
        PointSeriesLabel6.LineVisible = True
        Me.chart2_3.SeriesTemplate.Label = PointSeriesLabel6
        Me.chart2_3.SeriesTemplate.View = LineSeriesView6
        Me.chart2_3.Size = New System.Drawing.Size(1171, 106)
        Me.chart2_3.TabIndex = 7
        ChartTitle2.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle2.Text = "SIZE 현황"
        ChartTitle2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_3.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle2})
        '
        'chart2_4
        '
        XyDiagram3.AxisX.Label.Angle = -45
        XyDiagram3.AxisX.Label.Antialiasing = True
        XyDiagram3.AxisX.Range.ScrollingRange.SideMarginsEnabled = True
        XyDiagram3.AxisX.Range.SideMarginsEnabled = True
        XyDiagram3.AxisX.VisibleInPanesSerializable = "-1"
        XyDiagram3.AxisY.NumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        XyDiagram3.AxisY.NumericOptions.Precision = 1
        XyDiagram3.AxisY.Range.Auto = False
        XyDiagram3.AxisY.Range.MaxValueSerializable = "4"
        XyDiagram3.AxisY.Range.MinValueSerializable = "0"
        XyDiagram3.AxisY.Range.ScrollingRange.SideMarginsEnabled = False
        XyDiagram3.AxisY.Range.SideMarginsEnabled = True
        XyDiagram3.AxisY.VisibleInPanesSerializable = "-1"
        XyDiagram3.EnableAxisXScrolling = True
        XyDiagram3.EnableAxisYScrolling = True
        Me.chart2_4.Diagram = XyDiagram3
        Me.chart2_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chart2_4.EmptyChartText.Font = New System.Drawing.Font("맑은 고딕", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.chart2_4.EmptyChartText.Text = "조회할 데이터가 없습니다."
        Me.chart2_4.EmptyChartText.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_4.Location = New System.Drawing.Point(0, 0)
        Me.chart2_4.Name = "chart2_4"
        Me.chart2_4.PaletteName = "Metro"
        PointSeriesLabel7.LineVisible = True
        Series5.Label = PointSeriesLabel7
        Series5.Name = "Series 1"
        PointOptions5.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions5.ValueNumericOptions.Precision = 0
        Series5.PointOptions = PointOptions5
        Series5.View = LineSeriesView7
        PointSeriesLabel8.LineVisible = True
        Series6.Label = PointSeriesLabel8
        Series6.Name = "Series 2"
        PointOptions6.ValueNumericOptions.Format = DevExpress.XtraCharts.NumericFormat.Number
        PointOptions6.ValueNumericOptions.Precision = 0
        Series6.PointOptions = PointOptions6
        LineSeriesView8.LineMarkerOptions.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView8.LineMarkerOptions.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        LineSeriesView8.LineMarkerOptions.FillStyle.FillMode = DevExpress.XtraCharts.FillMode.Solid
        LineSeriesView8.LineMarkerOptions.Kind = DevExpress.XtraCharts.MarkerKind.Hexagon
        LineSeriesView8.LineMarkerOptions.Size = 13
        Series6.View = LineSeriesView8
        Me.chart2_4.SeriesSerializable = New DevExpress.XtraCharts.Series() {Series5, Series6}
        PointSeriesLabel9.LineVisible = True
        Me.chart2_4.SeriesTemplate.Label = PointSeriesLabel9
        Me.chart2_4.SeriesTemplate.View = LineSeriesView9
        Me.chart2_4.Size = New System.Drawing.Size(1171, 88)
        Me.chart2_4.TabIndex = 7
        ChartTitle3.Font = New System.Drawing.Font("맑은 고딕", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        ChartTitle3.Text = "C.T 현황"
        ChartTitle3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.chart2_4.Titles.AddRange(New DevExpress.XtraCharts.ChartTitle() {ChartTitle3})
        '
        'WP_PR1241
        '
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "WP_PR1241"
        Me.Size = New System.Drawing.Size(1182, 611)
        Me.Controls.SetChildIndex(Me.SplitContainer1, 0)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        Me.EPanel1.PerformLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.SplitContainer14.Panel1.ResumeLayout(False)
        Me.SplitContainer14.Panel2.ResumeLayout(False)
        Me.SplitContainer14.ResumeLayout(False)
        CType(Me.EPanel12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel12.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(XyDiagram1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EPanel13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel13.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(XyDiagram2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart2_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(XyDiagram3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Series6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(PointSeriesLabel9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(LineSeriesView9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart2_4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Fdt As Frame7.eDate
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer14 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel12 As Frame7.ePanel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents chart2_2 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents EPanel13 As Frame7.ePanel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents g20 As Frame7.eGrid
    Friend WithEvents inspec30 As Frame7.eText
    Friend WithEvents outspec30 As Frame7.eText
    Friend WithEvents CachedGAC120R1 As System7.CachedGAC120R
    Friend WithEvents mc_cd As Frame7.eCheckCombo
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents find_nm_nm As Frame7.eText
    Friend WithEvents find_nm_cd As Frame7.eText
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents chart2_3 As DevExpress.XtraCharts.ChartControl
    Friend WithEvents chart2_4 As DevExpress.XtraCharts.ChartControl
End Class
