﻿
Namespace DevExpress
    Class XtraCharts

    End Class
End Namespace
