﻿Imports Frame7
Imports Base7
Imports Base7.Shared

Public Class WP_PR3061

    Private Sub Me_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Open()
    End Sub

    Public Overrides Sub MenuButton_Click(ByVal mty As MenuType)
        Select Case mty
            'Case MenuType.Open
            '    New_Form()
            Case MenuType.Save

                If Me.Save() Then
                    Me.Open()
                    'New_Form()
                End If




            Case Else
                MyBase.MenuButton_Click(mty)
        End Select

    End Sub


  

    Private Sub g_result_CellValueChanged1(sender As Object, ColumnName As String, RowIndex As Integer, ByRef Value As Object) Handles g_result.CellValueChanged
        Select Case ColumnName
            Case "PACK_UNIT"
                If (IsNumeric(g_result.ToDec("PR_QTY", g_result.RowIndex)) = True) And IsNumeric(g_result.ToDec("PACK_UNIT", g_result.RowIndex)) = True Then

                    g_result.Text("PACK_QTY", g_result.RowIndex) = Fix(g_result.ToDec("PR_QTY", g_result.RowIndex) / g_result.ToDec("PACK_UNIT", g_result.RowIndex))
                    g_result.Text("PCS_QTY", g_result.RowIndex) = (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))
                    g_result.Text("MOD_QTY", g_result.RowIndex) = g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))
                End If
            Case "PACK_QTY"
                If (IsNumeric(g_result.ToDec("PR_QTY", g_result.RowIndex)) = True) And IsNumeric(g_result.ToDec("PACK_UNIT", g_result.RowIndex)) = True Then

                    g_result.Text("PCS_QTY", g_result.RowIndex) = (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))

                    If IsNumeric(g_result.ToDec("LOSS_QTY", g_result.RowIndex)) = True Then
                        g_result.Text("MOD_QTY", g_result.RowIndex) = (g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))) - g_result.ToDec("LOSS_QTY", g_result.RowIndex)
                    Else
                        g_result.Text("MOD_QTY", g_result.RowIndex) = g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))
                    End If


                End If
            Case "LOSS_QTY"
                If (IsNumeric(g_result.ToDec("PR_QTY", g_result.RowIndex)) = True) And IsNumeric(g_result.ToDec("PACK_UNIT", g_result.RowIndex)) = True And (IsNumeric(g_result.ToDec("LOSS_QTY", g_result.RowIndex)) = True) Then

                    g_result.Text("MOD_QTY", g_result.RowIndex) = (g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))) - g_result.ToDec("LOSS_QTY", g_result.RowIndex)

                End If
                '아래는 넣으면 무한반복
                'Case "MOD_QTY"

                '    If (IsNumeric(g_result.ToDec("PR_QTY", g_result.RowIndex)) = True) And IsNumeric(g_result.ToDec("PACK_UNIT", g_result.RowIndex)) = True Then

                '        If IsNumeric(g_result.ToDec("MOD_QTY", g_result.RowIndex)) = True Then
                '            g_result.Text("LOSS_QTY", g_result.RowIndex) = (g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))) - g_result.ToDec("MOD_QTY", g_result.RowIndex)
                '        Else
                '            g_result.Text("LOSS_QTY", g_result.RowIndex) = g_result.ToDec("PR_QTY", g_result.RowIndex) - (g_result.ToDec("PACK_QTY", g_result.RowIndex) * g_result.ToDec("PACK_UNIT", g_result.RowIndex))
                '        End If


                '    End If


        End Select
    End Sub
End Class
