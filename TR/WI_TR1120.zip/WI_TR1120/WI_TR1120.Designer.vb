﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WI_TR1120
    Inherits Base7.Form

    'UserControl1은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(WI_TR1120))
        Me.spc_1 = New System.Windows.Forms.SplitContainer()
        Me.tab1 = New DevExpress.XtraTab.XtraTabControl()
        Me.tp1 = New DevExpress.XtraTab.XtraTabPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.find_odgu_cd = New Frame7.eCombo()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_cancel = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_find = New DevExpress.XtraEditors.SimpleButton()
        Me.find_visible = New System.Windows.Forms.CheckBox()
        Me.find_from = New Frame7.eDate()
        Me.find_cs_nm = New Frame7.eText()
        Me.find_to = New Frame7.eDate()
        Me.find_stts = New Frame7.eOptionBox()
        Me.find_od_no = New Frame7.eText()
        Me.g_list = New Frame7.eGrid()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer()
        Me.ep_head = New Frame7.ePanel()
        Me.EPanel4 = New Frame7.ePanel()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.XtraTabPage1 = New DevExpress.XtraTab.XtraTabPage()
        Me.remk = New Frame7.eMemo()
        Me.XtraTabPage2 = New DevExpress.XtraTab.XtraTabPage()
        Me.g10 = New Frame7.eGrid()
        Me.initi = New Frame7.eText()
        Me.ECheck2 = New Frame7.eCheck()
        Me.addr_deli = New Frame7.eText()
        Me.but2_prt = New DevExpress.XtraEditors.SimpleButton()
        Me.ship_nm = New Frame7.eText()
        Me.ECheck1 = New Frame7.eCheck()
        Me.odgu_cd = New Frame7.eCombo()
        Me.REMARKS = New Frame7.eText()
        Me.cur_cd = New Frame7.eCombo()
        Me.bk_type = New Frame7.eCombo()
        Me.sa_cd = New Frame7.eCombo()
        Me.temp_nm_cd = New Frame7.eText()
        Me.but1_prt = New DevExpress.XtraEditors.SimpleButton()
        Me.but_work = New DevExpress.XtraEditors.SimpleButton()
        Me.stts1 = New Frame7.eCombo()
        Me.commission = New Frame7.eText()
        Me.deli_date = New Frame7.eDate()
        Me.pay_cd = New Frame7.eCombo()
        Me.payterm_cd = New Frame7.eCombo()
        Me.ship_by = New Frame7.eCombo()
        Me.od_dt = New Frame7.eDate()
        Me.nacs_addr = New Frame7.eText()
        Me.price_cd = New Frame7.eCombo()
        Me.btn_bom = New DevExpress.XtraEditors.SimpleButton()
        Me.dam_nm = New Frame7.eText()
        Me.deli_place = New Frame7.eText()
        Me.cs_cd = New Frame7.eText()
        Me.SHIPPING_PORT = New Frame7.eText()
        Me.od_amt = New Frame7.eText()
        Me.po_no = New Frame7.eText()
        Me.pl_cd = New Frame7.eText()
        Me.nacs_cd = New Frame7.eText()
        Me.cs_nm = New Frame7.eText()
        Me.pl_nm = New Frame7.eText()
        Me.SHIPPING_CORPORATION = New Frame7.eText()
        Me.od_no = New Frame7.eText()
        Me.ps_nm = New Frame7.eText()
        Me.ps_cd = New Frame7.eText()
        Me.nacs_nm = New Frame7.eText()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.EPanel1 = New Frame7.ePanel()
        Me.g_body = New Frame7.eGrid()
        Me.EPanel2 = New Frame7.ePanel()
        Me.SplitContainer6 = New System.Windows.Forms.SplitContainer()
        Me.g_body_01 = New Frame7.eGrid()
        Me.img = New Frame7.eImage()
        Me.btn_pic = New DevExpress.XtraEditors.SimpleButton()
        Me.EPanel3 = New Frame7.ePanel()
        Me.g_body2 = New Frame7.eGrid()
        Me.spc_1.Panel1.SuspendLayout()
        Me.spc_1.Panel2.SuspendLayout()
        Me.spc_1.SuspendLayout()
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab1.SuspendLayout()
        Me.tp1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        CType(Me.ep_head, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ep_head.SuspendLayout()
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel4.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.XtraTabPage1.SuspendLayout()
        Me.XtraTabPage2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel1.SuspendLayout()
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel2.SuspendLayout()
        Me.SplitContainer6.Panel1.SuspendLayout()
        Me.SplitContainer6.Panel2.SuspendLayout()
        Me.SplitContainer6.SuspendLayout()
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'spc_1
        '
        Me.spc_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spc_1.Location = New System.Drawing.Point(0, 0)
        Me.spc_1.Name = "spc_1"
        '
        'spc_1.Panel1
        '
        Me.spc_1.Panel1.Controls.Add(Me.tab1)
        '
        'spc_1.Panel2
        '
        Me.spc_1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.spc_1.Size = New System.Drawing.Size(1906, 687)
        Me.spc_1.SplitterDistance = 484
        Me.spc_1.TabIndex = 3
        '
        'tab1
        '
        Me.tab1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tab1.Location = New System.Drawing.Point(0, 0)
        Me.tab1.Name = "tab1"
        Me.tab1.SelectedTabPage = Me.tp1
        Me.tab1.Size = New System.Drawing.Size(484, 687)
        Me.tab1.TabIndex = 50
        Me.tab1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tp1})
        '
        'tp1
        '
        Me.tp1.Controls.Add(Me.SplitContainer1)
        Me.tp1.Name = "tp1"
        Me.tp1.Size = New System.Drawing.Size(477, 657)
        Me.tp1.Text = "검색 조건"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.g_list)
        Me.SplitContainer1.Size = New System.Drawing.Size(477, 657)
        Me.SplitContainer1.SplitterDistance = 214
        Me.SplitContainer1.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.find_odgu_cd)
        Me.Panel2.Controls.Add(Me.Panel1)
        Me.Panel2.Controls.Add(Me.find_from)
        Me.Panel2.Controls.Add(Me.find_cs_nm)
        Me.Panel2.Controls.Add(Me.find_to)
        Me.Panel2.Controls.Add(Me.find_stts)
        Me.Panel2.Controls.Add(Me.find_od_no)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(477, 214)
        Me.Panel2.TabIndex = 0
        '
        'find_odgu_cd
        '
        Me.find_odgu_cd.Location = New System.Drawing.Point(11, 94)
        Me.find_odgu_cd.Name = "find_odgu_cd"
        Me.find_odgu_cd.Size = New System.Drawing.Size(331, 21)
        Me.find_odgu_cd.TabIndex = 103
        Me.find_odgu_cd.Title = "거래유형"
        Me.find_odgu_cd.TitleWidth = 98
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.btn_cancel)
        Me.Panel1.Controls.Add(Me.btn_find)
        Me.Panel1.Controls.Add(Me.find_visible)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 173)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(477, 41)
        Me.Panel1.TabIndex = 2
        '
        'btn_cancel
        '
        Me.btn_cancel.Location = New System.Drawing.Point(98, 6)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(72, 27)
        Me.btn_cancel.TabIndex = 72
        Me.btn_cancel.Text = "취   소"
        '
        'btn_find
        '
        Me.btn_find.Location = New System.Drawing.Point(10, 6)
        Me.btn_find.Name = "btn_find"
        Me.btn_find.Size = New System.Drawing.Size(72, 27)
        Me.btn_find.TabIndex = 71
        Me.btn_find.Text = "검   색"
        '
        'find_visible
        '
        Me.find_visible.AutoSize = True
        Me.find_visible.Checked = True
        Me.find_visible.CheckState = System.Windows.Forms.CheckState.Checked
        Me.find_visible.Dock = System.Windows.Forms.DockStyle.Right
        Me.find_visible.Location = New System.Drawing.Point(383, 0)
        Me.find_visible.Name = "find_visible"
        Me.find_visible.Size = New System.Drawing.Size(92, 39)
        Me.find_visible.TabIndex = 48
        Me.find_visible.Text = "선택 후 숨김"
        Me.find_visible.UseVisualStyleBackColor = True
        '
        'find_from
        '
        Me.find_from.Location = New System.Drawing.Point(11, 16)
        Me.find_from.Name = "find_from"
        Me.find_from.Size = New System.Drawing.Size(198, 21)
        Me.find_from.TabIndex = 97
        Me.find_from.Title = "기간"
        Me.find_from.TitleWidth = 98
        '
        'find_cs_nm
        '
        Me.find_cs_nm.Location = New System.Drawing.Point(11, 42)
        Me.find_cs_nm.Name = "find_cs_nm"
        Me.find_cs_nm.Size = New System.Drawing.Size(331, 21)
        Me.find_cs_nm.TabIndex = 100
        Me.find_cs_nm.Title = "거래처"
        Me.find_cs_nm.TitleWidth = 98
        '
        'find_to
        '
        Me.find_to.Location = New System.Drawing.Point(242, 16)
        Me.find_to.Name = "find_to"
        Me.find_to.Size = New System.Drawing.Size(100, 21)
        Me.find_to.TabIndex = 98
        Me.find_to.Title = "기간"
        Me.find_to.TitleWidth = 0
        '
        'find_stts
        '
        Me.find_stts.Location = New System.Drawing.Point(11, 120)
        Me.find_stts.Name = "find_stts"
        Me.find_stts.SelectedIndex = -1
        Me.find_stts.Size = New System.Drawing.Size(331, 22)
        Me.find_stts.TabIndex = 102
        Me.find_stts.Title = "상태"
        Me.find_stts.TitleWidth = 98
        '
        'find_od_no
        '
        Me.find_od_no.Location = New System.Drawing.Point(11, 68)
        Me.find_od_no.Name = "find_od_no"
        Me.find_od_no.Size = New System.Drawing.Size(331, 21)
        Me.find_od_no.TabIndex = 101
        Me.find_od_no.Title = "수주번호"
        Me.find_od_no.TitleWidth = 98
        '
        'g_list
        '
        Me.g_list.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_list.Location = New System.Drawing.Point(0, 0)
        Me.g_list.Name = "g_list"
        Me.g_list.ReadOnly = False
        Me.g_list.RowHeight = -1
        Me.g_list.Size = New System.Drawing.Size(477, 439)
        Me.g_list.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer5)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(1418, 687)
        Me.SplitContainer2.SplitterDistance = 198
        Me.SplitContainer2.TabIndex = 0
        '
        'SplitContainer5
        '
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.ep_head)
        Me.SplitContainer5.Size = New System.Drawing.Size(1418, 198)
        Me.SplitContainer5.SplitterDistance = 1233
        Me.SplitContainer5.TabIndex = 0
        '
        'ep_head
        '
        Me.ep_head.Controls.Add(Me.EPanel4)
        Me.ep_head.Controls.Add(Me.initi)
        Me.ep_head.Controls.Add(Me.ECheck2)
        Me.ep_head.Controls.Add(Me.addr_deli)
        Me.ep_head.Controls.Add(Me.but2_prt)
        Me.ep_head.Controls.Add(Me.ship_nm)
        Me.ep_head.Controls.Add(Me.ECheck1)
        Me.ep_head.Controls.Add(Me.odgu_cd)
        Me.ep_head.Controls.Add(Me.REMARKS)
        Me.ep_head.Controls.Add(Me.cur_cd)
        Me.ep_head.Controls.Add(Me.bk_type)
        Me.ep_head.Controls.Add(Me.sa_cd)
        Me.ep_head.Controls.Add(Me.temp_nm_cd)
        Me.ep_head.Controls.Add(Me.but1_prt)
        Me.ep_head.Controls.Add(Me.but_work)
        Me.ep_head.Controls.Add(Me.stts1)
        Me.ep_head.Controls.Add(Me.commission)
        Me.ep_head.Controls.Add(Me.deli_date)
        Me.ep_head.Controls.Add(Me.pay_cd)
        Me.ep_head.Controls.Add(Me.payterm_cd)
        Me.ep_head.Controls.Add(Me.ship_by)
        Me.ep_head.Controls.Add(Me.od_dt)
        Me.ep_head.Controls.Add(Me.nacs_addr)
        Me.ep_head.Controls.Add(Me.price_cd)
        Me.ep_head.Controls.Add(Me.btn_bom)
        Me.ep_head.Controls.Add(Me.dam_nm)
        Me.ep_head.Controls.Add(Me.deli_place)
        Me.ep_head.Controls.Add(Me.cs_cd)
        Me.ep_head.Controls.Add(Me.SHIPPING_PORT)
        Me.ep_head.Controls.Add(Me.od_amt)
        Me.ep_head.Controls.Add(Me.po_no)
        Me.ep_head.Controls.Add(Me.pl_cd)
        Me.ep_head.Controls.Add(Me.nacs_cd)
        Me.ep_head.Controls.Add(Me.cs_nm)
        Me.ep_head.Controls.Add(Me.pl_nm)
        Me.ep_head.Controls.Add(Me.SHIPPING_CORPORATION)
        Me.ep_head.Controls.Add(Me.od_no)
        Me.ep_head.Controls.Add(Me.ps_nm)
        Me.ep_head.Controls.Add(Me.ps_cd)
        Me.ep_head.Controls.Add(Me.nacs_nm)
        Me.ep_head.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ep_head.Location = New System.Drawing.Point(0, 0)
        Me.ep_head.Name = "ep_head"
        Me.ep_head.Size = New System.Drawing.Size(1233, 198)
        Me.ep_head.TabIndex = 0
        Me.ep_head.Text = "     수주등록"
        '
        'EPanel4
        '
        Me.EPanel4.Controls.Add(Me.XtraTabControl1)
        Me.EPanel4.Location = New System.Drawing.Point(1026, 24)
        Me.EPanel4.Name = "EPanel4"
        Me.EPanel4.Size = New System.Drawing.Size(442, 198)
        Me.EPanel4.TabIndex = 0
        Me.EPanel4.Text = "     특기사항"
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(2, 23)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.XtraTabPage1
        Me.XtraTabControl1.Size = New System.Drawing.Size(438, 173)
        Me.XtraTabControl1.TabIndex = 3
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.XtraTabPage1, Me.XtraTabPage2})
        '
        'XtraTabPage1
        '
        Me.XtraTabPage1.Controls.Add(Me.remk)
        Me.XtraTabPage1.Name = "XtraTabPage1"
        Me.XtraTabPage1.Size = New System.Drawing.Size(431, 143)
        Me.XtraTabPage1.Text = "특기사항"
        '
        'remk
        '
        Me.remk.Dock = System.Windows.Forms.DockStyle.Fill
        Me.remk.Location = New System.Drawing.Point(0, 0)
        Me.remk.Name = "remk"
        Me.remk.Size = New System.Drawing.Size(431, 143)
        Me.remk.TabIndex = 0
        Me.remk.TitleWidth = 0
        '
        'XtraTabPage2
        '
        Me.XtraTabPage2.Controls.Add(Me.g10)
        Me.XtraTabPage2.Name = "XtraTabPage2"
        Me.XtraTabPage2.Size = New System.Drawing.Size(431, 143)
        Me.XtraTabPage2.Text = "첨부파일"
        '
        'g10
        '
        Me.g10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g10.Location = New System.Drawing.Point(0, 0)
        Me.g10.Name = "g10"
        Me.g10.ReadOnly = False
        Me.g10.RecordNavigator = False
        Me.g10.RowHeight = -1
        Me.g10.Size = New System.Drawing.Size(431, 143)
        Me.g10.TabIndex = 0
        '
        'initi
        '
        Me.initi.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.initi.Location = New System.Drawing.Point(904, 144)
        Me.initi.Name = "initi"
        Me.initi.Size = New System.Drawing.Size(116, 21)
        Me.initi.TabIndex = 22
        Me.initi.Title = "이니셜정보"
        Me.initi.TitleWidth = 0
        '
        'ECheck2
        '
        Me.ECheck2.Caption = ""
        Me.ECheck2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ECheck2.Location = New System.Drawing.Point(904, 120)
        Me.ECheck2.Name = "ECheck2"
        Me.ECheck2.Size = New System.Drawing.Size(116, 21)
        Me.ECheck2.TabIndex = 145
        Me.ECheck2.Title = "이니셜정보"
        '
        'addr_deli
        '
        Me.addr_deli.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.addr_deli.Location = New System.Drawing.Point(407, 224)
        Me.addr_deli.Name = "addr_deli"
        Me.addr_deli.Size = New System.Drawing.Size(18, 21)
        Me.addr_deli.TabIndex = 138
        Me.addr_deli.TitleWidth = 0
        '
        'but2_prt
        '
        Me.but2_prt.Location = New System.Drawing.Point(904, 48)
        Me.but2_prt.Name = "but2_prt"
        Me.but2_prt.Size = New System.Drawing.Size(116, 21)
        Me.but2_prt.TabIndex = 143
        Me.but2_prt.Text = "Proforma invoice"
        '
        'ship_nm
        '
        Me.ship_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ship_nm.Location = New System.Drawing.Point(14, 224)
        Me.ship_nm.Name = "ship_nm"
        Me.ship_nm.Size = New System.Drawing.Size(395, 21)
        Me.ship_nm.TabIndex = 137
        Me.ship_nm.Title = "배송지"
        Me.ship_nm.TitleWidth = 98
        '
        'ECheck1
        '
        Me.ECheck1.Caption = ""
        Me.ECheck1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ECheck1.Location = New System.Drawing.Point(904, 72)
        Me.ECheck1.Name = "ECheck1"
        Me.ECheck1.Size = New System.Drawing.Size(116, 21)
        Me.ECheck1.TabIndex = 116
        Me.ECheck1.Title = "은행정보"
        '
        'odgu_cd
        '
        Me.odgu_cd.Location = New System.Drawing.Point(698, 98)
        Me.odgu_cd.Name = "odgu_cd"
        Me.odgu_cd.Size = New System.Drawing.Size(199, 21)
        Me.odgu_cd.TabIndex = 17
        Me.odgu_cd.Title = "거래유형"
        Me.odgu_cd.TitleWidth = 80
        '
        'REMARKS
        '
        Me.REMARKS.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.REMARKS.Location = New System.Drawing.Point(169, 290)
        Me.REMARKS.Name = "REMARKS"
        Me.REMARKS.Size = New System.Drawing.Size(411, 21)
        Me.REMARKS.TabIndex = 134
        Me.REMARKS.Title = "Remarks"
        Me.REMARKS.TitleWidth = 98
        '
        'cur_cd
        '
        Me.cur_cd.Location = New System.Drawing.Point(442, 50)
        Me.cur_cd.Name = "cur_cd"
        Me.cur_cd.Size = New System.Drawing.Size(230, 21)
        Me.cur_cd.TabIndex = 8
        Me.cur_cd.Title = "화폐"
        Me.cur_cd.TitleWidth = 70
        '
        'bk_type
        '
        Me.bk_type.Location = New System.Drawing.Point(904, 96)
        Me.bk_type.Name = "bk_type"
        Me.bk_type.Size = New System.Drawing.Size(116, 21)
        Me.bk_type.TabIndex = 21
        Me.bk_type.TitleWidth = 0
        '
        'sa_cd
        '
        Me.sa_cd.Location = New System.Drawing.Point(698, 74)
        Me.sa_cd.Name = "sa_cd"
        Me.sa_cd.Size = New System.Drawing.Size(199, 21)
        Me.sa_cd.TabIndex = 16
        Me.sa_cd.Title = "사업장"
        Me.sa_cd.TitleWidth = 80
        '
        'temp_nm_cd
        '
        Me.temp_nm_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.temp_nm_cd.Location = New System.Drawing.Point(756, 220)
        Me.temp_nm_cd.Name = "temp_nm_cd"
        Me.temp_nm_cd.Size = New System.Drawing.Size(117, 21)
        Me.temp_nm_cd.TabIndex = 140
        Me.temp_nm_cd.Title = "od_no"
        Me.temp_nm_cd.TitleWidth = 98
        '
        'but1_prt
        '
        Me.but1_prt.Location = New System.Drawing.Point(904, 24)
        Me.but1_prt.Name = "but1_prt"
        Me.but1_prt.Size = New System.Drawing.Size(116, 21)
        Me.but1_prt.TabIndex = 142
        Me.but1_prt.Text = "수출통보서"
        '
        'but_work
        '
        Me.but_work.Location = New System.Drawing.Point(284, 24)
        Me.but_work.Name = "but_work"
        Me.but_work.Size = New System.Drawing.Size(120, 23)
        Me.but_work.TabIndex = 141
        Me.but_work.Text = "복사"
        '
        'stts1
        '
        Me.stts1.Location = New System.Drawing.Point(698, 50)
        Me.stts1.Name = "stts1"
        Me.stts1.Size = New System.Drawing.Size(199, 21)
        Me.stts1.TabIndex = 15
        Me.stts1.Title = "상태"
        Me.stts1.TitleWidth = 80
        '
        'commission
        '
        Me.commission.ColumnName = "find_paymentterm_nm"
        Me.commission.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.commission.Location = New System.Drawing.Point(791, 252)
        Me.commission.Name = "commission"
        Me.commission.Size = New System.Drawing.Size(199, 21)
        Me.commission.TabIndex = 117
        Me.commission.TableName = "find_paymentterm_nm"
        Me.commission.Title = "commission"
        Me.commission.TitleWidth = 80
        Me.commission.Visible = False
        '
        'deli_date
        '
        Me.deli_date.Location = New System.Drawing.Point(698, 122)
        Me.deli_date.Name = "deli_date"
        Me.deli_date.Size = New System.Drawing.Size(199, 21)
        Me.deli_date.TabIndex = 18
        Me.deli_date.Title = "deli_date"
        Me.deli_date.TitleWidth = 80
        '
        'pay_cd
        '
        Me.pay_cd.Location = New System.Drawing.Point(442, 122)
        Me.pay_cd.Name = "pay_cd"
        Me.pay_cd.Size = New System.Drawing.Size(230, 21)
        Me.pay_cd.TabIndex = 11
        Me.pay_cd.Title = "결제방법"
        Me.pay_cd.TitleWidth = 70
        '
        'payterm_cd
        '
        Me.payterm_cd.Location = New System.Drawing.Point(441, 146)
        Me.payterm_cd.Name = "payterm_cd"
        Me.payterm_cd.Size = New System.Drawing.Size(230, 21)
        Me.payterm_cd.TabIndex = 12
        Me.payterm_cd.Title = "결제조건"
        Me.payterm_cd.TitleWidth = 70
        '
        'ship_by
        '
        Me.ship_by.Location = New System.Drawing.Point(441, 170)
        Me.ship_by.Name = "ship_by"
        Me.ship_by.Size = New System.Drawing.Size(230, 21)
        Me.ship_by.TabIndex = 13
        Me.ship_by.Title = "선적방법"
        Me.ship_by.TitleWidth = 70
        '
        'od_dt
        '
        Me.od_dt.Location = New System.Drawing.Point(698, 26)
        Me.od_dt.Name = "od_dt"
        Me.od_dt.Size = New System.Drawing.Size(199, 21)
        Me.od_dt.TabIndex = 14
        Me.od_dt.Title = "od_dt"
        Me.od_dt.TitleWidth = 80
        '
        'nacs_addr
        '
        Me.nacs_addr.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.nacs_addr.Location = New System.Drawing.Point(14, 98)
        Me.nacs_addr.Name = "nacs_addr"
        Me.nacs_addr.Size = New System.Drawing.Size(411, 21)
        Me.nacs_addr.TabIndex = 120
        Me.nacs_addr.Title = "주소"
        Me.nacs_addr.TitleWidth = 98
        '
        'price_cd
        '
        Me.price_cd.Location = New System.Drawing.Point(442, 98)
        Me.price_cd.Name = "price_cd"
        Me.price_cd.Size = New System.Drawing.Size(230, 21)
        Me.price_cd.TabIndex = 10
        Me.price_cd.Title = "가격조건"
        Me.price_cd.TitleWidth = 70
        '
        'btn_bom
        '
        Me.btn_bom.Location = New System.Drawing.Point(880, 224)
        Me.btn_bom.Name = "btn_bom"
        Me.btn_bom.Size = New System.Drawing.Size(114, 21)
        Me.btn_bom.TabIndex = 136
        Me.btn_bom.Text = "BOM 생성"
        '
        'dam_nm
        '
        Me.dam_nm.ColumnName = "find_paymentterm_nm"
        Me.dam_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.dam_nm.Location = New System.Drawing.Point(442, 74)
        Me.dam_nm.Name = "dam_nm"
        Me.dam_nm.Size = New System.Drawing.Size(230, 21)
        Me.dam_nm.TabIndex = 9
        Me.dam_nm.TableName = "find_paymentterm_nm"
        Me.dam_nm.Title = "영업담당자"
        Me.dam_nm.TitleWidth = 70
        '
        'deli_place
        '
        Me.deli_place.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.deli_place.Location = New System.Drawing.Point(14, 170)
        Me.deli_place.Name = "deli_place"
        Me.deli_place.Size = New System.Drawing.Size(411, 21)
        Me.deli_place.TabIndex = 6
        Me.deli_place.Title = "deli_place"
        Me.deli_place.TitleWidth = 98
        '
        'cs_cd
        '
        Me.cs_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.cs_cd.Location = New System.Drawing.Point(14, 50)
        Me.cs_cd.Name = "cs_cd"
        Me.cs_cd.Size = New System.Drawing.Size(180, 21)
        Me.cs_cd.TabIndex = 1
        Me.cs_cd.Title = "거래처"
        Me.cs_cd.TitleWidth = 98
        '
        'SHIPPING_PORT
        '
        Me.SHIPPING_PORT.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.SHIPPING_PORT.Location = New System.Drawing.Point(14, 146)
        Me.SHIPPING_PORT.Name = "SHIPPING_PORT"
        Me.SHIPPING_PORT.Size = New System.Drawing.Size(411, 21)
        Me.SHIPPING_PORT.TabIndex = 5
        Me.SHIPPING_PORT.Title = "선적장소"
        Me.SHIPPING_PORT.TitleWidth = 98
        '
        'od_amt
        '
        Me.od_amt.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.od_amt.Location = New System.Drawing.Point(698, 170)
        Me.od_amt.Name = "od_amt"
        Me.od_amt.Size = New System.Drawing.Size(199, 21)
        Me.od_amt.TabIndex = 20
        Me.od_amt.Title = "수주금액"
        Me.od_amt.TitleWidth = 80
        '
        'po_no
        '
        Me.po_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.po_no.Location = New System.Drawing.Point(698, 145)
        Me.po_no.Name = "po_no"
        Me.po_no.Size = New System.Drawing.Size(199, 21)
        Me.po_no.TabIndex = 19
        Me.po_no.Title = "고객p/o"
        Me.po_no.TitleWidth = 80
        '
        'pl_cd
        '
        Me.pl_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pl_cd.Location = New System.Drawing.Point(466, 267)
        Me.pl_cd.Name = "pl_cd"
        Me.pl_cd.Size = New System.Drawing.Size(188, 21)
        Me.pl_cd.TabIndex = 106
        Me.pl_cd.Title = "부서"
        Me.pl_cd.TitleWidth = 98
        Me.pl_cd.Visible = False
        '
        'nacs_cd
        '
        Me.nacs_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.nacs_cd.Location = New System.Drawing.Point(14, 74)
        Me.nacs_cd.Name = "nacs_cd"
        Me.nacs_cd.Size = New System.Drawing.Size(180, 21)
        Me.nacs_cd.TabIndex = 2
        Me.nacs_cd.Title = "납품처"
        Me.nacs_cd.TitleWidth = 98
        '
        'cs_nm
        '
        Me.cs_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.cs_nm.Location = New System.Drawing.Point(200, 50)
        Me.cs_nm.Name = "cs_nm"
        Me.cs_nm.Size = New System.Drawing.Size(225, 21)
        Me.cs_nm.TabIndex = 110
        Me.cs_nm.Title = "nacs_nm"
        Me.cs_nm.TitleWidth = 0
        '
        'pl_nm
        '
        Me.pl_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.pl_nm.Location = New System.Drawing.Point(660, 252)
        Me.pl_nm.Name = "pl_nm"
        Me.pl_nm.Size = New System.Drawing.Size(210, 21)
        Me.pl_nm.TabIndex = 105
        Me.pl_nm.Title = "pl_cd"
        Me.pl_nm.TitleWidth = 98
        '
        'SHIPPING_CORPORATION
        '
        Me.SHIPPING_CORPORATION.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.SHIPPING_CORPORATION.Location = New System.Drawing.Point(14, 122)
        Me.SHIPPING_CORPORATION.Name = "SHIPPING_CORPORATION"
        Me.SHIPPING_CORPORATION.Size = New System.Drawing.Size(411, 21)
        Me.SHIPPING_CORPORATION.TabIndex = 4
        Me.SHIPPING_CORPORATION.Title = "선적회사"
        Me.SHIPPING_CORPORATION.TitleWidth = 98
        '
        'od_no
        '
        Me.od_no.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.od_no.Location = New System.Drawing.Point(14, 26)
        Me.od_no.Name = "od_no"
        Me.od_no.Size = New System.Drawing.Size(258, 21)
        Me.od_no.TabIndex = 0
        Me.od_no.Title = "od_no"
        Me.od_no.TitleWidth = 98
        '
        'ps_nm
        '
        Me.ps_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ps_nm.Location = New System.Drawing.Point(582, 26)
        Me.ps_nm.Name = "ps_nm"
        Me.ps_nm.Size = New System.Drawing.Size(89, 21)
        Me.ps_nm.TabIndex = 104
        Me.ps_nm.Title = "ps_nm"
        Me.ps_nm.TitleWidth = 0
        '
        'ps_cd
        '
        Me.ps_cd.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.ps_cd.Location = New System.Drawing.Point(442, 26)
        Me.ps_cd.Name = "ps_cd"
        Me.ps_cd.Size = New System.Drawing.Size(138, 21)
        Me.ps_cd.TabIndex = 7
        Me.ps_cd.Title = "작성자"
        Me.ps_cd.TitleWidth = 70
        Me.ps_cd.Visible = False
        '
        'nacs_nm
        '
        Me.nacs_nm.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.nacs_nm.Location = New System.Drawing.Point(200, 74)
        Me.nacs_nm.Name = "nacs_nm"
        Me.nacs_nm.Size = New System.Drawing.Size(225, 21)
        Me.nacs_nm.TabIndex = 108
        Me.nacs_nm.Title = "nacs_nm"
        Me.nacs_nm.TitleWidth = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.SplitContainer4)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.EPanel3)
        Me.SplitContainer3.Size = New System.Drawing.Size(1418, 485)
        Me.SplitContainer3.SplitterDistance = 897
        Me.SplitContainer3.TabIndex = 1
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        Me.SplitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.EPanel1)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.EPanel2)
        Me.SplitContainer4.Size = New System.Drawing.Size(897, 485)
        Me.SplitContainer4.SplitterDistance = 286
        Me.SplitContainer4.TabIndex = 0
        '
        'EPanel1
        '
        Me.EPanel1.Controls.Add(Me.g_body)
        Me.EPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel1.Location = New System.Drawing.Point(0, 0)
        Me.EPanel1.Name = "EPanel1"
        Me.EPanel1.Size = New System.Drawing.Size(897, 286)
        Me.EPanel1.TabIndex = 0
        Me.EPanel1.Text = "     제품 리스트"
        '
        'g_body
        '
        Me.g_body.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body.Location = New System.Drawing.Point(2, 23)
        Me.g_body.Name = "g_body"
        Me.g_body.ReadOnly = False
        Me.g_body.RowHeight = -1
        Me.g_body.Size = New System.Drawing.Size(893, 261)
        Me.g_body.TabIndex = 2
        '
        'EPanel2
        '
        Me.EPanel2.Controls.Add(Me.SplitContainer6)
        Me.EPanel2.Controls.Add(Me.btn_pic)
        Me.EPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel2.Location = New System.Drawing.Point(0, 0)
        Me.EPanel2.Name = "EPanel2"
        Me.EPanel2.Size = New System.Drawing.Size(897, 195)
        Me.EPanel2.TabIndex = 0
        Me.EPanel2.Text = "     포장재 리스트"
        '
        'SplitContainer6
        '
        Me.SplitContainer6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer6.Location = New System.Drawing.Point(2, 23)
        Me.SplitContainer6.Name = "SplitContainer6"
        '
        'SplitContainer6.Panel1
        '
        Me.SplitContainer6.Panel1.Controls.Add(Me.g_body_01)
        '
        'SplitContainer6.Panel2
        '
        Me.SplitContainer6.Panel2.Controls.Add(Me.img)
        Me.SplitContainer6.Size = New System.Drawing.Size(893, 170)
        Me.SplitContainer6.SplitterDistance = 679
        Me.SplitContainer6.TabIndex = 3
        '
        'g_body_01
        '
        Me.g_body_01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body_01.Location = New System.Drawing.Point(0, 0)
        Me.g_body_01.Name = "g_body_01"
        Me.g_body_01.ReadOnly = False
        Me.g_body_01.RowHeight = -1
        Me.g_body_01.Size = New System.Drawing.Size(679, 170)
        Me.g_body_01.TabIndex = 3
        '
        'img
        '
        Me.img.Location = New System.Drawing.Point(0, 0)
        Me.img.Name = "img"
        Me.img.Size = New System.Drawing.Size(210, 140)
        Me.img.SizeMode = Frame7.ImageSizeMode.Stretch
        Me.img.TabIndex = 157
        Me.img.TitleBorderStyle = Frame7.BorderStyle.None
        '
        'btn_pic
        '
        Me.btn_pic.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_pic.Image = CType(resources.GetObject("btn_pic.Image"), System.Drawing.Image)
        Me.btn_pic.Location = New System.Drawing.Point(112, 3)
        Me.btn_pic.Name = "btn_pic"
        Me.btn_pic.Size = New System.Drawing.Size(24, 20)
        Me.btn_pic.TabIndex = 158
        '
        'EPanel3
        '
        Me.EPanel3.Controls.Add(Me.g_body2)
        Me.EPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EPanel3.Location = New System.Drawing.Point(0, 0)
        Me.EPanel3.Name = "EPanel3"
        Me.EPanel3.Size = New System.Drawing.Size(517, 485)
        Me.EPanel3.TabIndex = 0
        Me.EPanel3.Text = "     도수별"
        '
        'g_body2
        '
        Me.g_body2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.g_body2.Location = New System.Drawing.Point(2, 23)
        Me.g_body2.Name = "g_body2"
        Me.g_body2.ReadOnly = False
        Me.g_body2.RowHeight = -1
        Me.g_body2.Size = New System.Drawing.Size(513, 460)
        Me.g_body2.TabIndex = 2
        '
        'WI_TR1120
        '
        Me.Controls.Add(Me.spc_1)
        Me.Name = "WI_TR1120"
        Me.Size = New System.Drawing.Size(1906, 687)
        Me.Controls.SetChildIndex(Me.spc_1, 0)
        Me.spc_1.Panel1.ResumeLayout(False)
        Me.spc_1.Panel2.ResumeLayout(False)
        Me.spc_1.ResumeLayout(False)
        CType(Me.tab1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab1.ResumeLayout(False)
        Me.tp1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.ResumeLayout(False)
        CType(Me.ep_head, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ep_head.ResumeLayout(False)
        CType(Me.EPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel4.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.XtraTabPage1.ResumeLayout(False)
        Me.XtraTabPage2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.EPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel1.ResumeLayout(False)
        CType(Me.EPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel2.ResumeLayout(False)
        Me.SplitContainer6.Panel1.ResumeLayout(False)
        Me.SplitContainer6.Panel2.ResumeLayout(False)
        Me.SplitContainer6.ResumeLayout(False)
        CType(Me.EPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EPanel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents spc_1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents ep_head As Frame7.ePanel
    Friend WithEvents find_to As Frame7.eDate
    Friend WithEvents find_from As Frame7.eDate
    Friend WithEvents find_od_no As Frame7.eText
    Friend WithEvents find_cs_nm As Frame7.eText
    Friend WithEvents od_no As Frame7.eText
    Friend WithEvents ps_cd As Frame7.eText
    Friend WithEvents ps_nm As Frame7.eText
    Friend WithEvents pl_nm As Frame7.eText
    Friend WithEvents pl_cd As Frame7.eText
    Friend WithEvents cs_nm As Frame7.eText
    Friend WithEvents cs_cd As Frame7.eText
    Friend WithEvents nacs_nm As Frame7.eText
    Friend WithEvents nacs_cd As Frame7.eText
    Friend WithEvents od_dt As Frame7.eDate
    Friend WithEvents od_amt As Frame7.eText
    Friend WithEvents deli_date As Frame7.eDate
    Friend WithEvents nacs_addr As Frame7.eText
    Friend WithEvents dam_nm As Frame7.eText
    Friend WithEvents commission As Frame7.eText
    Friend WithEvents po_no As Frame7.eText
    Friend WithEvents SHIPPING_CORPORATION As Frame7.eText
    Friend WithEvents SHIPPING_PORT As Frame7.eText
    Friend WithEvents deli_place As Frame7.eText
    Friend WithEvents cur_cd As Frame7.eCombo
    Friend WithEvents price_cd As Frame7.eCombo
    Friend WithEvents ship_by As Frame7.eCombo
    Friend WithEvents payterm_cd As Frame7.eCombo
    Friend WithEvents pay_cd As Frame7.eCombo
    Friend WithEvents find_stts As Frame7.eOptionBox
    Friend WithEvents tab1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tp1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents btn_cancel As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_find As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents find_visible As System.Windows.Forms.CheckBox
    Friend WithEvents g_list As Frame7.eGrid
    Friend WithEvents stts1 As Frame7.eCombo
    Friend WithEvents REMARKS As Frame7.eText
    Friend WithEvents sa_cd As Frame7.eCombo
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel1 As Frame7.ePanel
    Friend WithEvents g_body As Frame7.eGrid
    Friend WithEvents EPanel2 As Frame7.ePanel
    Friend WithEvents EPanel3 As Frame7.ePanel
    Friend WithEvents g_body2 As Frame7.eGrid
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btn_bom As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SplitContainer5 As System.Windows.Forms.SplitContainer
    Friend WithEvents EPanel4 As Frame7.ePanel
    Friend WithEvents remk As Frame7.eMemo
    Friend WithEvents ship_nm As Frame7.eText
    Friend WithEvents addr_deli As Frame7.eText
    Friend WithEvents SplitContainer6 As System.Windows.Forms.SplitContainer
    Friend WithEvents g_body_01 As Frame7.eGrid
    Friend WithEvents btn_pic As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents img As Frame7.eImage
    Friend WithEvents odgu_cd As Frame7.eCombo
    Friend WithEvents find_odgu_cd As Frame7.eCombo
    Friend WithEvents temp_nm_cd As Frame7.eText
    Friend WithEvents but_work As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents but2_prt As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents but1_prt As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents bk_type As Frame7.eCombo
    Friend WithEvents ECheck1 As Frame7.eCheck
    Friend WithEvents initi As Frame7.eText
    Friend WithEvents ECheck2 As Frame7.eCheck
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents XtraTabPage1 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabPage2 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents g10 As Frame7.eGrid
    'Friend WithEvents CachedGAC120R1 As System7.CachedGAC120R
    'Friend WithEvents CachedGAC120R2 As System7.CachedGAC120R
    'Friend WithEvents CachedGAC120R3 As System7.CachedGAC120R

End Class
